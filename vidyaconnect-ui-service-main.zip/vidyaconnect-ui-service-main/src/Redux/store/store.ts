import { configureStore } from '@reduxjs/toolkit';
import GetHelpReducer from "../slices/GetLiveHelpSlice";
import ExpertDataReducer from "../slices/ExpertsDataSlice";
import FlagsReducer from "../slices/FlagsSLice";
import PaymentReducer from "../slices/PaymentDetails";
import LearnerReducer from '../slices/LearnerSlices';
import dataSlice from '../slices/ExpertSlice';
import authSlice from "../slices/authSlice";
import modalSlice from "../slices/modalSlice";
import timezoneReducer from "../slices/TimeZoneSlices";
import profilePicreducer from '../slices/ProfilePicGetUploadSlice';
import sessionSlice from "../slices/SessionRequestSlice";
import ExpertSlice from '../slices/ExpertSlice';
import calendarReducer from '../slices/GoogleCalenderApiSlice';
import userSlice from "../slices/userSlice";
import ExpertExploreApiReducer from "../slices/ExpertExporeApiSlice";
import FindAnExpertApiReducer from "../slices/FindAnExpertSlice";
import ticketReducer from "../slices/TicketSlice";
import SessionDetailsReducer from "../slices/SessionDetailsSlice";
import LearnerSlice from '../slices/LearnerSlices';
import ExpertWorkProfileReducer from "../slices/ExpertWorkProfile";
import BankDetailsReducer from "../slices/BankDetailsSlice";
import TimeSlotsReducer from "../slices/AvaliableTimeSlotSlice";
import LearnerSettingReducer from "../slices/LearnerSettingSlice"
import DomainReducer from "../slices/DomainSlice"
import feedbackReducer from '../slices/FeedbackSlice'
import legalContactsReducer from '../slices/LegalContractsSlice'


export const store = configureStore({
  reducer: {
    getHelp: GetHelpReducer,
    expertData: ExpertDataReducer,
    flags: FlagsReducer,
    paymentDetails: PaymentReducer,
    leanerDetails : LearnerReducer,
    data: dataSlice,
    auth: authSlice,
    modal: modalSlice,
    timezone: timezoneReducer,
    profilePic: profilePicreducer,
    user: userSlice,
    expert: ExpertSlice,
    learner: LearnerSlice,
    session: sessionSlice,
    expertExploreApi: ExpertExploreApiReducer,
    googleCalender: calendarReducer,
    FindAnExpertApi: FindAnExpertApiReducer,
    ticket: ticketReducer,
    sessionDetails: SessionDetailsReducer,
    expertWorkProfile: ExpertWorkProfileReducer,
    bankDetails: BankDetailsReducer,
    TimeSlots: TimeSlotsReducer,
    LearnerSetting: LearnerSettingReducer,
    domainData: DomainReducer,
    feedback : feedbackReducer,
    legalContracts: legalContactsReducer
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
