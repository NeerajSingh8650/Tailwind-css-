import axiosInstance from '@/api/axios';
import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { toast } from 'react-toastify';

// Define the initial state
interface Timeslot {
  day: string;
  startTime: string;
  endTime: string;
 
}

interface TimeslotState {
  slots: Timeslot[];
  status: 'idle' | 'loading' | 'succeeded' | 'failed';
  error: string | null;
  deleteData: {
    day: string;
    startTime: string;
    endTime: string;
  };
}

const initialState: TimeslotState = {
  slots: [],
  status: 'idle',
  error: null,
  deleteData: {
    day: '',
    startTime: '',
    endTime: ''
  }
};

// Create an async thunk for fetching available timeslots
export const fetchAvailableTimeslots = createAsyncThunk(
  'timeslots/fetchAvailableTimeslots',
  async (_, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.get('/expert/slots'); // Adjust the URL as needed
      return response.data.data.availableSlots;
    } catch (error: any) {
      toast.error("Failed to fetch timeslots");
      return rejectWithValue(error.response.data);
    }
  }
);

// Create an async thunk for posting a new timeslot
export const postTimeslot = createAsyncThunk(
  'timeslots/postTimeslot',
  async (newTimeslot: Timeslot, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.post('/expert/slots',  {
        "day": newTimeslot.day,
        "startTime": newTimeslot.startTime,
        "endTime": newTimeslot.endTime
      });
      toast.success("Timeslot posted successfully");
      return response.data;
    } catch (error: any) {
      toast.error("Failed to post timeslot");
      return rejectWithValue(error.response.data);
    }
  }
);

// Create an async thunk for deleting a timeslot
export const deleteTimeslot = createAsyncThunk(
  'timeslots/deleteTimeslot',
  async (Timeslot: any, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.delete(`/expert/availableSlots/${Timeslot.day}/startTime/${Timeslot.startTime}/endTime/${Timeslot.endTime}`);
      if (response.status === 204) {
        toast.success("Timeslot deleted successfully");
      }
      return response.data;
    } catch (error: any) {
      toast.error("Failed to delete timeslot");
      return rejectWithValue(error.response.data);
    }
  }
);

// Create a slice of the store
const timeslotSlice = createSlice({
  name: 'timeslots',
  initialState,
  reducers: {
    SlotDeleteData: (state, action) => {
      state.deleteData = action.payload
    }
  },
  extraReducers: (builder) => {
    builder
      // Handle fetchAvailableTimeslots
      .addCase(fetchAvailableTimeslots.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchAvailableTimeslots.fulfilled, (state, action: PayloadAction<Timeslot[]>) => {
        state.status = 'succeeded';
        state.slots = action.payload;
      })
      .addCase(fetchAvailableTimeslots.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message || 'Failed to fetch timeslots';
      })
      // Handle postTimeslot
      .addCase(postTimeslot.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(postTimeslot.fulfilled, (state) => {
        state.status = 'succeeded';
      })
      .addCase(postTimeslot.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message || 'Failed to post timeslot';
      })
      // Handle deleteTimeslot
      .addCase(deleteTimeslot.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(deleteTimeslot.fulfilled, (state) => {
        state.status = 'succeeded';
      })
      .addCase(deleteTimeslot.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message || 'Failed to delete timeslot';
      });
  },
});

// Export the reducer to be used in the store
export default timeslotSlice.reducer;
export const {SlotDeleteData} = timeslotSlice.actions