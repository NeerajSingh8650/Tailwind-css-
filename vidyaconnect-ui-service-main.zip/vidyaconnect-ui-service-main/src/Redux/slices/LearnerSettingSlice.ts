import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import axiosInstance from '../../api/axios';
import { toast } from 'react-toastify';
import { GenderType, LearnerProfileType } from '@/constants';



export interface LearnerPersonalInfo {
    firstName: string;
    lastName: string;
    dob: string;
    gender: GenderType | null;
    learnerProfile: LearnerProfileType | null;
    linkedInProfileLink: string;
    email: string;
    phoneNumber: string;
}

export interface Child {
        id: number;
        name: string;
        dob: string;
        gender: GenderType | null;
        school: string;
        schoolId: number;
        grade: string;
}
interface LearnerSettingState {
    learnerDetails: LearnerPersonalInfo
    children: Child[];
    child: Child;
    loading: boolean;
    error: string | null;
    companies: any[]
    filteredCompanies: any[];
    positions: any[],
}

// Initial state for the slice
const initialState: LearnerSettingState = {
    learnerDetails: {
        firstName: '',
        lastName: '',
        dob: '',
        gender: null,
        learnerProfile: null,
        linkedInProfileLink: '',
        email: '',
        phoneNumber: ''
    },
    children: [],
    child: {
        id: 0,
        name: '',
        dob: '',
        gender: null,
        school: '',
        schoolId: 0,
        grade: ''
    },
    loading: false,
    error: null,
    companies: [],
    filteredCompanies: [],
    positions: [],
};

// Define the async thunk to fetch learner settings
export const fetchLearnerSettings = createAsyncThunk(
    'learnerSettings/fetchLearnerSettings',
    async (_, thunkAPI) => {
        try {
            const response = await axiosInstance.get('/learner');
            return response.data.data;
        } catch (error: any) {
            return thunkAPI.rejectWithValue(error.response?.data || 'An error occurred');
        }
    }
);


export const updateLearnerSettings = createAsyncThunk(
    'learnerSettings/updateLearnerInformation',
    async (learnerDetails: LearnerPersonalInfo, thunkAPI) => {
        try {
            const response = await axiosInstance.put('/learner', {
                "firstName": learnerDetails.firstName,
                "lastName": learnerDetails.lastName,
                "dob": learnerDetails.dob,
                "gender": learnerDetails.gender,
                "learnerProfile": learnerDetails.learnerProfile,
                "linkedInProfileLink": learnerDetails.linkedInProfileLink
            });
            return response.data.data;
        } catch (error: any) {
            return thunkAPI.rejectWithValue(error.response?.data || 'An error occurred');
        }
    }
);

// Define the async thunk to fetch all children
export const fetchChildren = createAsyncThunk(
    'learnerSettings/fetchChildren',
    async (_, thunkAPI) => {
        try {
            const response = await axiosInstance.get('/learner/children');
            return response.data.data.children;
        } catch (error: any) {
            return thunkAPI.rejectWithValue(error.response?.data || 'An error occurred');
        }
    }
);

// Define the async thunk to fetch company data
export const fetchCompanies = createAsyncThunk(
    'learnerSettings/fetchCompanies',
    async (_, thunkAPI) => {
        try {
            const response = await axiosInstance.get('/companies');
            return response.data.data.companies;
        } catch (error: any) {
            return thunkAPI.rejectWithValue(error.response?.data || 'An error occurred');
        }
    }
);


export const fetchPositions = createAsyncThunk(
    'learnerSettings/fetchPositions',
    async (_, thunkAPI) => {
        try {
            const response = await axiosInstance.get('/positions');
            return response.data.data.positions;
        } catch (error: any) {
            return thunkAPI.rejectWithValue(error.response?.data || 'An error occurred');
        }
    }
);



// Define the async thunk to fetch a single child by ID
export const addChildren = createAsyncThunk(
    'learnerSettings/fetchChildById',
    async (childData: Child, thunkAPI) => {
        try {
            if (childData.schoolId !== null) {
                const response = await axiosInstance.post(`/learner/child`, {
                    name: childData.name,
                    dob: childData.dob,
                    gender: childData.gender,
                    schoolId: childData.schoolId,
                    grade: childData.grade
                });

                if (response.data.success === true) {
                    toast.success("Child added successfully");
                    return response;
                }
            } else {
                const response = await axiosInstance.post(`/learner/child`, {
                    name: childData.name,
                    dob: childData.dob,
                    gender: childData.gender,
                    school: childData.school,
                    grade: childData.grade
                });

                if (response.data.success === true) {
                    toast.success("Child added successfully");
                    return response.data;
                }
            }

        } catch (error:any) {
                toast.error("something went wrong")
                return thunkAPI.rejectWithValue(error.response?.data || 'An error occurred');
        }
    }
);

export const updateChildren = createAsyncThunk(
    'learnerSettings/updateChildren',
    async (childData: Child, thunkAPI) => {
        try {
            if (childData.schoolId !== null) {
                const response = await axiosInstance.put(`/learner/child/${childData.id}`, {
                    name: childData.name,
                    dob: childData.dob,
                    gender: childData.gender,
                    schoolId: childData.schoolId,
                    grade: childData.grade
                });

                if (response.data.success === true) {
                    toast.success("Child updated successfully");
                    return response.data;
                }
            } else {
                const response = await axiosInstance.put(`/learner/child/${childData.id}`, {
                    name: childData.name,
                    dob: childData.dob,
                    gender: childData.gender,
                    school: childData.school,
                    grade: childData.grade
                });

                if (response.data.success === true) {
                    toast.success("Child updated successfully");
                    return response.data;
                }
            }

        } catch (error:any) {
                toast.error("something went wrong")
                return thunkAPI.rejectWithValue(error.response?.data || 'An error occurred');
        }
    }
);

// Define the async thunk to delete a child by ID
export const deleteChildById = createAsyncThunk(
    'learnerSettings/deleteChildById',
    async (id: number, thunkAPI) => {
        try {
            const response = await axiosInstance.delete(`/learner/child/${id}`);
            if (response.status === 204) {
                toast.success("Child delete Successfully")
            }
        } catch (error: any) {
            toast.error("Something Went Wrong")
            return thunkAPI.rejectWithValue(error.response?.data || 'An error occurred');
        }
    }
);

// Create the slice
const learnerSettingSlice = createSlice({
    name: 'learnerSettings',
    initialState,
    reducers: {
        gradeUpdater: (state, action: PayloadAction<string>) => {
            state.child = {
                ...state.child,
                grade: action.payload
            };
        },
        schoolUpdater: (state, action) => {
            state.child = {
                ...state.child,
                school: action.payload
            };
        },
        childUpdater: (state, action) => {
            state.child = action.payload
        },
        learnerUpdater: (state, action) => {
            state.learnerDetails = action.payload
        },
        filteredCompaniesUpdater: (state, action) => {
            state.filteredCompanies = action.payload
        }
    },
    extraReducers: (builder) => {
        builder
            // Handle fetchLearnerSettings
            .addCase(fetchLearnerSettings.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchLearnerSettings.fulfilled, (state, action) => {
                state.loading = false;
                state.learnerDetails = action.payload;
            })
            .addCase(fetchLearnerSettings.rejected, (state, action) => {
                state.loading = true;
                state.error = action.payload as string;
            })
            // Handle fetchChildren
            .addCase(fetchChildren.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchChildren.fulfilled, (state, action) => {
                state.loading = false;
                state.children = action.payload;
            })
            .addCase(fetchChildren.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload as string;
            })
            // Handle fetchChildById
            .addCase(addChildren.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(addChildren.fulfilled, (state) => {
                state.loading = false;
            })
            .addCase(addChildren.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload as string;
            })
            // Handle deleteChildById
            .addCase(deleteChildById.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(deleteChildById.fulfilled, (state) => {
                state.loading = false;
            })
            .addCase(deleteChildById.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload as string;
            }).addCase(fetchCompanies.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchCompanies.fulfilled, (state, action) => {
                state.loading = false;
                state.companies = action.payload;
            })
            .addCase(fetchCompanies.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload as string;
            }).addCase(fetchPositions.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchPositions.fulfilled, (state, action) => {
                state.loading = false;
                state.positions = action.payload;
            })
            .addCase(fetchPositions.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload as string;
            });

    },
});

export default learnerSettingSlice.reducer;
export const { gradeUpdater, schoolUpdater, childUpdater, learnerUpdater, filteredCompaniesUpdater } = learnerSettingSlice.actions