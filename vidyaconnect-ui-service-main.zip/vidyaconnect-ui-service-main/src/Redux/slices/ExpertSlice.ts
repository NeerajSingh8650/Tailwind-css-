import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axiosInstance from "../../api/axios";
import { DayOfWeek } from "@/constants";


interface PersonalInformation {
  firstName: string;
  lastName: string;
  dob: string;
  gender: string;
  timezone: string;
  id?: number;
  linkedInProfileLink: string;
}

export interface ExpertOnboardRequest {
  firstName: string;
  lastName: string;
  dob: string;
  gender: string;
  timezone: string;
  linkedInProfileLink?: string | null;
}

export interface TimeSlot {
  startTime: string;
  endTime: string;
}

export interface AvailableSlot {
  day: DayOfWeek;
  slots: TimeSlot[];
}

interface stateInterface {
  personalInformation: PersonalInformation | null;
  expertSkills: [];
  timezones: string[];
  skills: [];
  availableSlots: AvailableSlot[];
  error: any;
  loading: boolean;
  kycUpdated: boolean;
}
const initialState: stateInterface = {
  personalInformation: null,
  expertSkills: [],
  timezones: [],
  skills: [],
  availableSlots: [],
  error: null,
  loading: false,
  kycUpdated: false,
};

interface DeleteAvailabilityArgs {
  day: string;
  startTime: string;
  endTime: string;
}

export const fetchExpertData = createAsyncThunk(
  'expertWorkProfile/fetchExpertData',
  async () => {
      const response = await axiosInstance.get('/expert');
      return response.data.data; 
  }
);

export const fetchTimezones = createAsyncThunk(
  "expert/timezones",
  async (_, { rejectWithValue }) => {
    try {
      const { data } = await axiosInstance.get(`/timezones`);
      return data?.data;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

export const fetchSkills = createAsyncThunk(
  "expert/skills",
  async (args: String, { rejectWithValue }) => {
    try {
      const { data } = await axiosInstance.get(`/skills?search=${args}`);
      return data?.data.skills;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

export const createExpertPersonalInfo = createAsyncThunk<any, ExpertOnboardRequest>(
  "expert/createExpertPersonalInfo",
  async ({firstName, lastName, dob, gender, linkedInProfileLink, timezone}, { rejectWithValue }) => {
    try {
      const { data } = await axiosInstance.post("/tenant/expert/onboard/",
        {
          firstName: firstName,
          lastName: lastName,
          dob: dob,
          gender: gender,
          linkedInProfileLink: linkedInProfileLink,
          timezone: timezone
        }
      );
      return data?.data;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

export const updateExpertPersonalInfo = createAsyncThunk(
  "expert/updateExpertPersonalInfo",
  async (args: object, { rejectWithValue }) => {
    try {
      const { data } = await axiosInstance.put("/expert", args);

      return data;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

export const fetchExpertPersonalInfo = createAsyncThunk(
  "Profile/fetchExpertPersonalInfo",
  async (_, thunkAPI) => {
    try {
      const response = await axiosInstance.get("/tenant/profile");
      return response?.data?.data;
    } catch (error: any) {
      return thunkAPI.rejectWithValue(error.message);
    }
  }
);

export const createExpertExpertise = createAsyncThunk(
  "expert/createExpertExpertise",
  async (args: object, { rejectWithValue }) => {
    try {
      const { data } = await axiosInstance.post("/expert/skills", args);
      return data?.data;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

export const fetchExpertExpertise = createAsyncThunk(
  "expert/fetchExpertExpertise",
  async (_, { rejectWithValue }) => {
    try {
      const { data } = await axiosInstance.get("/expert/skills");
      return data?.data?.expertSkills;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

export const updateExpertExpertise = createAsyncThunk(
  "expert/updateExpertExpertise",
  async (args: object, { rejectWithValue }) => {
    try {
      const { data } = await axiosInstance.put("/expert/skills", args);
      return data?.data;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

export const createExpertAvailability = createAsyncThunk(
  "expert/createExpertAvailability",
  async (args: object, { rejectWithValue }) => {
    try {
      const { data } = await axiosInstance.post("/expert/slots", args);
      return data?.data;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

export const getExpertAvailability = createAsyncThunk(
  "expert/getExpertAvailability",
  async (_, { rejectWithValue }) => {
    try {
      const { data } = await axiosInstance.get("/expert/slots");
      return data?.data;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

export const deleteExpertAvailability = createAsyncThunk(
  "expert/deleteExpertAvailability",
  async (args: DeleteAvailabilityArgs, { rejectWithValue }) => {
    try {
      const { day, startTime, endTime } = args;
      const { data } = await axiosInstance.delete(
        `/expert/availableSlots/${day}/startTime/${startTime}/endTime/${endTime}`
      );
      return data?.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

export const updateExpertKyc = createAsyncThunk(
  "expert/updateExpertKyc",
  async (args: object, { rejectWithValue }) => {
    try {
      const { data } = await axiosInstance.put(
        "/tenant/onboarding-status",
        args
      );
      return data?.data;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

const expertSlice = createSlice({
  name: "expert",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchTimezones.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTimezones.fulfilled, (state, action) => {
        state.loading = false;
        state.timezones = action.payload;
      })
      .addCase(fetchTimezones.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      })
      .addCase(fetchSkills.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchSkills.fulfilled, (state, action) => {
        state.loading = false;
        state.skills = action.payload;
      })
      .addCase(fetchSkills.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      })
      .addCase(createExpertPersonalInfo.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createExpertPersonalInfo.fulfilled, (state, action) => {
        state.loading = false;
        state.personalInformation = action.payload;
      })
      .addCase(createExpertPersonalInfo.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      })
      .addCase(createExpertExpertise.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createExpertExpertise.fulfilled, (state) => {
        state.loading = false;
      })
      .addCase(createExpertExpertise.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      })
      .addCase(getExpertAvailability.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getExpertAvailability.fulfilled, (state, action) => {
        state.loading = false;
        state.availableSlots = action.payload.availableSlots;
      })
      .addCase(getExpertAvailability.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      })
      .addCase(createExpertAvailability.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createExpertAvailability.fulfilled, (state) => {
        state.loading = false;
      })
      .addCase(createExpertAvailability.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      })
      .addCase(updateExpertPersonalInfo.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateExpertPersonalInfo.fulfilled, (state) => {
        state.loading = false;
      })
      .addCase(updateExpertPersonalInfo.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      })
      .addCase(deleteExpertAvailability.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteExpertAvailability.fulfilled, (state) => {
        state.loading = false;
      })
      .addCase(deleteExpertAvailability.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      })
      .addCase(updateExpertKyc.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateExpertKyc.fulfilled, (state) => {
        state.loading = false;
        state.kycUpdated = true;
      })
      .addCase(updateExpertKyc.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      })
      .addCase(fetchExpertPersonalInfo.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchExpertPersonalInfo.fulfilled, (state, action) => {
        state.loading = false;
        state.personalInformation = action.payload;
      })
      .addCase(fetchExpertPersonalInfo.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      })
      .addCase(fetchExpertExpertise.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchExpertExpertise.fulfilled, (state, action) => {
        state.loading = false;
        state.expertSkills = action.payload;
      })
      .addCase(fetchExpertExpertise.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      })
      .addCase(updateExpertExpertise.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateExpertExpertise.fulfilled, (state, action) => {
        state.loading = false;
        state.expertSkills = action.payload;
      })
      .addCase(updateExpertExpertise.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      });
  },
});

export default expertSlice.reducer;
