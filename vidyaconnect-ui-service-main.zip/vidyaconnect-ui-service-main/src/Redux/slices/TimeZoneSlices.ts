import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import axiosInstance from "../../api/axios";
import { getLocalTimeZone } from "@/lib/utils";

const initialState: any = {
  timezones: [],
  loading: false,
  error: null,
  timeSlots: [],
  minutes: 0,
  localTimeZone: getLocalTimeZone(),
};

// Async thunk for fetching timezone details
export const fetchTimeZones = createAsyncThunk(
  "TimeZone/fetchTimeZones",
  async (_, thunkAPI) => {
    try {
      const response = await axiosInstance.get("/timezones");
      return response.data.data;
    } catch (error: any) {
      return thunkAPI.rejectWithValue(error.message);
    }
  }
);

// Slice
export const TimeZoneSlice = createSlice({
  name: "TimeZone",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchTimeZones.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTimeZones.fulfilled, (state, action: PayloadAction<[]>) => {
        state.loading = false;
        state.timezones = action.payload;
      })
      .addCase(fetchTimeZones.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export default TimeZoneSlice.reducer;
