import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import axiosInstance from '../../api/axios';


const initialState: any = {
    otp: []
};

// Async thunk for OTP generation
export const generateOtp = createAsyncThunk(
    'otp/generation',
    async ({ countryCode, phoneNumber}: { countryCode: string, phoneNumber: string}, thunkAPI) => {
        try {
            const response = await axiosInstance.post(
                '/otp/generation',
                {
                    countryCode: parseInt(countryCode),
                    phoneNumber: phoneNumber,
                }
            );
            return response.data?.data;
        } catch (error:any) {
            return thunkAPI.rejectWithValue(error.message);
        }
    }
);

export const otpSlice = createSlice({
    name: 'otp',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(generateOtp.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(generateOtp.fulfilled, (state) => {
                state.loading = false;
            })
            .addCase(generateOtp.rejected, (state, action: PayloadAction<any>) => {
                state.loading = false;
                state.error = action.payload;
            });
    },
});

export default otpSlice.reducer;
