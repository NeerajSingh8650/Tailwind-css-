import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  isOpen: false,
  title: "",
  modalName: "",
};

const modalSlice = createSlice({
  name: "modal",
  initialState,
  reducers: {
    showModal: (state, { payload }) => {
      state.isOpen = true;
      state.title = payload?.title;
      state.modalName = payload?.modalName;
    },
    hideModal: (state) => {
      state.isOpen = false;
      state.title = "";
      state.modalName = "";
    },
  },
});

export const { showModal, hideModal } = modalSlice.actions;

export default modalSlice.reducer;
