
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axiosInstance from '../../api/axios';
import { toast } from 'react-toastify';
import { Skill } from './GetLiveHelpSlice';



export interface TriggerExpertSearchResponse {
    success: boolean;
    status: number;
}


interface FindAnExpertState {
    loading: boolean;
    error: string | null;
    timeslots:string[];
    minutes: number; 
}

const initialState: FindAnExpertState = {
    loading: false,
    error: null,
    timeslots: [],
    minutes: 0
};

interface TriggerExpertSearchRequest {
    sessionDetails: {
        title: string;
        description: string;
        skills: Skill[]
    };
    domainId: number;
    preferredSlots: string[];
    sessionDurationMinutes: number;
    expertPreferences: string[];
}

export const triggerExpertSearch = createAsyncThunk<TriggerExpertSearchResponse, TriggerExpertSearchRequest>(
    'findAnExpert/triggerExpertSearch',
    async ({sessionDetails, preferredSlots, sessionDurationMinutes, expertPreferences, domainId}, { rejectWithValue }) => {
        try {
            const response = await axiosInstance.post('/request/trigger', {
                    title: sessionDetails.title,
                    description: sessionDetails.description,
                    skillIds: sessionDetails.skills.map(skill => skill.id),
                    preferredSlots: preferredSlots,
                    sessionDurationMinutes: sessionDurationMinutes,
                    expertPreferences: expertPreferences,
                    domainId: domainId
                });

                if(response.status === 200){
                    toast.success("Experts have been notified")
                }

            return {
                success: response.data.data.success,
                status: response.status
            }
        } catch (error: any) {
            if (!error.response) {
                throw error;
            }
            return rejectWithValue(error.response.data.data?.error);
        }
    }
);

const findAnExpertSlice = createSlice({
    name: 'findAnExpert',
    initialState,
    reducers: {
        timeSlotsUpdate: (state, action) => {
            state.timeslots = action.payload;
          },
          minutesUpdate: (state, action) => {
            state.minutes = action.payload;
          },
    },
    extraReducers: (builder) => {
        builder
            .addCase(triggerExpertSearch.pending, (state) => {
                state.loading = true;
            })
            .addCase(triggerExpertSearch.fulfilled, (state) => {
                state.loading = false;
            })
            .addCase(triggerExpertSearch.rejected, (state) => {
                state.loading = false;
                state.error = "Error triggering expert search"
            });
    },
});

export const { timeSlotsUpdate, minutesUpdate } = findAnExpertSlice.actions;
export default findAnExpertSlice.reducer;