import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import type { PayloadAction } from '@reduxjs/toolkit'
import axiosInstance from '../../api/axios'


export interface SessionPendingPaymentDetails {
    title: string;
    expertName: string;
    sessionDate: string;
    amountDue: number;
}

interface PendingPaymentResponse {
    pendingPayments: SessionPendingPaymentDetails[];
    totalPayment: number;
    subtotal: number;
    discount: number;
}

export interface PaymentDetailsState {
    pendingPaymentDetails: PendingPaymentResponse
    loading: boolean
    error: string | null
}

const initialState: PaymentDetailsState = {
    pendingPaymentDetails : {
        pendingPayments: [],
        totalPayment: 0,
        subtotal: 0,
        discount: 0
    },
    loading: false,
    error: null,
}

export const fetchPaymentDetails = createAsyncThunk(
    'paymentDetails/fetchPaymentDetails',
    async () => {
        const response = await axiosInstance.get('/pending-payments')
        return response.data.data
    }
)

const paymentDetailsSlice = createSlice({
    name: 'paymentDetails',
    initialState,
    reducers: {
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchPaymentDetails.pending, (state) => {
                state.loading = true
            })
            .addCase(fetchPaymentDetails.fulfilled, (state, action: PayloadAction<PendingPaymentResponse>) => {
                state.loading = false
                state.pendingPaymentDetails = action.payload
            })
            .addCase(fetchPaymentDetails.rejected, (state, action) => {
                state.loading = false
                state.error = action.error.message || 'Failed to fetch payment details'
            })
    },
})

export default paymentDetailsSlice.reducer
