import axiosInstance from '@/api/axios';
import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { toast } from 'react-toastify';
import { Education, WorkExperience } from './ExpertsDataSlice';


export interface Degree {
    id: number;
    name: string;
}
export interface ExpertProfessionalData {
    id: number;
    workExperiences: WorkExperience[];
    education: Education[];
    expertise: Expertise[];
    degrees: Degree[];
    loading: boolean;
    error: string | null;
}

const initialState: ExpertProfessionalData = {
    id: 0,
    workExperiences: [],
    education: [],
    expertise: [],
    degrees: [],
    loading: false,
    error: null
};

interface ExpertUpdateRequest {
    linkedInProfileLink?: string | null;
    timezone?: string | null;
}

export interface ExpertiseSkill {
    skillName: string;
    score: number;
}

export interface Expertise {
    domain: string;
    skills: ExpertiseSkill[]
}
interface ExpertiseResponse {
    expertise: Expertise[];
    statusCode: number;
}

// Async thunk to fetch education data
export const fetchEducation = createAsyncThunk(
    'expertWorkProfile/fetchEducation',
    async () => {
        const response = await axiosInstance.get('/expert/education');
        return response.data.data.educations;
    }
);

// Async thunk to fetch work data
export const fetchWork = createAsyncThunk(
    'expertWorkProfile/fetchWork',
    async () => {
        const response = await axiosInstance.get('/expert/work');
        return response.data.data.workExperiences;
    }
);

export const fetchExpertise = createAsyncThunk<ExpertiseResponse, void>(
    'expertWorkProfile/fetchExpertise',
    async (_, {rejectWithValue}) => {
        try {
        const response = await axiosInstance.get('/expert/expertise');
        return {
            expertise: response.data.data.expertise,
            statusCode: response.status
        }
    } catch(error: any) {
        if (error.response) {
            return rejectWithValue({
                status: error.response.status,
                message: error.response.data?.message || 'Error occurred fetching experise'
            });
        }
        return rejectWithValue({
            status: 500,
            message: 'Network or server error'
        });
    }
    }
);

// Async thunk to fetch degrees
export const fetchDegrees = createAsyncThunk(
    'expertWorkProfile/fetchDegrees',
    async () => {
        const response = await axiosInstance.get('/degrees');
        return response.data.data.degrees;
    }
);


// Async thunk to add new work experience
export const addWorkExperience = createAsyncThunk(
    'expertWorkProfile/addWorkExperience',
    async (workData: any, { rejectWithValue }) => {
        try {
            const response = await axiosInstance.post('/expert/work', {
                company: workData.company,
                position: workData.title,
                employmentType: workData.employmentType,
                startDate: workData.startDate,
                endDate: workData.endDate,
                description: workData.description
            });
            if (response.status === 201) {
                toast.success('Work experience added successfully');
            }
            return response.data.data.workExperience;
        } catch (error: any) {
            toast.error('Failed to add work experience');
            return rejectWithValue(error.response.data);
        }
    }
);

// Async thunk to add new education
export const addEducation = createAsyncThunk(
    'expertWorkProfile/addEducation',
    async (educationData: any, { rejectWithValue }) => {
        try {
            const response = await axiosInstance.post('/expert/education', {
                company: educationData.company,
                degree: educationData.degree,
                course: '',
                startDate: educationData.startDate,
                endDate: educationData.endDate,
                description: educationData.description
            });
            if (response.status === 201) {
                toast.success('Education added successfully');
            }
            return response.data.data.education;
        } catch (error: any) {
            toast.error('Failed to add education');
            return rejectWithValue(error.response.data);
        }
    }
);

// Async thunk to update a work experience
export const updateWorkExperience = createAsyncThunk(
    'expertWorkProfile/updateWorkExperience',
    async ({ workId, workData }: { workId: string, workData: any }, { rejectWithValue }) => {
        try {
            const response = await axiosInstance.put(`/work/${workId}`, {
                company: workData.company,
                position: workData.title,
                employmentType: workData.employmentType,
                startDate: workData.startDate,
                endDate: workData.endDate,
                description: workData.description
            });
            if (response.status === 200) {
                toast.success('Work experience updated successfully');
            }
            return response.data.data.workExperience;
        } catch (error: any) {
            toast.error('Failed to update work experience');
            return rejectWithValue(error.response.data);
        }
    }
);

// Async thunk to update education
export const updateEducation = createAsyncThunk(
    'expertWorkProfile/updateEducation',
    async ({ educationId, educationData }: { educationId: string, educationData: any }, { rejectWithValue }) => {
        try {
            const response = await axiosInstance.put(`/education/${educationId}`, {
                company: educationData.company,
                degree: educationData.degree,
                course: '',
                startDate: educationData.startDate,
                endDate: educationData.endDate,
                description: educationData.description
            });
            if (response.status === 200) {
                toast.success('Education updated successfully');
            }
            return response.data.data.education;
        } catch (error: any) {
            toast.error('Failed to update education');
            return rejectWithValue(error.response.data);
        }
    }
);

// Async thunk to delete a work experience
export const deleteWorkExperience = createAsyncThunk(
    'expertWorkProfile/deleteWorkExperience',
    async (workId: any, { rejectWithValue }) => {
        try {
            const response = await axiosInstance.delete(`/work/${workId}`);
            if (response.status === 204) {
                toast.success('Work experience deleted successfully');
            }
            return workId;
        } catch (error: any) {
            toast.error('Failed to delete work experience');
            return rejectWithValue(error.response.data);
        }
    }
);

// Async thunk to delete education
export const deleteEducation = createAsyncThunk(
    'expertWorkProfile/deleteEducation',
    async (educationId: any, { rejectWithValue }) => {
        try {
            const response = await axiosInstance.delete(`/education/${educationId}`);
            if (response.status === 204) {
                toast.success('Education deleted successfully');
            }
            return educationId;
        } catch (error: any) {
            toast.error('Failed to delete education');
            return rejectWithValue(error.response.data);
        }
    }
);

function filterUnchangedFields(data: ExpertUpdateRequest) {
    const filteredData: Partial<ExpertUpdateRequest> = {};
    Object.keys(data).forEach(key => {
        const value = data[key as keyof ExpertUpdateRequest];
        if (value !== null && value !== undefined) {
            filteredData[key as keyof ExpertUpdateRequest] = value;
        }
    });
    return filteredData;
}

// Async thunk to update expert data
export const updateExpertData = createAsyncThunk<any, ExpertUpdateRequest>(
    'expertWorkProfile/updateExpertData',
    async (expertData: ExpertUpdateRequest, { rejectWithValue }) => {
        const filteredData = filterUnchangedFields(expertData);
        try {
            const response = await axiosInstance.put('/expert', filteredData);
            if (response.status === 200) {
                toast.success('Expert data updated successfully');
            }
            return response.data.data;
        } catch (error: any) {
            toast.error('Failed to update expert data');
            return rejectWithValue(error.response.data);
        }
    }
);

// Create the slice
const expertWorkProfileSlice = createSlice({
    name: 'expertWorkProfile',
    initialState,
    reducers: {
        profileUpdateId: (state, action) => {
            state.id = action.payload;
        },
    },
    extraReducers: (builder) => {
        builder
            // Handle fetch education actions
            .addCase(fetchEducation.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchEducation.fulfilled, (state, action) => {
                state.loading = false;
                state.education = action.payload;
            })
            .addCase(fetchEducation.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error.message || 'Failed to fetch education';
            })
            // Handle fetch work actions
            .addCase(fetchWork.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchWork.fulfilled, (state, action) => {
                state.loading = false;
                state.workExperiences = action.payload;
            })
            .addCase(fetchWork.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error.message || 'Failed to fetch work experiences';
            })
            .addCase(fetchDegrees.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchDegrees.fulfilled, (state, action) => {
                state.loading = false;
                state.degrees = action.payload; // Save degrees to state
            })
            .addCase(fetchDegrees.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error.message || 'Failed to fetch degrees';
            })
            // Handle fetch expert data actions
            // .addCase(fetchExpertData.pending, (state) => {
            //     state.loading = true;
            //     state.error = null;
            // })
            // .addCase(fetchExpertData.fulfilled, (state, action) => {
            //     state.loading = false;
            //     state.expertData = action.payload; // Save expert data to state
            // })
            // .addCase(fetchExpertData.rejected, (state, action) => {
            //     state.loading = false;
            //     state.error = action.error.message || 'Failed to fetch expert data';
            // })
            // Handle add work experience actions
            .addCase(addWorkExperience.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(addWorkExperience.fulfilled, (state) => {
                state.loading = false;
            })
            .addCase(addWorkExperience.rejected, (state) => {
                state.loading = false;
                state.error = 'Failed to add work experience';
            })
            // Handle add education actions
            .addCase(addEducation.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(addEducation.fulfilled, (state) => {
                state.loading = false;
            })
            .addCase(addEducation.rejected, (state) => {
                state.loading = false;
                state.error = 'Failed to add education';
            })
            // Handle update work experience actions
            .addCase(updateWorkExperience.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(updateWorkExperience.fulfilled, (state) => {
                state.loading = false;
            })
            .addCase(updateWorkExperience.rejected, (state) => {
                state.loading = false;
                state.error = 'Failed to update work experience';
            })
            // Handle update education actions
            .addCase(updateEducation.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(updateEducation.fulfilled, (state) => {
                state.loading = false;
            })
            .addCase(updateEducation.rejected, (state) => {
                state.loading = false;
                state.error = 'Failed to update education';
            })
            // Handle delete work experience actions
            .addCase(deleteWorkExperience.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(deleteWorkExperience.fulfilled, (state) => {
                state.loading = false;
            })
            .addCase(deleteWorkExperience.rejected, (state) => {
                state.loading = false;
                state.error =  'Failed to delete work experience';
            })
            // Handle delete education actions
            .addCase(deleteEducation.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(deleteEducation.fulfilled, (state) => {
                state.loading = false;
            })
            .addCase(deleteEducation.rejected, (state) => {
                state.loading = false;
                state.error = 'Failed to delete education';
            })
            .addCase(updateExpertData.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(updateExpertData.fulfilled, (state) => {
                state.loading = false;
            })
            .addCase(updateExpertData.rejected, (state) => {
                state.loading = false;
                state.error = 'Failed to update expert data';
            })
            .addCase(fetchExpertise.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchExpertise.fulfilled, (state, action: PayloadAction<ExpertiseResponse>) => {
                state.loading = false;
                state.expertise = action.payload.expertise;
            })
            .addCase(fetchExpertise.rejected, (state) => {
                state.loading = false;
                state.error = 'Failed to fetch expert expertise';
            });
    },
});


export const { profileUpdateId } = expertWorkProfileSlice.actions;
export default expertWorkProfileSlice.reducer;
