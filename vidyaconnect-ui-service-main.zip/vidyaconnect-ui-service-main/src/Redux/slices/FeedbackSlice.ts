import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import axiosInstance from "../../api/axios";


interface GetFeedbackRequest {
  queryFilter: string | null;
  sortFilter: string;
  page: number;
  size: number;
}

interface GetExpertReviewsRequest {
  expertId: number,
  domainId: number
}

export interface Feedback {
      id: number ,
      rating: string,
      review: string,
      learnerId: number,
      learnerName: string,
      bookingId: number,
      title: string
}

interface FeedbackResponse {
  feedbacks : Feedback[];
  ratings: number;
  numSessions: number;
  statusCode: number;
}

interface DataState {
    data : Feedback[],
    ratings: number,
    numSessions: number,
    loading : boolean, 
    error : string | null
}

const initialState: DataState = {
    data: [],
    ratings: 0,
    numSessions: 0,
    loading: false,
    error: null,
  };


export interface argsType {
    expertId: number,
    bookingId: number,
    rating: string,
    review: string
  }
   
export const submitFeedback = createAsyncThunk(
  'post/submitFeedback',
  async (args: argsType , { rejectWithValue }) => {
    try {      
        const response = await axiosInstance.post(
            "/submit-feedback",
             args
          );

          return response ;

    } catch (error) {
          return rejectWithValue(error)
    }
  }
);

export const getFeedback = createAsyncThunk<FeedbackResponse, GetFeedbackRequest>(
  'expert/getFeedback',
  async ({queryFilter, sortFilter, page, size}, thunkAPI) => {
      try {
        const response = await axiosInstance.post("/feedback", {
          queryFilter: queryFilter,
          sortFilter: sortFilter,
          page: page,
          size: size
        });

        return {
          feedbacks: response.data.data.feedbacks,
          ratings: response.data.data.rating,
          numSessions: response.data.data.numSessions,
          statusCode: response.status
        }
      } catch(error: any) {
        return thunkAPI.rejectWithValue(error.response.status);
      }
  });

  export const getRatings = createAsyncThunk(
    'expert/getFeedbackRatings',
    async (_, thunkAPI) => {
        try {
          const response = await axiosInstance.get("/ratings");
          return response.data.data
        } catch(error: any) {
          return thunkAPI.rejectWithValue(error.response.status);
        }
    });

  export const getExpertReviews = createAsyncThunk<FeedbackResponse, GetExpertReviewsRequest>(
    'expert/getReviews',
    async({expertId, domainId}, thunkAPI) => {
      try {
        let url = `expert/${expertId}/reviews`;
        if (domainId) {
          url = `${url}?domainId=${domainId}`
        }
        const response = await axiosInstance.get(url);
        return {
          feedbacks: response.data.data.feedbacks,
          ratings: response.data.data.rating,
          numSessions: response.data.data.numSessions,
          statusCode: response.status
        }
      } catch(error: any) {
        return thunkAPI.rejectWithValue(error.response.status);
      }
    }
  );

  const feedbackSlice = createSlice({
    name: 'feedback',
    initialState,
    reducers: {
    },
    extraReducers: (builder) => {
      builder
        .addCase(submitFeedback.pending, (state) => {
           state.loading = true;
        })
        .addCase(submitFeedback.fulfilled, (state) => {
           state.loading = false;
        })
        .addCase(submitFeedback.rejected, (state, action: PayloadAction<any>) => {
          state.loading = false;
          state.error = action.payload || "Failed to submit feedback";
        })
        .addCase(getFeedback.pending, (state) => {
          state.loading = true;
       })
       .addCase(getFeedback.fulfilled, (state, action: PayloadAction<FeedbackResponse>) => {
          state.loading = false;
          state.data = action.payload.feedbacks;
          state.numSessions = action.payload.numSessions;
          state.ratings = action.payload.ratings;
       })
       .addCase(getFeedback.rejected, (state) => {
         state.loading = false;
         state.error = "Failed to retrieve feedbacks for expert";
       })
      .addCase(getRatings.pending, (state) => {
        state.loading = true;
       })
      .addCase(getRatings.fulfilled, (state, action) => {
        state.loading = false;
        state.ratings = action.payload.rating;
        state.numSessions = action.payload.numSessions;
      })
      .addCase(getRatings.rejected, (state) => {
       state.loading = false;
       state.error = "Failed to get expert ratings";
     })
     .addCase(getExpertReviews.pending, (state) => {
      state.loading = true;
      })
    .addCase(getExpertReviews.fulfilled, (state, action) => {
      state.loading = false;
      state.data = action.payload.feedbacks;
      state.ratings = action.payload.ratings;
      state.numSessions = action.payload.numSessions;
    })
    .addCase(getExpertReviews.rejected, (state) => {
      state.loading = false;
      state.error = "Failed to get expert reviews";
   })
    },
  });
  
  export default feedbackSlice.reducer;