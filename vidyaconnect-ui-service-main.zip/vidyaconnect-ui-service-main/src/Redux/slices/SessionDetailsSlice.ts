// src/store/viewSessionDetailsSlice.ts
import axiosInstance from '@/api/axios';
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

interface BookingDetailsState {
    booking: any | null;
    status: 'idle' | 'loading' | 'succeeded' | 'failed';
    error: string | null;
    sessionId: any;
}

const initialState: BookingDetailsState = {
    booking: null,
    status: 'idle',
    error: null,
    sessionId: ""
};

// Create async thunk for fetching booking details
export const fetchBookingDetails = createAsyncThunk(
    'viewSessionDetails/fetchBookingDetails',
    async (id: number, thunkAPI) => {
        try {
            const response = await axiosInstance.get(`/booking/${id}`);
            return response.data.data;
        } catch (error: any) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    }
);

const viewSessionDetailsSlice = createSlice({
    name: 'viewSessionDetails',
    initialState,
    reducers: {
        sessionIdUpdate: (state, action) => {
            state.sessionId = action.payload
        }
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchBookingDetails.pending, (state) => {
                state.status = 'loading';
                state.error = null;
            })
            .addCase(fetchBookingDetails.fulfilled, (state, action) => {
                state.status = 'succeeded';
                state.booking = action.payload;
            })
            .addCase(fetchBookingDetails.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.payload as string;
            });
    },
});

export default viewSessionDetailsSlice.reducer;
export const {sessionIdUpdate} = viewSessionDetailsSlice.actions