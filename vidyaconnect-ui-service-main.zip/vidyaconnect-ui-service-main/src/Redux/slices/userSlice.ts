import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axiosInstance from "../../api/axios";

interface stateInterface {
  userDetails: any;
  error: any;
  loading: boolean;
  onboardStatus: any;
  isLoggedIn: boolean;
}
const initialState: stateInterface = {
  userDetails: {},
  error: "",
  loading: false,
  onboardStatus: {},
  isLoggedIn: JSON.parse(sessionStorage.isLoggedIn || "false"),
};

export const checkOnboardingStatus = createAsyncThunk(
  "user/checkOnboardingStatus",
  async (_, { rejectWithValue }) => {
    try {
      const { data } = await axiosInstance.get(`/status`);
      return data?.data;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

export const getProfileDetails = createAsyncThunk(
  "user/getProfileDetails",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.get(`/tenant/profile`);
      if (!sessionStorage.isLoggedIn) {
        sessionStorage.setItem("isLoggedIn", "true");
      }
      return response?.data?.data;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

export const getOAuthUserDetails = createAsyncThunk(
  "user/getOAuthUserDetails",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.get(`/tenant/oauth2User`);
      return response?.data?.data;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

export const updateLearnerProfile = createAsyncThunk(
  "user/updateLearnerProfile",
  async (args: any, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.put(`/learner`, args);

      return response;
    } catch (error: any) {
      const { status, data } = error.response || { status: 0, data: null };

      return rejectWithValue({
        statusCode: status,
        apiResponse: data.error.message,
      });
    }
  }
);

export const updateTenantProfile = createAsyncThunk(
  "user/updateTenantProfile",
  async (args: any, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.put(`/tenant`, args);

      return response;
    } catch (error: any) {
      const { status, data } = error.response || { status: 0, data: null };

      return rejectWithValue({
        statusCode: status,
        apiResponse: data.error.message,
      });
    }
  }
);

const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    setLoggedIn: (state, action) => {
      state.isLoggedIn = action.payload;
    },
  },
  extraReducers: (builder) =>
    builder
      .addCase(checkOnboardingStatus.pending, (state, {}) => {
        state.loading = true;
      })
      .addCase(checkOnboardingStatus.fulfilled, (state, action) => {
        state.loading = false;
        state.onboardStatus = action.payload;
      })
      .addCase(checkOnboardingStatus.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      })
      .addCase(getProfileDetails.pending, (state, {}) => {
        state.loading = true;
      })
      .addCase(getProfileDetails.fulfilled, (state, action) => {
        state.loading = false;
        state.userDetails = action.payload;
      })
      .addCase(getProfileDetails.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      }),
});

export const { setLoggedIn } = userSlice.actions;
export default userSlice.reducer;
