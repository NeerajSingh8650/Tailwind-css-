// bankDetailsSlice.ts
import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import axiosInstance from '../../api/axios'; 

// Define types for your state and the response data
interface BankDetails {
    name: string;
    accountNumber: string;
    ifscCode: string;
}

interface BankDetailsState {
    bankDetails: BankDetails | null;
    loading: boolean;
    error: string | null;
}

// Initial state
const initialState: BankDetailsState = {
    bankDetails: null,
    loading: false,
    error: null,
};

// Async thunk for fetching bank details
export const fetchBankDetails = createAsyncThunk(
    'bankDetails/fetchBankDetails',
    async (_, thunkAPI) => {
        try {
            const response = await axiosInstance.get('/bank-details');
            return response.data.data; // Assuming response.data is the bank details
        } catch (error) {
            return thunkAPI.rejectWithValue('Failed to fetch bank details');
        }
    }
);

// Create slice
const bankDetailsSlice = createSlice({
    name: 'bankDetails',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(fetchBankDetails.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchBankDetails.fulfilled, (state, action: PayloadAction<BankDetails>) => {
                state.loading = false;
                state.bankDetails = action.payload;
            })
            .addCase(fetchBankDetails.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload as string;
            });
    },
});

export default bankDetailsSlice.reducer;
