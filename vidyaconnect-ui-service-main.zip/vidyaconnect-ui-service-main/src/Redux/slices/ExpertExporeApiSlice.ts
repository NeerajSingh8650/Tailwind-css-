import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import axiosInstance from '../../api/axios';
import {toast} from "react-toastify"
import { Skill } from './GetLiveHelpSlice';
import { TimeSlot } from './ExpertSlice';


// Define the shape of the state
interface ExpertExploreState {
    timeData: ExpertAvailabilityResponse;
    prevPaymentAmount: number | null;
    prevPaymentStatus: string | null;
    labels: any[];
    experts: any[];
    loading: boolean;
    error: string | null;
    statusCode: null | number
}

// Define the initial state
const initialState: ExpertExploreState = {
    timeData: {
        availability: []
    },
    prevPaymentAmount: null,
    prevPaymentStatus: null,
    labels: [],
    experts: [],
    loading: false,
    error: null,
    statusCode : null
};


interface BookSessionRequest {
    expertId: number;
    sessionDetails: {
        title: string;
        description: string;
        skills: Skill[]
    };
    dateData: Date;
    bookData: Date;
    min: number;
    bucket: string;
    domainId: number;
}

interface BookSessionResponse {
    previousPayments: number;
    status: string;
    statusCode: number
}

export interface ExpertDayAvailability {
    day: string;
    date: string;
    slots: TimeSlot[]
}

interface ExpertAvailabilityResponse {
    availability: ExpertDayAvailability[];
}

// Async thunk for fetching availability
export const fetchAvailability: any = createAsyncThunk<ExpertAvailabilityResponse, number>(
    'ExpertExploreApi/fetchAvailability',
    async (expertId, thunkAPI) => {
        try {
            const userLocalTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
            const response = await axiosInstance.post(`/request/expert/${expertId}/availability`, {
                learnerTimezone: userLocalTimezone
            }
            );
            return response.data.data;
        } catch (error: any) {
            return thunkAPI.rejectWithValue(error.message);
        }
    }
);

// Async thunk for fetching session payment data
export const bookSession: any = createAsyncThunk<BookSessionResponse, BookSessionRequest>(
    'ExpertExploreApi/bookSession',
    async ({ expertId, sessionDetails, dateData, min, bucket, domainId }, thunkAPI) => {
        try {
            const response = await axiosInstance.post('/request/session', {
                expertId: expertId,
                title: sessionDetails.title,
                description: sessionDetails.description,
                sessionStart: dateData,
                sessionDurationMinutes: min,
                bucket: bucket,
                domainId: domainId,
                skillIds: sessionDetails.skills.map(skill => skill.id)
            });   
            
            console.log("prev payment response", response.data.data.previousPayments);
              
            return {
                previousPayments: response.data.data.previousPayments?.totalDues,
                status: response.data.data.status, 
                statusCode: response.status
            };

            
        } catch (error: any) {
            if (error.response && error.response.status === 400) {
                const errorMessage = error.response.data.error?.message || 'Bad request. Please try again.';
                toast.error(errorMessage);
                thunkAPI.rejectWithValue(error.response.status);
              }

            return thunkAPI.rejectWithValue(error.response.status);
        }
    }
);

// Async thunk for fetching labels
export const fetchLabels: any = createAsyncThunk<any[], void>(
    'ExpertExploreApi/fetchLabels',
    async (_, thunkAPI) => {
        try {
            const response = await axiosInstance.get('/exploration/labels');
          //  thunkAPI.dispatch(domainIdUpdate(response.data.data.labels[0].labelId));
            return response.data.data.labels;
        } catch (error: any) {
            return thunkAPI.rejectWithValue(error.message);
        }
    }
);

// Async thunk for fetching experts based on label
export const fetchExperts: any = createAsyncThunk<any[], string>(
    'ExpertExploreApi/fetchExperts',
    async (labelId, thunkAPI) => {
        try {
            const response = await axiosInstance.post('/exploration/experts', {
                labelId
            });
            return response.data.data.experts;
        } catch (error: any) {
            return thunkAPI.rejectWithValue(error.message);
        }
    }
);



// Slice
const ExpertExploreApiSlice = createSlice({
    name: 'ExpertExploreApi',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(fetchAvailability.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchAvailability.fulfilled, (state, action: PayloadAction<ExpertAvailabilityResponse>) => {
                state.loading = false;
                state.timeData = action.payload;
            })
            .addCase(fetchAvailability.rejected, (state, action: PayloadAction<string | null>) => {
                state.loading = false;
                state.error = action.payload ?? 'An error occurred while fetching availability';
            })
            .addCase(bookSession.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(bookSession.fulfilled, (state, action: PayloadAction<BookSessionResponse>) => {    
                state.loading = false;
                state.prevPaymentAmount = action.payload.previousPayments;
                state.prevPaymentStatus = action.payload.status;
                state.statusCode = action.payload.statusCode
            })
            .addCase(bookSession.rejected, (state, action: any) => {
                state.loading = false;
                state.statusCode = action.payload
              
            })
            .addCase(fetchLabels.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchLabels.fulfilled, (state, action: PayloadAction<any[]>) => {
                state.loading = false;
                state.labels = action.payload;
            })
            .addCase(fetchLabels.rejected, (state, action: PayloadAction<string | null>) => {
                state.loading = false;
                state.error = action.payload ?? 'An error occurred while fetching labels';
            })
            .addCase(fetchExperts.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchExperts.fulfilled, (state, action: PayloadAction<any[]>) => {
                state.loading = false;
                state.experts = action.payload;
            })
            .addCase(fetchExperts.rejected, (state, action: PayloadAction<string | null>) => {
                state.loading = false;
                state.error = action.payload ?? 'An error occurred while fetching experts';
            });
    },
});

export default ExpertExploreApiSlice.reducer;
