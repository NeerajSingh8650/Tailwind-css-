import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import type { PayloadAction } from '@reduxjs/toolkit';
import axiosInstance from "../../api/axios";
import { getProfileDetails } from './userSlice';

export interface School {
    id: number;
    name: string;
}
  
export interface Learner {
    id: number | null;
    error: any;
    loading: boolean;
    schools: School[];
    onboardingDone: boolean;
    children : object[];
}
interface childData {
    name: string;
    dob: string;
    gender: string;
    school: string;
    schoolId?: number;
    grade: string;
    id?: number;
}


const initialState: Learner = {
    id: null,
    error: null,
    loading: false,
    schools: [],
    onboardingDone: false,
    children: []
};

// Async Thunks
export const fetchSchools = createAsyncThunk(
    "learner/fetchSchools",
    async (_, { rejectWithValue }) => {
        try {
            const response = await axiosInstance.get(`/companies`);
            const schools = response.data.data.companies.map((company: any) => ({
                id: company.id,
                name: company.name
            }));
            return schools; 
        } catch (error) {
            return rejectWithValue(error);
        }
    }
);

export const learnerOnboard = createAsyncThunk(
    "learner/learnerOnboard",
    async (args: Object, { rejectWithValue, dispatch }) => {
        try {
            const { data } = await axiosInstance.post(`/tenant/learner/onboard`, args);
            dispatch(getProfileDetails())
            return data?.data;
        } catch (error) {
            return rejectWithValue(error);
        }
    }
);


// Async Thunks
export const getChildren = createAsyncThunk(
    "learner/getChildren",
    async (_, { rejectWithValue }) => {
        try {
            const data = await axiosInstance.get(`learner/children`);
            return data?.data?.data;
        } catch (error) {
            return rejectWithValue(error);
        }
    }
);

export const saveChildData = createAsyncThunk(
    "learner/saveChildData",
    async (args: childData, { rejectWithValue }) => {
        try {
            const response = args.id ? await axiosInstance.put(`/learner/child/${args.id}`, args)
            : await axiosInstance.post(`/learner/child`, args);
            return response.data?.data;
        } catch (error) {
            return rejectWithValue(error);
        }
    }
);

export const deleteChild = createAsyncThunk(
    "learner/deleteChild",
    async (args: childData, { rejectWithValue }) => {
        try {
            const response = await axiosInstance.delete(`/learner/child/${args.id}`)
            return response.data?.data;
        } catch (error) {
            return rejectWithValue(error);
        }
    }
);

 


// Slice
export const learnerSlice = createSlice({
    name: 'learner',
    initialState,
    reducers: {
        learnerIdUpdate: (state, action: PayloadAction<null | number>) => {
            state.id = action.payload;
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchSchools.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchSchools.fulfilled, (state, action) => {
                state.loading = false;
                state.schools = action.payload;
            })
            .addCase(fetchSchools.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
            })
            .addCase(learnerOnboard.pending, (state) => {
                state.loading = true;
                state.error = null;
                state.onboardingDone = false;
            })
            .addCase(learnerOnboard.fulfilled, (state) => {
                state.loading = false;
                state.onboardingDone = true;
            })
            .addCase(learnerOnboard.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
                state.onboardingDone = false;
            })
            .addCase(saveChildData.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(saveChildData.fulfilled, (state) => {
                state.loading = false;
            })
            .addCase(saveChildData.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
            })
            .addCase(deleteChild.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(deleteChild.fulfilled, (state) => {
                state.loading = false;
            })
            .addCase(deleteChild.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
            })
            .addCase(getChildren.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(getChildren.fulfilled, (state, action) => {
                state.loading = false;
                state.children = action.payload;
            })
            .addCase(getChildren.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = payload;
            });
    },
});

export const { learnerIdUpdate } = learnerSlice.actions;
export default learnerSlice.reducer;
