import { createSlice } from '@reduxjs/toolkit'
import type { PayloadAction } from '@reduxjs/toolkit'


export interface flag {
    bookSessionResponseModal: boolean;
    ExploreBookSessionModal: boolean;
    bookingSessionModalFlag: boolean;
    CancelledSessionDrawerFlag: boolean;
    learnerGetLiveHelpModalFlag: boolean;
    learnerTimePreferenceModalFlag: boolean;
    expertPreferenceModalFlag: boolean;
}

const initialState: flag = {
    bookSessionResponseModal: false,
    ExploreBookSessionModal: false,
    bookingSessionModalFlag: false,
    CancelledSessionDrawerFlag: false,
    learnerGetLiveHelpModalFlag: false,
    learnerTimePreferenceModalFlag: false,
    expertPreferenceModalFlag: false
}

export const FlagsSlice = createSlice({
    name: 'flags',
    initialState,
    reducers: {
        bookSessionResponseModalUpdate: (state, action: PayloadAction<boolean>) => {
            state.bookSessionResponseModal = action.payload
        },
        ExploreBookSessionModalUpdate: (state, action: PayloadAction<boolean>) => {
            state.ExploreBookSessionModal = action.payload
        },
        bookingSessionModalFlagUpdate: (state, action: PayloadAction<boolean>) => {
            state.bookingSessionModalFlag = action.payload
        },
        cancelledSessionDrawerFlagUpdate: (state, action) => {
            state.CancelledSessionDrawerFlag = action.payload
        },
        learnerGetLiveHelpModalUpdate: (state, action: PayloadAction<boolean>) => {
            state.learnerGetLiveHelpModalFlag = action.payload
        },
        learnerTimePreferenceModalUpdate: (state, action: PayloadAction<boolean>) => {
            state.learnerTimePreferenceModalFlag = action.payload
        },
        expertPreferenceModalFlagUpdate: (state, action: PayloadAction<boolean>) => {
            state.expertPreferenceModalFlag = action.payload
        }
    },
})


export const { bookSessionResponseModalUpdate,
    ExploreBookSessionModalUpdate,
    bookingSessionModalFlagUpdate,
    cancelledSessionDrawerFlagUpdate,
    learnerGetLiveHelpModalUpdate,
    learnerTimePreferenceModalUpdate,
    expertPreferenceModalFlagUpdate } = FlagsSlice.actions
export default FlagsSlice.reducer