import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axiosInstance from "../../api/axios";
import {
  PAGE_SIZE,
  CANCELLED_SESSIONS_NOTIFICATIONS_SIZE,
  BOOKING_STATUS_EXPIRED,
  BOOKING_STATUS_CANCELLED,
  BOOKING_STATUS_REJECTED,
} from "../../constants";
import { PayloadAction } from "@reduxjs/toolkit";
import { toast } from "react-toastify";


// Initial state
const initialState: any = {
  sessions : [] ,
  completedData: [],
  historyStatusData: [],
  cancelledData: [],
  loading: false,
  error: null,
  filters: "",
  meeting: {},
};


interface FetchSessionArgs {
  queryFilter: string;
  sortFilter: string;
  page: number;
  size: number;
}



export const fetchSessions = createAsyncThunk("SessionDetails/fetchSessions",
  async({queryFilter ,sortFilter, page ,  size}:FetchSessionArgs, thunkAPI)=>{
     try {
        const response = await axiosInstance.post("/sessions", {
          queryFilter, 
          sortFilter,
          page,
          size
        })
        return response.data.data.sessions
     } catch (error:any ) {
      return thunkAPI.rejectWithValue(error.message);
     }
  }  
)

 


// Async thunk for fetching completed sessions
export const fetchSessionHistory = createAsyncThunk(
  "SessionDetails/fetchCompletedSessions",
  async (filter: string, thunkAPI) => {
    try {
      const response = await axiosInstance.post("/sessions", {
        queryFilter: `status=in=(${filter})`,
        sortFilter: "id,desc",
        page: 0,
        size: PAGE_SIZE,
      });

      if (response.status === 200) {
        return response.data.data.sessions;
      }
    } catch (error: any) {
      return thunkAPI.rejectWithValue(error.message);
    }
  }
);

// Async thunk for fetching history sessions with specified status
export const fetchHistorySessionstatus = createAsyncThunk(
  "SessionDetails/fetchHistorySessionstatus",
  async (_, thunkAPI) => {
    try {
      const response = await axiosInstance.get("/session-history/status");
      if (response.status === 200) {
        return response.data.data;
      }
    } catch (error: any) {
      return thunkAPI.rejectWithValue(error.message);
    }
  }
);

// Async thunk for approval selection API
export const approvalSelectionApi = createAsyncThunk(
  "SessionDetails/approvalSelectionApi",
  async ({ action, id }: { action: any; id: number }, thunkAPI) => {
    try {
      const res = await axiosInstance.get(
        `/request/booking/${id}?action=${action}`
      );
      if (res) {
        action === "ACCEPT" ? toast("Approved") : toast("Rejected");
      }
    } catch (error: any) {
      return thunkAPI.rejectWithValue(error.message);
    }
  }
);

// Async thunk for cancel booked session API
export const cancelBooking = createAsyncThunk(
  "SessionDetails/cancelBooking",
  async (id: number, thunkAPI) => {
    try {
      const res = await axiosInstance.get(`/booking/${id}/cancellation`);
      if (res) {
        toast("cancelled");
      }
    } catch (error: any) {
      return thunkAPI.rejectWithValue(error.message);
    }
  }
);

// Async thunk for fetching cancelled sessions
export const fetchCancelledSession = createAsyncThunk(
  "SessionDetails/fetchCancelledSession",
  async (_, thunkAPI) => {
    try {
      const response = await axiosInstance.post("/sessions", {
        queryFilter: `status=in=(${BOOKING_STATUS_CANCELLED},${BOOKING_STATUS_EXPIRED},${BOOKING_STATUS_REJECTED})`,
        sortFilter: "id,desc",
        page: 0,
        size: CANCELLED_SESSIONS_NOTIFICATIONS_SIZE,
      });
      return response.data.data.sessions;
    } catch (error: any) {
      return thunkAPI.rejectWithValue(error.message);
    }
  }
);

// Slice
export const SessionDetailsSlice = createSlice({
  name: "SessionDetails",
  initialState,
  reducers: {
    filterUpdate: (state, action: PayloadAction<string>) => {
      state.filters = action.payload;
    },
    setMeetingDetails: (state, action: PayloadAction) => {
      state.meeting = action.payload;
    },
    clearSessionsData: (state) => {
      state.sessions = []
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchSessionHistory.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchSessionHistory.fulfilled, (state, action) => {
        state.loading = false;
        state.completedData = action.payload;
      })
      .addCase(fetchSessionHistory.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(fetchHistorySessionstatus.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchHistorySessionstatus.fulfilled, (state, action) => {
        state.loading = false;
        state.historyStatusData = action.payload;
      })
      .addCase(approvalSelectionApi.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(approvalSelectionApi.fulfilled, (state) => {
        state.loading = false;
      })
      .addCase(approvalSelectionApi.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(cancelBooking.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(cancelBooking.fulfilled, (state) => {
        state.loading = false;
      })
      .addCase(cancelBooking.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(fetchCancelledSession.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchCancelledSession.fulfilled, (state, action) => {
        state.loading = false;
        state.cancelledData = action.payload;
      })
      .addCase(fetchHistorySessionstatus.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(fetchSessions.pending , (state)=>{
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchSessions.fulfilled , (state, action)=>{
          state.loading = false;
          state.sessions = action.payload
      })
      .addCase(fetchSessions.rejected , (state, action)=>{
        state.loading = false 
        state.error = action.payload
      })
  },
});
export const { filterUpdate, setMeetingDetails, clearSessionsData } = SessionDetailsSlice.actions;
export default SessionDetailsSlice.reducer;
