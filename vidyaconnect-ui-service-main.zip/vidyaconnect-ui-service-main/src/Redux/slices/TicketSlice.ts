import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axiosInstance from '../../api/axios';
import {toast} from "react-toastify"
// Define types for the state and API responses
interface TicketCategory {
  id: string;
  name: string;
}

interface Ticket {
  id: string;
  title: string;
  description: string;
}

interface TicketState {
  categories: TicketCategory[];
  tickets: Ticket[];
  loading: boolean;
  error: string | null;
}

// Define initial state
const initialState: TicketState = {
  categories: [],
  tickets: [],
  loading: false,
  error: null,
};

// Create an asynchronous thunk for fetching ticket categories
export const fetchTicketCategories = createAsyncThunk<TicketCategory[]>(
  'ticket/fetchTicketCategories',
  async (_, thunkAPI) => {
    try {
      const response = await axiosInstance.get('/ticket-categories');
      return response.data.data; // Assuming the API response directly returns the array of categories
    } catch (error: any) {
      return thunkAPI.rejectWithValue(error.message);
    }
  }
);

// Create an asynchronous thunk for fetching tickets
export const fetchTickets = createAsyncThunk<Ticket[], { categoryId: number, value: string }>(
  'ticket/fetchTickets',
  async ({ categoryId, value }, thunkAPI) => {
    try {
      const response = await axiosInstance.post('/ticket',
        {
          categoryId: categoryId,
          description: value,
          assignee: "string"
        }
      );
      if (response.status === 200) {
        toast.success("Ticket raised successfully!");
      }else{
        toast.error("Something went Wrong");
      }
      return response.data.data; // Assuming the API response directly returns the array of tickets
    } catch (error: any) {
      return thunkAPI.rejectWithValue(error.message);
    }
  }
);


// Create the slice
const ticketSlice = createSlice({
  name: 'ticket',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    // Handle fetchTicketCategories actions
    builder
      .addCase(fetchTicketCategories.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTicketCategories.fulfilled, (state, action) => {
        state.loading = false;
        state.categories = action.payload;
      })
      .addCase(fetchTicketCategories.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });

    // Handle fetchTickets actions
    builder
      .addCase(fetchTickets.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTickets.fulfilled, (state, action) => {
        state.loading = false;
        state.tickets = action.payload;
      })
      .addCase(fetchTickets.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

// Export the reducer
export default ticketSlice.reducer;
