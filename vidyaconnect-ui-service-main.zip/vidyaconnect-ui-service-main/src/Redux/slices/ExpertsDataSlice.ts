import axiosInstance from '@/api/axios';
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import type { PayloadAction } from '@reduxjs/toolkit'


export interface WorkExperience {
    id: number;
    company: string;
    position: string;
    employmentType: string | null;
    startDate: string;
    endDate: string | null;
    description: string;
}

export interface Education {
    id: number;
    company: string;
    degree: string;
    course: string;
    startDate: string;
    endDate: string | null;
    description: string;
}

interface Skill {
    expertSkillId: number;
    name: string;
    score: number;
}

interface ExpertProfileData {
    id: number;
    name: string;
    currentPosition: string;
    priceBucket: string;
    picUrl: string;
    ratings: number;
    numSessions: number;
    workExperiences: WorkExperience[];
    education: Education[];
    skills: Skill[];
}

interface ExpertProfileResponse {
    expertProfileData: ExpertProfileData;
    statusCode: number;
}

export interface ExpertDataState {
    loading: boolean;
    expertProfileData: ExpertProfileData;
    id: number;
    timeData: any[];
    selectedSlot: string;
    error: string | null;
}

const initialState: ExpertDataState = {
    loading: false,
    id: 0,
    timeData: [],
    selectedSlot: "",
    expertProfileData: {
        id: 0,
        name: '',
        currentPosition: '',
        priceBucket: '',
        picUrl: '',
        ratings: 0,
        numSessions: 0,
        workExperiences: [],
        education: [],
        skills: []
    },
    error: null
}

interface ExpertViewProfileRequest {
    expertId: number;
    domainId: number | null;
    priceBucket: string | null;
}

export const getExpertProfile = createAsyncThunk<ExpertProfileResponse, ExpertViewProfileRequest>(
    'findAnExpert/getExpertProfile',
    async ({expertId, domainId, priceBucket}, thunkAPI) => {
        try {
            let url = `expert/${expertId}/view-profile`;
            const params = new URLSearchParams();

            if (domainId) {
                params.append("domain", domainId.toString()); 
            }
            if (priceBucket) {
                params.append("priceBucket", priceBucket);
            }
            
            if (params.toString()) {
                url += `?${params.toString()}`;
            }

            const response = await axiosInstance.get(url);
            return {
                expertProfileData: response.data.data,
                statusCode: response.status
            }
       
        } catch (error: any) {
            if (!error.response) {
                throw error;
            }
            return thunkAPI.rejectWithValue(error.response.data);
        }
    }
);

// Create the slice
export const expertDataSlice = createSlice({
    name: 'expertDataSlice',
    initialState,
    reducers: {
        idUpdate: (state, action: PayloadAction<number>) => {
            state.id = action.payload
        },
        timeDataUpdate: (state, action: PayloadAction<any[]>) => {
            state.timeData = action.payload
        },
        selectedSlotUpdate: (state, action: PayloadAction<string>) => {
            state.selectedSlot = action.payload
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(getExpertProfile.pending, (state) => {
                state.loading = true;
            })
            .addCase(getExpertProfile.fulfilled, (state, action: PayloadAction<ExpertProfileResponse>) => {
                state.loading = false;
                state.expertProfileData = action.payload.expertProfileData
            })
            .addCase(getExpertProfile.rejected, (state) => {
                state.loading = false;
                state.error = "Erorr getting expert profile";
            });
    },
})

// Export actions and reducer
export const { idUpdate, timeDataUpdate, selectedSlotUpdate } = expertDataSlice.actions
export default expertDataSlice.reducer
