import axiosInstance from "@/api/axios";
import { PRIVACY_POLICY_DOCUMENT_TYPE, PROFILE, TERMS_CONDITIONS_DOCUMENT_TYPE } from "@/constants";
import { createAsyncThunk, createSlice, PayloadAction } from "@reduxjs/toolkit";

export interface LegalContracts {
    learnerTermsAndConditions: string,
    expertTermsAndConditions: string,
    privacy: string,
    cookies: string,
    loading: boolean,
    error: string | null
}

const initialState: LegalContracts = {
    learnerTermsAndConditions : "",
    expertTermsAndConditions: "",
    privacy: "",
    cookies: "",
    loading: false,
    error: null
}

interface LegalContractsResponse {
    content: string,
    documentType: string,
    version: string,
    statusCode: number,
    profile: string | null
}

interface LegalContactsRequest {
    type: string,
    profile: string
}


export const getLatestLegalContacts: any = createAsyncThunk<LegalContractsResponse, LegalContactsRequest>(
    'legalContracts/getLatestLegalContacts',
    async (type, thunkAPI) => {
        try {
            const response = await axiosInstance.get(`/legal-document/${type}/active`);            
              
            return {
                content: response.data.data.content,
                documentType: response.data.data.documentType,
                version: response.data.data.version,
                statusCode: response.status,
                profile: response.data.data.profile
            };

            
        } catch (error: any) {
            return thunkAPI.rejectWithValue(error.response.status);
        }
    });

    export const getLatestLegalContactsByProfile: any = createAsyncThunk<LegalContractsResponse, LegalContactsRequest>(
        'legalContracts/getLatestLegalContactsByProfile',
        async ({type, profile}, thunkAPI) => {
            try {
                const response = await axiosInstance.get(`/legal-document/${type}/${profile}/active`);            
                  
                return {
                    content: response.data.data.content,
                    documentType: response.data.data.documentType,
                    version: response.data.data.version,
                    statusCode: response.status,
                    profile: response.data.data.profile
                };
    
                
            } catch (error: any) {
                return thunkAPI.rejectWithValue(error.response.status);
            }
        });

    const LegalContractsSlice = createSlice({
        name: 'LegalContactsSlice',
        initialState,
        reducers: {},
        extraReducers: (builder) => {
            builder
                .addCase(getLatestLegalContacts.pending, (state) => {
                    state.loading = true;
                    state.error = null;
                })
                .addCase(getLatestLegalContacts.fulfilled, (state, action: PayloadAction<LegalContractsResponse>) => {
                    state.loading = false;
                    const type = action.payload.documentType;
                    if (type === TERMS_CONDITIONS_DOCUMENT_TYPE) {
                        if (action.payload.profile?.toLowerCase() == PROFILE.LEARNER){
                            state.learnerTermsAndConditions = action.payload.content;
                        } else if (action.payload.profile?.toLowerCase() === PROFILE.EXPERT) {
                            state.expertTermsAndConditions = action.payload.content;
                        }
                    } else if (type === PRIVACY_POLICY_DOCUMENT_TYPE) {
                        state.privacy = action.payload.content;
                    } else {
                        state.cookies = action.payload.content;
                    } 
                })
                .addCase(getLatestLegalContacts.rejected, (state) => {
                    state.loading = false;
                    state.error = 'An error occurred while fetching legal contracts';
                })
                .addCase(getLatestLegalContactsByProfile.pending, (state) => {
                    state.loading = true;
                    state.error = null;
                })
                .addCase(getLatestLegalContactsByProfile.fulfilled, (state, action: PayloadAction<LegalContractsResponse>) => {
                    state.loading = false;
                    const type = action.payload.documentType;
                    if (type === TERMS_CONDITIONS_DOCUMENT_TYPE) {
                        if (action.payload.profile?.toLowerCase() == PROFILE.LEARNER){
                            state.learnerTermsAndConditions = action.payload.content;
                        } else if (action.payload.profile?.toLowerCase() === PROFILE.EXPERT) {
                            state.expertTermsAndConditions = action.payload.content;
                        }
                    } else if (type === PRIVACY_POLICY_DOCUMENT_TYPE) {
                        state.privacy = action.payload.content;
                    } else {
                        state.cookies = action.payload.content;
                    } 
                })
                .addCase(getLatestLegalContactsByProfile.rejected, (state) => {
                    state.loading = false;
                    state.error = 'An error occurred while fetching legal contracts';
                })
            }
        }
);

export default LegalContractsSlice.reducer;