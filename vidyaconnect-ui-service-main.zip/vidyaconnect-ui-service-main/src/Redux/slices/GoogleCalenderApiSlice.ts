import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axiosInstance from "../../api/axios";


interface CalendarState {
  isConnected: any;
  toogle: any;
  loading: boolean;
  error: string | null;
}

const initialState: CalendarState = {
  isConnected: false,
  toogle: false,
  loading: false,
  error: null,
};

// Create async thunk for checking integration
export const checkIntegration = createAsyncThunk(
  "calendar/checkIntegration",
  async (_, thunkAPI) => {
    try {
      const response = await axiosInstance.get(
        "/google-calendar/check-integration"
      );
      return response.data.data;
    } catch (error: any) {
      return thunkAPI.rejectWithValue(error.message);
    }
  }
);

export const calendarAuthorization = createAsyncThunk(
  "calendar/calendarAuthorization",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.get("/google-calendar/authorize");

      return response.data.data;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

export const calendarCallback = createAsyncThunk(
  "calendar/calendarCallback",
  async ({ code }:{code : string}, { rejectWithValue, dispatch }) => {
    try {
      const response = await axiosInstance.get(
        `/google-calendar/callback?code=${code}`
      );
      dispatch(checkIntegration());
      return response.data.data;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Create async thunk for checking integration

export const deleteGoogleCalendarIntegration = createAsyncThunk(
  "calendar/deleteGoogleCalendarIntegration",
  async (_, thunkAPI) => {
    try {
      const response = await axiosInstance.delete(
        "/google-calendar/disconnect"
      );
      return response.data.data;
    } catch (error: any) {
      return thunkAPI.rejectWithValue(error.message);
    }
  }
);

// Create async thunk for enabling/disabling auto-save
export const googleCalendarConnectedStatus = createAsyncThunk(
  "calendar/googleCalendarConnectedStatus",
  async (_, thunkAPI) => {
    try {
      const response = await axiosInstance.get("/calendar/settings");
      return response.data.data.calendarAutoSave;
    } catch (error: any) {
      return thunkAPI.rejectWithValue(error.message);
    }
  }
);

// Create async thunk for updating calendar auto-save status
export const calendarAutoSaveStatusUpdate = createAsyncThunk(
  "calendar/calendarAutoSaveStatusUpdate",
  async (status: boolean, thunkAPI) => {
    try {
      const response = await axiosInstance.put("/calendar/settings", {
        calendarAutoSave: status,
      });

      return response.data.data.calendarAutoSave;
    } catch (error: any) {
      return thunkAPI.rejectWithValue(error.message);
    }
  }
);

// Create slice
const googleCalendarSlice = createSlice({
  name: "calendar",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(checkIntegration.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(checkIntegration.fulfilled, (state, action) => {
        state.isConnected = action.payload;
        state.loading = false;
      })
      .addCase(checkIntegration.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(googleCalendarConnectedStatus.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(googleCalendarConnectedStatus.fulfilled, (state, action) => {
        state.toogle = action.payload;
        state.loading = false;
      })
      .addCase(googleCalendarConnectedStatus.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(calendarAutoSaveStatusUpdate.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(calendarAutoSaveStatusUpdate.fulfilled, (state, action) => {
        state.toogle = action.payload;
        state.loading = false;
      })
      .addCase(calendarAutoSaveStatusUpdate.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default googleCalendarSlice.reducer;
