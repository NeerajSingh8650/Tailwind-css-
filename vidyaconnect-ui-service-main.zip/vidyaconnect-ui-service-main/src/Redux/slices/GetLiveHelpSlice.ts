import axiosInstance from '@/api/axios'
import { PAGE_SIZE, START_PAGE } from '@/constants'
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import type { PayloadAction } from '@reduxjs/toolkit'
import { toast } from 'react-toastify'


export interface Skill {
    name: string,
    id: number
}

interface MatchedExpertsRequest {
    skillIds: number[]
    page: number,
    size: number
}

interface MatchedExpertsResponse {
    statusCode: number,
    expertsData: ExpertData[]
}

export interface ExpertData {
    id: number,
    name: string,
    sessions: number,
    ratings: number,
    bucket: string,
    picUrl: string
}

export interface GetLiveHelpState {
    title: string,
    description: string,
    skills: Skill[],
    bucket: string,
    nameFilter: string,
    expertsData: ExpertData[]
    loading: boolean,
    error: string | null
}


const initialState: GetLiveHelpState = {
    title: "",
    description: "",
    skills: [],
    bucket: "",
    nameFilter: "",
    expertsData: [],
    loading: false,
    error: null
}

export const GetLiveHelpSlice = createSlice({
    name: 'getlivehelp',
    initialState,
    reducers: {
        titleUpdate: (state, action: PayloadAction<string>) => {
            state.title = action.payload
        },
        descriptionUpdate: (state, action: PayloadAction<string>) => {
            state.description = action.payload
        },
        skillUpdate: (state, action: PayloadAction<Skill[]>) => {
            state.skills = action.payload
        },
        bucketUpdate: (state, action: PayloadAction<any>) => {
            state.bucket = action.payload
        },
        nameFilterUpdate: (state, action: PayloadAction<string>) => {
            state.nameFilter = action.payload
        },
        expertsDataUpdate: (state, action: PayloadAction<ExpertData[]>) => {
            state.expertsData = action.payload
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(getMatchedExperts.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(getMatchedExperts.fulfilled, (state, action: PayloadAction<MatchedExpertsResponse>) => {
                state.loading = false;
                state.expertsData = action.payload.expertsData;
            })
            .addCase(getMatchedExperts.rejected, (state, action: PayloadAction<string | null>) => {
                state.loading = false;
                state.error = action.payload
            })
    },
})

export const getMatchedExperts: any = createAsyncThunk<MatchedExpertsResponse, MatchedExpertsRequest>(
    'getLiveHelp/selectExpert',
    async ({skillIds}, thunkAPI) => {
        try {
            const response = await axiosInstance.post('/request/experts', {
                skillIds: skillIds,
                page: START_PAGE,
                size: PAGE_SIZE
            });
            return {  
                expertsData: response.data.data.experts,
                statusCode: response.status
            };


        } catch (error: any) {
            const message = error.response?.data?.error?.message || "Error getting experts for the request";
            if (error.response && error.response.status === 400) {
                toast.error(message);
            }
            return thunkAPI.rejectWithValue({
                status: error.response?.status || 500,
                message
            });
        }
    }
);


export const { titleUpdate, descriptionUpdate, skillUpdate, nameFilterUpdate, bucketUpdate, expertsDataUpdate } = GetLiveHelpSlice.actions
export default GetLiveHelpSlice.reducer