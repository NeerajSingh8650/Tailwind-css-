import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import axiosInstance from '../../api/axios';
import { toast } from 'react-toastify';

interface ProfileState {
    profilePicture: string | null;
    userData: any;
    loading: boolean;
    error: string | null;
}

const initialState: ProfileState = {
    profilePicture: null,
    userData: null,
    loading: false,
    error: null,
};

export const fetchProfilePicture = createAsyncThunk(
    'Profile/fetchProfilePicture',
    async (_, thunkAPI) => {
        try {
            const response = await axiosInstance.get('/profile-picture');
            return response.data.data.profilePicUrl;
        } catch (error: any) {
            return thunkAPI.rejectWithValue(error.message);
        }
    }
);

export const postProfilePicture = createAsyncThunk(
    'Profile/postProfilePicture',
    async (event: React.ChangeEvent<HTMLInputElement>, thunkAPI) => {
        const file = event.target.files?.[0];
        if (file) {
            const formData = new FormData();
            formData.append('file', file);
            try {
                const response = await axiosInstance.post('profile-picture', formData, {
                    headers: {
                        'Content-Type': 'multipart/form-data',
                    },
                });
                if (response.status === 200) {
                    thunkAPI.dispatch(fetchProfilePicture());
                    toast.success("Profile picture changed Succesfully")
                }
            } catch (error: any) {
                toast.error("something went wrong")
                return thunkAPI.rejectWithValue(error.message);
            }
        } else {
            return thunkAPI.rejectWithValue('No file selected');
        }
    }
);

export const fetchUserData = createAsyncThunk(
    'Profile/fetchUserData',
    async (_, thunkAPI) => {
        try {
            const response = await axiosInstance.get('/expert');
            return response.data.data;
        } catch (error: any) {
            return thunkAPI.rejectWithValue(error.message);
        }
    }
);

export const ProfilePicSlice = createSlice({
    name: 'Profile',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(fetchProfilePicture.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchProfilePicture.fulfilled, (state, action: PayloadAction<string>) => {
                state.loading = false;
                state.profilePicture = action.payload;
            })
            .addCase(postProfilePicture.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchUserData.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchUserData.fulfilled, (state, action: PayloadAction<any>) => {
                state.loading = false;
                state.userData = action.payload;
            })
    },
});

export default ProfilePicSlice.reducer;
