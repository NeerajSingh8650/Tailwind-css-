import axiosInstance from "@/api/axios";
import { PayloadAction, createAsyncThunk, createSlice } from "@reduxjs/toolkit";

export interface DomainDetails {
    id: number,
    name: string,
    goldBucket: number,
    silverBucket: number,
    platinumBucket: number,
} 

export interface DomainState {
    domain: DomainDetails,
    domains: DomainDetails[]
    loading: boolean,
    error: string | null
} 

const initialState: DomainState = {
    domain : {
        id: 0,
        name: '',
        goldBucket: 0,
        silverBucket: 0,
        platinumBucket: 0
    },
    domains: [],
    loading : false,
    error: null
};

interface DomainRequest {
    skillIds: number[]
}

interface DomainResponse {
    data: DomainDetails,
    statusCode: number
}

interface AllDomainResponse {
    data: DomainDetails[]
    statusCode: number
}

export const fetchDomainDetails: any = createAsyncThunk<DomainResponse, DomainRequest>(
    'GetLiveHelp/fetchDomainDetails',
    async ({skillIds}, thunkAPI) => {
        try {
            const response = await axiosInstance.post('/request/domain',
                {
                    skillIds: skillIds
                }
            );
            return {
                data: response.data.data,
                statusCode: response.status
            }
        } catch (error: any) {
            return thunkAPI.rejectWithValue(error.message);
        }
    }
);

// Async thunk for fetching domains
export const fetchAllDomains: any = createAsyncThunk<AllDomainResponse, void>(
    'ExpertExploreApi/fetchDomains',
    async (_, thunkAPI) => {
        try {
            const response = await axiosInstance.get('/domain');
            return {
                data: response.data.data,
                statusCode: response.status
            }
        } catch (error: any) {
            return thunkAPI.rejectWithValue(error.message);
        }
    }
);

const DomainsSlice = createSlice({
    name: 'DomainApi',
    initialState,
    reducers: {
        domainIdUpdate: (state, action: PayloadAction<number>) => {
            console.log("domainId", action.payload)
            state.domain.id = action.payload
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchDomainDetails.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchDomainDetails.fulfilled, (state, action: PayloadAction<DomainResponse>) => {
                state.loading = false;
                state.domain = action.payload.data;
            })
            .addCase(fetchDomainDetails.rejected, (state, action: PayloadAction<string | null>) => {
                state.loading = false;
                state.error = action.payload ?? 'An error occurred while fetching domain details';
            })
            .addCase(fetchAllDomains.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchAllDomains.fulfilled, (state, action: PayloadAction<AllDomainResponse>) => {
                state.loading = false;
                state.domains = action.payload.data;
            })
            .addCase(fetchAllDomains.rejected, (state, action: PayloadAction<string | null>) => {
                state.loading = false;
                state.error = action.payload ?? 'An error occurred while fetching domains';
            });
    },
});

export const {domainIdUpdate} = DomainsSlice.actions;

export default DomainsSlice.reducer;

