import { createAsyncThunk, createSlice, PayloadAction } from "@reduxjs/toolkit";
import axiosInstance from "../../api/axios";
import { COOKIES, removeCookies, setCookie } from "../../config/sessionHelper";
import { toast } from "react-toastify";
import { PROFILE } from "@/constants";
import { setLoggedIn } from "./userSlice";

interface stateInterface {
  userDetails: object;
  error: any;
  loading: boolean;
  showVerificationModal: boolean;
  passwordVerificationModal: boolean;
  loggedOut: boolean;
  isResetPasswordModal: boolean
  isSuccessPasswordModal: boolean
  isSigninModal: boolean
  isSigninOptionsModal: boolean;
  isSignUpModal: boolean;
}


const initialState: stateInterface = {
  userDetails: {},
  error: "",
  loading: false,
  showVerificationModal: false,
  passwordVerificationModal: false,
  loggedOut: false,
  isResetPasswordModal: false,
  isSuccessPasswordModal: false,
  isSigninModal: false,
  isSigninOptionsModal: false,
  isSignUpModal: false
};

export const loginWithEmail = createAsyncThunk(
  "auth/loginWithEmail",
  async (
    {
      email,
      password,
      navigate,
      onSignInSuccess,
    }: { email: string; password: string; navigate: any, onSignInSuccess: () => void },
    { rejectWithValue, dispatch }
  ) => {
    try {
      const { data } = await axiosInstance.post(`/auth/login`, {
        email,
        password,
      });
      setCookie(COOKIES.USER_INFO, data.data);
      sessionStorage.setItem("isLoggedIn", "true");
      dispatch(setLoggedIn(true));
      if (data?.data?.onboardingCompleted) {
        toast.success("Signed in successfully!");
        if (data?.data?.profile[0]?.toLowerCase() === PROFILE.EXPERT) {
          navigate("/dashboard/expert-home");
        } else {
          navigate("/explore-experts");
        }
      } else {
        toast.success("Signed in successful!");
        navigate("/onboarding");
      }
      onSignInSuccess();
    } catch (error: any) {
      const { status, data } = error.response || { status: 0, data: null };
      return rejectWithValue({
        statusCode: status,
        apiResponse: data.error.message,
      });
    }
  }
);

export const fetchUserProfile = createAsyncThunk(
  "auth/fetchUserProfile",
  async (_args, { rejectWithValue }) => {
    try {
      const { data } = await axiosInstance.get(`/tenant/profile`);
      return data?.data;
    } catch (error: any) {
      const { status, data } = error.response || { status: 0, data: null };
      toast.error(data.error.message);
      return rejectWithValue({
        statusCode: status,
        apiResponse: data.error.message,
      });
    }
  }
);

export const logout = createAsyncThunk(
  "auth/logout", async (_args, { rejectWithValue }) => {
    try {
      const { data } = await axiosInstance.post(`/auth/logout`);
      return data?.data;
    } catch (error: any) {
      const { status, data } = error.response || { status: 0, data: null };
      toast.error(data.error.message);
      return rejectWithValue({
        statusCode: status,
        apiResponse: data.error.message,
      });
    }
  }
)

export const signupWithEmail = createAsyncThunk(
  "auth/signupWithEmail",
  async (args: any, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.post(`/signup`, args);
      toast.success(
        "Please check your email; we have sent a verification link!"
      );
      return response;
    } catch (error: any) {
      const { status, data } = error.response || { status: 0, data: null };
      toast.error(data?.error.message);
      return rejectWithValue({
        statusCode: status,
        apiResponse: data?.error.message || "Error signing up",
      });
    }
  }
);

export const forgotPassword = createAsyncThunk(
  "/forgot-password",
  async (args: { email: string }, { rejectWithValue }) => {
    try {
      const emailEncoded = encodeURIComponent(args.email);
      const response = await axiosInstance.get(`/tenant/${emailEncoded}/forgot-password`);
      toast.success('Please check your email; we have sent a verification link!');
      return response;
    } catch (error: any) {
      const { status, data } = error.response || { status: 0, data: null };
      toast.error(data.error.message);
      return rejectWithValue({
        statusCode: status,
        apiResponse: data.error.message
      });
    }
  }
);

export const logoutUser = createAsyncThunk(
  "auth/logoutUser",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.post(`/auth/logout`);
      localStorage.clear();
      sessionStorage.clear();
      removeCookies();
      window.location.reload();
      return response;
    } catch (error: any) {
      const { status, data } = error.response || { status: 0, data: null };
      toast.error(data.error.message);
      return rejectWithValue({
        statusCode: status,
        apiResponse: data.error.message,
      });
    }
  }
);

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    closeModal: (state) => {
      state.showVerificationModal = false;
      state.passwordVerificationModal = false;
    },
    clearError: (state) => {
      state.error = null;
    },
    setIsResetPasswordModal: (state, action) => {
      state.isResetPasswordModal = action.payload
    },
    setisSuccessPasswordModal: (state, action) => {
      state.isSuccessPasswordModal = action.payload
    },
    setIsSigninModal: (state, action) => {
      state.isSigninModal = action.payload
    },
    setisSigninOptionsModal: (state, action) => {
      state.isSigninOptionsModal = action.payload
    },
    setIsSignUpModal: (state, action: PayloadAction<boolean>) => {
      state.isSignUpModal = action.payload
    }
  },
  extraReducers: (builder) =>
    builder
      .addCase(loginWithEmail.pending, (state, { }) => {
        state.loading = true;
      })
      .addCase(loginWithEmail.fulfilled, (state) => {
        state.loading = false;
        state.error = null;
      })
      .addCase(loginWithEmail.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      })
      .addCase(signupWithEmail.pending, (state, { }) => {
        state.loading = true;
      })
      .addCase(signupWithEmail.fulfilled, (state) => {
        state.showVerificationModal = true;
        state.loading = false;
      })
      .addCase(signupWithEmail.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      })
      .addCase(forgotPassword.fulfilled, (state) => {
        state.passwordVerificationModal = true;
        state.loading = false;
      })
      .addCase(fetchUserProfile.pending, (state, { }) => {
        state.loading = true;
      })
      .addCase(fetchUserProfile.fulfilled, (state, action) => {
        state.showVerificationModal = true;
        state.userDetails = action.payload;
      })
      .addCase(fetchUserProfile.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      })
      .addCase(logout.pending, (state) => {
        state.loading = true;
        state.loggedOut = false
      })
      .addCase(logout.fulfilled, (state) => {
        state.loading = false;
        state.loggedOut = true;
      })
      .addCase(logout.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
        state.loggedOut = false;
      }),
});
export const { closeModal, clearError, setIsResetPasswordModal, setisSuccessPasswordModal, setIsSigninModal, setisSigninOptionsModal, setIsSignUpModal } = authSlice.actions;
export default authSlice.reducer;
