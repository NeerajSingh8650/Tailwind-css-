import './CircularProgressBar.css'

type Props = {
  percentage: number,
  skillName: string,
}

function CircularProgressBar({ percentage, skillName }: Props) {
  return (
    <div className='flex flex-col  justify-center items-center gap-2'>
      <div style={{ background: `conic-gradient(#09A5D6 ${percentage*3.6*100}deg, #ffff 0deg )` }} className='outer w-20 rounded-[50%] h-20 flex items-center justify-center'>
        <div className='h-16 w-16 rounded-[50%] text-[20px] flex items-center bg-white justify-center'>{percentage * 100}%</div>
      </div>
      <p className='text-[16px]'>{skillName}</p>
    </div>

  )
}

export default CircularProgressBar