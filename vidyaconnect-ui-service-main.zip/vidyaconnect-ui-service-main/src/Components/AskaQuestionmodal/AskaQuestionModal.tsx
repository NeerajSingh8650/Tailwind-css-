import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/Components/ui/select";
import { Button } from "@/shadcn/ui/button";
import { Textarea } from "../ui/textarea";
import { Label } from "../ui/label";
import { useEffect, useState } from "react";
import { X } from "lucide-react";
import { useDispatch, useSelector } from "react-redux";
import { fetchTicketCategories, fetchTickets } from "@/Redux/slices/TicketSlice";
import { AppDispatch, RootState } from "@/Redux/store/store";

interface AskaQuestionModalProps {
    onClose: () => void; // Prop type for the onClose function
    concern?: string
}

function AskaQuestionModal({ onClose, concern }: AskaQuestionModalProps) {
    const [submitFlag, setSubmitFlag] = useState<boolean>(false);
    const [othersFlag, setOthersFlag] = useState<boolean>(false);
    const [value, setValue] = useState<string>("Choose Your concern"); // Set default value here
    const [textValue, setTextValue] = useState<string>("");
    const [categoryId, setCategoryId] = useState<number>(0);
    const ticket = useSelector((state: RootState) => state.ticket.categories)
    const dispatch: AppDispatch = useDispatch()

    useEffect(() => {
        if (value === "" || value.toUpperCase() === "OTHER") {
            setSubmitFlag(false);
            if (textValue === "") {
                setOthersFlag(false);
            } else {
                setOthersFlag(true);
                setSubmitFlag(true);
            }
        } else {
            setSubmitFlag(true);
            setOthersFlag(true);
        }
    }, [value, textValue]);

    useEffect(() => {
        if (concern) {
            setValue(concern)
        }
        dispatch(fetchTicketCategories())
    }, [])

    return (
        <div className="fixed z-50 h-screen w-screen bg-black/30 top-0 left-0 flex items-center justify-center">
            <div className={`relative w-[578px] ${value.toLocaleUpperCase() === "OTHER" ? "h-[486px]" : "h-[341px]"}  rounded-lg overflow-hidden bg-white`}>
                <X
                    className="absolute right-5 top-5 cursor-pointer text-graymod-textfour"
                    onClick={onClose} 
                />
                <div className='h-[71px] rounded-lg bg-graymod text-[24px] font-semibold w-full flex items-center justify-center'>
                    Ask a Question
                </div>
                <div className="px-[30px] ">
                    <p className="mt-6 mb-4 ml-1">How can we help you?</p>

                    <Select onValueChange={(e: string) => setValue(e)}>
                        <SelectTrigger className="min-w-[500px]">
                            <SelectValue placeholder={concern ? concern :"Choose your concern"} />
                        </SelectTrigger>
                        <SelectContent>
                            {
                                ticket.map((data: any) => (
                                    <SelectItem key={data.categoryId} onClick={() => setCategoryId(data.categoryId)} value={data.category}>
                                        {data.category}
                                    </SelectItem>
                                ))
                            }
                        </SelectContent>
                    </Select>
                    {value.toUpperCase() === "OTHER" && (
                        <div className="gap-1.5 ml-1 mt-3 text-graymod-textfive">
                            <Label htmlFor="message">State your concern</Label>
                            <Textarea
                                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setTextValue(e.target.value)}
                                rows={4}
                                placeholder="Please include as much info as possible..."
                                id="message"
                            />
                        </div>
                    )}
                    <p className="ml-1 text-[12px] mt-3">
                        Visit our <span className="text-cyanmod">Help</span> desk for more <span className="text-cyanmod">FAQs</span>, that might help you with your concern.
                    </p>
                    <div className="absolute bottom-12 right-5 flex justify-end items-center gap-3 px-3 ">
                        <Button variant={"outline"} onClick={onClose}>Cancel</Button>
                        {submitFlag && othersFlag ? (
                            <Button onClick={() => {
                                dispatch(fetchTickets({ categoryId, value })).then(()=>{
                                    onClose()
                                })
                            }}>Submit</Button>
                        ) : (
                            <Button variant={"disabled"}>Submit</Button>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}

export default AskaQuestionModal;
