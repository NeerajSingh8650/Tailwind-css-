import "./Footer.css";
import linkedin from "../../assets/linke.png";
import fb from "../../assets/fb.png";
import insta from "../../assets/insta.png";
import { PRODUCT_NAME, COMPANY_NAME, SUPPORT_EMAIL } from "../../constants";
import logo from "../../assets/sagenest_logo.svg";

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <div className="footer py-[8px] bg-[#002834] text-white">     

 <div className="flex md:flex-row flex-col justify-between mx-8 xl:mx-20 mb-12 mt-8 md:text-left text-center">
          <div className="md:ps-9 ps-0 lg:ps-0 md:basis-[30%] basis-[100%]">
            <img
              src={logo}
              alt={`${PRODUCT_NAME} Logo`}
              className="w-[170px] h-[auto] bg-none mb-2 m-[auto] md:mx-0"
            />
            <p className="font-normal text-[#cbcbcb]">Made in India for the World!</p>            
          </div>

         <div className="relative md:basis-[65%] lg:basis-[49%] basis-[100%]">
           
                <div className="md:h-[40px] h-[auto]"> 
                  <div className="relative">
                    <div className="md:absolute relative right-0 flex md:text-right text-center justify-center md:gap-0 gap-10 md:py-0 py-5">
                          <a
                          href="https://www.linkedin.com/company/sagenest/"
                          target="_blank"
                          className="md:mr-[20px] mr-[0px]"
                          >
                            <img src={linkedin} alt="" />
                          </a>
                        <a href="" target="_blank" className="md:mr-[20px] mr-[0px]">
                            <img src={insta} alt="" />
                          </a>
                
                          <a href="" target="_blank" className="md:mr-[20px] mr-[0px]">
                            <img src={fb} alt="" />
                          </a>
                
                    </div>
                  </div>            
                </div>

                <div className="w-[100%] h-[auto] flex md:flex-row flex-wrap md:gap-0 gap-2 justify-between items-center md:text-right text-centermm list-menu" >
                        <a href="/help" className="text-[#cbcbcb]">
                          Help 
                        </a> 
                        <a href="/terms" className="text-[#cbcbcb]">
                          Terms and Conditions
                        </a>  
                        <a href="/privacy" className="text-[#cbcbcb]">
                          Privacy Policy
                        </a>  
                       <a href="mailto:contact@glofluent.com" className="text-[#cbcbcb]">
                         {SUPPORT_EMAIL}
                      </a>            
                </div>
         </div>

      </div>


      <p className="bg-white flex flex-wrap w-full text-[#002834] text-center justify-center items-center py-3 text-[16px] font-normal absolute px-3">
         Copyright © {currentYear} {COMPANY_NAME} All rights reserved
      </p>
    </div>
  );
};

export default Footer;
