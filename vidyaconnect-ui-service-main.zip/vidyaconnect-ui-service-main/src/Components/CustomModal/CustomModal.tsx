import { Button } from "@/shadcn/ui/button";
import { ReactNode } from "react";
import CloseIcon from '../../assets/close.svg';
import BackIcon from '../../assets/back.svg';

interface modalProps {
    title : string;
    child: ReactNode;
    onClose: () => void;
    isCta : boolean;
    hasBackButton: boolean;
    onPress?: () => void;
    buttonText?: string;
    secondButtonText? : string;
    onSecondButtonPress?: () => void;
    onBackPress?: () => void
}

const CustomModal = ({title, child, buttonText, secondButtonText, isCta, onClose, onPress, onSecondButtonPress, onBackPress, hasBackButton} : modalProps) => {
    return (
        <div id="default-modal" aria-hidden="true" className="overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center flex items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full">
            <div className="relative p-4 w-full max-w-2xl max-h-full">
                <div className="relative bg-white rounded-lg shadow dark:bg-gray-700">
                    <div className="flex items-center justify-between p-4 border-b rounded-t dark:border-gray-600">
                        <div className="w-8"></div>
                        <h3 className="text-[22px] font-semibold text-gray-900 dark:text-white">
                            {hasBackButton && 
                                <button type="button" onClick={() => onBackPress && onBackPress()} className="text-gray-400 bg-transparent hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white" data-modal-hide="default-modal">
                                    <img 
                                            src={BackIcon}
                                    />
                                </button>
                            }
                            {title}
                        </h3>
                        <button type="button"onClick={() => onClose()} className="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white" data-modal-hide="default-modal">
                            <img 
                                src={CloseIcon}
                           />
                        </button>
                    </div>
                    <div className="px-4 py-6 space-y-4">
                        {child}
                    </div>
                    {isCta && 
                        <div className="flex items-center justify-end p-4 md:p-5 border-t border-gray-200 rounded-b gap-2 dark:border-gray-600">
                            {secondButtonText && secondButtonText.trim() != ''?
                                <Button onClick={() => onSecondButtonPress && onSecondButtonPress()}>{secondButtonText}</Button>
                            :
                                null
                            }
                            <Button onClick={() => onPress && onPress()} variant={'outline'}>{buttonText}</Button>
                        </div>
                    }
                </div>
            </div>
        </div>
    );
};

export default CustomModal;