import React from 'react';
import { Button } from '@/shadcn/ui/button';

interface RejectModuleProps {
  onCancel: () => void;
  onConfirm: () => void;
  heading: string;
}

const ExpertRejectSessionPopUp: React.FC<RejectModuleProps> = ({ onCancel, onConfirm, heading }) => {
  return (
    <div className='fixed flex justify-center w-[100vw] top-0 left-0 items-center bg-[#00000030] mx-auto h-[100vh] z-10'>
      <div className='w-[314px] h-[176px] p-5 flex items-center justify-center flex-col gap-7 rounded-xl bg-white'>
        <h2 className='text-[20px] text-center'>
        {heading}
        </h2>
        <div className='flex gap-2'>
          <Button
            variant={"outline"}
            onClick={onCancel}
          >
            Cancel
          </Button>
          <Button
            onClick={onConfirm}
          >
            Confirm
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ExpertRejectSessionPopUp;
