import React, { useEffect, useState, useRef } from "react";
import { FaAngleLeft, FaAngleRight } from "react-icons/fa6";
import "./LearnerBookSessionsModal.css";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../Redux/store/store";
import { selectedSlotUpdate } from "../../Redux/slices/ExpertsDataSlice";
import {
  bookingSessionModalFlagUpdate,
  bookSessionResponseModalUpdate,
  ExploreBookSessionModalUpdate,
} from "../../Redux/slices/FlagsSLice";
import {
  fetchAvailability,
  bookSession
} from "../../Redux/slices/ExpertExporeApiSlice";
import close from "../../assets/close.svg";
import arrowLeft from "../../assets/arrow-left.png";
import { Button } from "@/shadcn/ui/button";
import TimePicker from "../TimePicker/TimePicker";
import LoadingComponent from "../LoadingComponent";
import { TimeSlot } from "@/Redux/slices/ExpertSlice";

interface Props {
  openFrom: string;
  domainId: number
}

const months: { [key: number]: string } = {
  1: "Jan",
  2: "Feb",
  3: "Mar",
  4: "Apr",
  5: "May",
  6: "Jun",
  7: "Jul",
  8: "Aug",
  9: "Sep",
  10: "Oct",
  11: "Nov",
  12: "Dec",
};

const LearnerBookSessionsModal: React.FC<Props> = ({
  openFrom,
  domainId
}) => {
  const [bookFlag, setBookFlag] = useState<boolean>(false);
  const [leftArrowFlag, setLeftArrowFlag] = useState<boolean>(true);
  const [rightArrowFlag, setRightArrowFlag] = useState<boolean>(false);
  const [bookData, setBookData] = useState<string>("");
  const [selectedSlot, setSelectedSlot] = useState<string>("");
  const expertId = useSelector((state: RootState) => state.expertData.id);
  const sessionDetails = useSelector((state: RootState) => state.getHelp);
  const dispatch = useDispatch();
  const timeDataSelector = useSelector(
    (state: RootState) => state.expertExploreApi.timeData.availability
  );
  const loading = useSelector((state: RootState) => state.expertExploreApi.loading);
  const bucket = useSelector((state: RootState) => state.getHelp.bucket);
  const numberInputRef = useRef<HTMLInputElement>(null);
  const [min, setMin] = useState<string>("");
  const [i, setI] = useState<number>(0);
  const [slotError, setSlotError] = useState<string>("");
  const [isSlotSelected, setIsSlotSelected] = useState<number>();
  const [startTime, setStarttime] = useState<string>("");
  const [bookButtonDisable, setBookButtonDisable] = useState(true);
  const [slotDuration, setSlotDuration] = useState<number>(0);
  const [toggleSlot, setToggleSlot] = useState<number | null>(null);

  useEffect(() => {
    if (bookFlag && startTime != "" && min != "") {
      setBookButtonDisable(false);
    } else {
      setBookButtonDisable(true);
    }
  }, [bookFlag, min]);

  useEffect(() => {
    if (!bookFlag) {
      setIsSlotSelected(-1);
    }
  }, [bookFlag]);

  useEffect(() => {
    const [startTime, endTime] = selectedSlot.split("-");
    const startDate = new Date(`1970-01-01T${startTime}:00Z`);
    const endDate = new Date(`1970-01-01T${endTime}:00Z`);
    const diffInMilliseconds = endDate.getTime() - startDate.getTime();
    const diffInMinutes = diffInMilliseconds / (1000 * 60);

    setMin(String(diffInMinutes));
  }, [isSlotSelected]);

  function convertToIsoFormatWithMillis(
    dateString: string,
    timeString: string,
    millis: number = 0
  ): string {
    const [year, month, day] = dateString.split("-").map(Number);
    const [hours, minutes] = timeString.split(":").map(Number);
    const date = new Date(
      Date.UTC(year, month - 1, day, hours, minutes, 0, millis)
    );
    const isoString = date.toISOString();
    return isoString;
  }

  const onLeftClick = () => {
    setIsSlotSelected(-1);
    setBookFlag(false);
    if (i <= 0) {
      setI(0);
      setLeftArrowFlag(true);
    } else {
      setI((prev) => prev - 1);
      setLeftArrowFlag(false);
      setRightArrowFlag(false);
    }
  };

  const onRightClick = () => {
    setIsSlotSelected(-1);
    setBookFlag(false);
    if (i >= timeDataSelector.length - 1) {
      setI(timeDataSelector.length - 1);
      setRightArrowFlag(true);
    } else {
      setI((prev) => prev + 1);
      setRightArrowFlag(false);
      setLeftArrowFlag(false);
    }
  };

  const onClose = () => {
    dispatch(bookingSessionModalFlagUpdate(false));
  }

  const handleClick = (e: React.MouseEvent<HTMLElement>, index: number) => {
    if (index == toggleSlot) {
      setBookFlag((prev) => !prev);
    } else {
      setBookFlag(true);
    }
    setToggleSlot(index);

    const target = e.target as HTMLElement;
    if (bookData === e.currentTarget.innerText) {
      target.classList.add("border-cyanmod");
    }
  };

  useEffect(() => {
    dispatch(fetchAvailability(expertId));
  }, [dispatch, expertId]);

  const convertToUtc = (localTime: string) => {
    const [hours, minutes] = localTime.split(":").map(Number);
    const localDate = new Date();
    localDate.setHours(hours);
    localDate.setMinutes(minutes);
    const utcHours = localDate.getUTCHours();
    const utcMinutes = localDate.getUTCMinutes();
    return `${String(utcHours).padStart(2, "0")}:${String(utcMinutes).padStart(
      2,
      "0"
    )}`;
  };

  const handleBookSession = () => {
    if (min == "" || Number(min) < 5) {
      setSlotError("Minutes cannot be less than 5");
    } else {
      if (Number(min) > slotDuration) {
        setSlotError("Session duration cannot exceed slot end time.");
      } else {
        const timeInUtc = convertToUtc(startTime);
        const dateData = convertToIsoFormatWithMillis(
          timeDataSelector[i].date,
          timeInUtc,
          0
        );
        dispatch(
          bookSession({
            expertId,
            sessionDetails,
            dateData,
            min,
            bucket,
            domainId
          })
        );
        dispatch(ExploreBookSessionModalUpdate(false))
        dispatch(bookingSessionModalFlagUpdate(false));
        dispatch(bookSessionResponseModalUpdate(true));
      }
    }
  };

  const handleTimeChange = (newTime: string) => {
    const startTime = newTime;
    const endTime = selectedSlot.split("-")[1];
    const startDate = new Date(`1970-01-01T${startTime}:00Z`);
    const endDate = new Date(`1970-01-01T${endTime}:00Z`);
    const diffInMilliseconds = endDate.getTime() - startDate.getTime();
    const diffInMinutes = diffInMilliseconds / (1000 * 60);
    setSlotDuration(diffInMinutes);
    setStarttime(newTime);
  };

  const date = timeDataSelector.length === 0 ? "" : timeDataSelector[i].date;

    return (
          <div className="modal-backdrop fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
            <div
              className={`book-sessions-modal w-[405px] rounded-lg flex flex-col gap-4 p-8`}
            >     
              {openFrom === "selectexpert" && (
                <div className="h-5 w-5 text-[16px] absolute right-5 top-4 text-[#00000048] cursor-pointer">
                  <img
                    src={close}
                    onClick={onClose}
                    className="cross-icon"
                    alt=""
                  />
                </div>
              )}
              {openFrom === "explore" && (
                <div className="h-5 w-6 text-[10px] absolute left-5 top-4 text-[#000] cursor-pointer">
                  <img src={arrowLeft} onClick={onClose} alt="" />
                </div>
              )}
              <h1 className="text-[20px] font-medium text-center mb-3">
                Available Slots
              </h1>

              {loading ? (
              <div className="flex justify-center items-center" style={{ minHeight: '200px' }}>
                <LoadingComponent/>
              </div>
            ) : (
              <>
              <div className="flex items-center justify-around mb-5">
                {timeDataSelector.length === 0 ? (
                  ""
                ) : (
                  <FaAngleLeft
                    className={`cursor-pointer w-[18.62px] h-[35.2px] ${
                      leftArrowFlag ? "text-gray-400" : "text-[#444]"
                    }`}
                    onClick={onLeftClick}
                  />
                )}
                <h3 className="mx-4 flex font-regular text-[18px]">
                  <p>
                    {timeDataSelector.length === 0
                      ? ""
                      : date.slice(8, 10) +
                        " " +
                        months[parseFloat(date.slice(5, 7))] +
                        " " +
                        date.slice(2, 4) +
                        ", " +
                        timeDataSelector[i].day}
                  </p>
                </h3>
                {timeDataSelector.length === 0 ? (
                  ""
                ) : (
                  <FaAngleRight
                    className={`cursor-pointer w-[18.62px] h-[35.2px] ${
                      rightArrowFlag ? "text-gray-400" : "text-[#444]"
                    }`}
                    onClick={onRightClick}
                  />
                )}
              </div>

              {/* Time Slot */}
              <div className="flex w-full justify-center">
                <div className="grid grid-cols-3 gap-2 justify-center w-[30rem]">
                  {timeDataSelector.length === 0 ? (
                    <h1 className="text-black text-[16px] top-[50%] left-[50%] -translate-y-[50%] -translate-x-[50%] absolute text-nowrap">
                      Sorry, no slots available.
                    </h1>
                  ) : (
                    timeDataSelector[i].slots.map((data: TimeSlot, index: any) => (
                      <div
                        onClick={(e) => {
                          const timeSlot = e.currentTarget.innerText;
                          setIsSlotSelected(index);
                          setSelectedSlot(timeSlot);
                          dispatch(selectedSlotUpdate(timeSlot));
                          handleClick(e, index);
                          setBookData(e.currentTarget.innerText);
                        }}
                        key={index}
                        className={` gap-1 font-normal justify-center items-center cursor-pointer text-[14px] rounded-lg h-auto border p-2 w-[110px] text-center
                          ${
                            selectedSlot === data.startTime
                              ? "bg-cyanmod text-white"
                              : "text-cyanmod1"
                          }
                          ${
                            isSlotSelected === index &&
                            "border-2 border-solid border-cyanmod"
                          }
                          `}
                      >
                        <p className="text-cyanmod">
                          {data.startTime}
                          -
                          {data.endTime}
                        </p>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {bookFlag && (
                <>
                  {/* Start time */}
                  <div className="flex text-[16px] justify-between items-center">
                    <label htmlFor="title">Start Time</label>
                    <TimePicker
                      selectedSlot={selectedSlot}
                      onTimeChange={handleTimeChange}
                    />
                  </div>

                  {/* No of Minutes */}
                  <div className="text-[16px]">
                    <div className="flex justify-between">
                      <label htmlFor="title">No. of Minutes</label>

                      <input
                        ref={numberInputRef}
                        type="number"
                        className="w-20 block text-[16px] border border-graymod rounded-md outline-none px-2 py-2"
                        // defaultValue={min}
                        value={min}
                        onChange={(e) => {
                          setSlotError("");
                          setMin(e.target.value);
                        }}
                      />
                    </div>
                    <p className="text-right w-[100%]">
                      {slotError != "" && (
                        <span className="text-red-600 text-xs w-[200px] inline-block">
                          {slotError}
                        </span>
                      )}
                    </p>
                  </div>
                </>
              )}

              <div className="text-center">
                <Button
                  className={`self-end mt-7 ${
                    bookButtonDisable ? "bookBtnDisable" : ""
                  }`}
                  disabled={bookButtonDisable}
                  onClick={() => {
                    if (bookFlag) {
                      handleBookSession();
                    }
                  }}
                >
                  Book
                </Button>
              </div>
              </>
            )}
            </div>
          </div>
    );
  }


export default LearnerBookSessionsModal;
