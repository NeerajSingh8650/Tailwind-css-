import { useEffect } from 'react';
import { FaCheck } from 'react-icons/fa';

function WorkProfileUpdatedSuccessFullyModal() {

    useEffect(() => {
        const handlePopState = (e: any) => {
            e.preventDefault();
            window.history.pushState(null, document.title, window.location.href); 
        };

        window.history.pushState(null, document.title, window.location.href); 
        window.addEventListener('popstate', handlePopState);

        return () => {
            window.removeEventListener('popstate', handlePopState);
        };
    }, []);

    return (
        <div className="w-screen fixed top-0 left-0 z-50 h-screen flex flex-col gap-5 justify-center items-center bg-graymod-background">
            <div className="h-20 w-20 border-4 rounded-[50%] flex items-center justify-center border-cyanmod">
                <FaCheck className=" text-[35px]  text-cyanmod" />
            </div>
            <p className='inter font-medium text-[20px]'>
                Your work profile updated successfully. You can close this tab.
            </p>
        </div>
    );
}

export default WorkProfileUpdatedSuccessFullyModal;
