import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import VerificationEmailModal from "../VerificationEmailModal/VerificationEmailModal";
import * as Yup from "yup";
import { useFormik } from "formik";
import { useDispatch, useSelector } from "react-redux";
import { clearError, signupWithEmail } from "../../Redux/slices/authSlice";
import BackIcon from "../../assets/back.svg";
import { Button } from "@/shadcn/ui/button";
import { AppDispatch } from "@/Redux/store/store";
interface SignUpEmailModalProps {
  onClose: () => void;
  onBack: () => void;
  onSignIn: () => void;
  userTypeValue: string;
}

const signupSchema = Yup.object().shape({
  email: Yup.string().email("Please enter valid email").required(),
});

const SignUpWithEmailModal: React.FC<SignUpEmailModalProps> = ({
  onClose,
  onBack,
  onSignIn,
  userTypeValue,
}) => {
  const dispatch: AppDispatch = useDispatch();
  const { error: errorSelector } = useSelector(
    (state: { auth: { error: any } }) => state.auth
  );
  const { showVerificationModal } = useSelector((state: any) => state.auth);
  const { values, handleChange, handleSubmit, errors, touched, isSubmitting } =
    useFormik({
      initialValues: {
        email: "",
        profile: userTypeValue,
      },
      validationSchema: signupSchema,
      onSubmit: (values, { resetForm }) => {
        dispatch(signupWithEmail(values));
        resetForm();
      },
    });

  const handleSignIn = () => {
    onClose();
    onSignIn();
  };

  useEffect(() => {
    dispatch(clearError())
  }, [])

  return (
    <>
      {showVerificationModal ?
        <VerificationEmailModal
          onClose={() => {onClose()}}
          onSignIn={() => onSignIn()}
        />
        :
        <div className="social-modal open w-[28rem]">
          <div className="h-5 w-5 absolute left-5 top-4 text-[#00000048] cursor-pointer">
            <img src={BackIcon} className="cross-icon" onClick={onBack} />
          </div>
          <h3 className={`font-medium text-[28px] text-center ${errorSelector ? "mb-6" : "mb-14"}`}>Sign Up</h3>
          {errorSelector && (
                <div className="mx-auto mb-4 top-[110px] error-info-sign-up w-[75%]">
                  <span className="p-2 text-red-500 text-[14px] text-center mt-6">{errorSelector.apiResponse}</span>
                </div>
              )}
          <div>
            <form onSubmit={handleSubmit}>
              <div className="mb-10">
                <h3 className="font-medium text-[18px] text-center mb-8">
                  Enter Your Email
                </h3>
                <input
                  type="text"
                  className="border border-graymod w-full font-extralight text-[16px] rounded-xl py-2 ps-3 outline-none"
                  placeholder="Enter email"
                  name="email"
                  value={values.email}
                  onChange={handleChange}
                />
                {touched.email && errors.email && (
                  <p className="text-red-400 text-l mt-1">{errors.email}</p>
                )}
              </div>
              <div className="flex justify-center">
                <Button type="submit" >
                  {isSubmitting ? "Please wait..." : "Continue"}
                </Button>
              </div>
              <p className="font-normal text-[18px] text-center mb-6 mt-[40px]">
                Already have an account?{" "}
                <Link to="" onClick={() => handleSignIn()} className="underline">
                  Sign In
                </Link>
              </p>
              <p className="font-regular text-[15px] policy text-center">
                I agree to the{" "}
                <Link to="/terms" className="underline" onClick={onClose}>
                  Terms & Conditions{" "}
                </Link>
                and{" "}
                <Link to="/policy" className="underline" onClick={onClose}>
                  Privacy Policy
                </Link>
              </p>
            </form>
          </div>
        </div>
      }
    </>
  );
};

export default SignUpWithEmailModal;
