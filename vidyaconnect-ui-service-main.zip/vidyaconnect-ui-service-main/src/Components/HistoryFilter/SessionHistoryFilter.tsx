"use client"

import React, { useEffect, useState } from 'react';
import "./sessionhistoryfilter.css";
import { filterUpdate } from "../../Redux/slices/SessionRequestSlice"
import { BOOKING_STATUS_COMPLETED } from "@/constants";
import { useDispatch } from 'react-redux';
import DownArrow from '../../assets/down_arrow.svg';

// import { DropdownMenu, DropdownMenuCheckboxItem, DropdownMenuCheckboxItemProps, DropdownMenuContent, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@radix-ui/react-dropdown-menu"
// import { Button } from '@/shadcn/ui/button';

//type Checked = DropdownMenuCheckboxItemProps["checked"]
interface Option {
    label: string;
    value: string;
    //isChecked: Checked;
}

interface SessionHistoryFilterProps {
    options: Option[];
}

const SessionHistoryFilter: React.FC<SessionHistoryFilterProps> = ({ options }) => {
    const [selectedOptions, setSelectedOptions] = useState<string[]>([BOOKING_STATUS_COMPLETED]);
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const dispatch = useDispatch()

    const handleCheckboxChange = (value: string) => {
        setSelectedOptions(prevSelected => {
            const updatedSelected = prevSelected.includes(value)
                ? prevSelected.filter(option => option !== value)
                : [...prevSelected, value];

            if (updatedSelected.length > 0) {
                dispatch(filterUpdate(updatedSelected.join(', ')))
            } else {
                dispatch(filterUpdate(`${BOOKING_STATUS_COMPLETED}`))
                return [BOOKING_STATUS_COMPLETED];
            }
            return updatedSelected;
        });

    };

    useEffect(() => {
        dispatch(filterUpdate(`${BOOKING_STATUS_COMPLETED}`))
    }, [])

    const toggleDropdown = () => {
        setIsDropdownOpen(!isDropdownOpen);
    };

    const isValueChecked = (value: string) => {
        return selectedOptions.includes(value);
    }


    // const [showStatusBar, setShowStatusBar] = React.useState<Checked>(true)
    // const [showActivityBar, setShowActivityBar] = React.useState<Checked>(false)
    // const [showPanel, setShowPanel] = React.useState<Checked>(false)

    // return (
    //     <DropdownMenu>
    //         <DropdownMenuTrigger asChild>
    //             <Button variant="filter">Select Session Status</Button>
    //         </DropdownMenuTrigger>
    //         <DropdownMenuContent className="w-56">
    //             <DropdownMenuLabel>Session Status</DropdownMenuLabel>
    //             <DropdownMenuSeparator />
    //             {options.map(option => (
    //                 <DropdownMenuCheckboxItem
    //                 checked={option.isChecked}
    //                 onCheckedChange={setShowStatusBar}
    //             >
    //                 {option.value}
    //             </DropdownMenuCheckboxItem>
    //             ))}
    //         </DropdownMenuContent>
    //     </DropdownMenu>
    // )


    return (
        <div className="dropdown">
            <button
                className='bg-white justify-between rounded-lg h-[39px] w-[300px] text-graymod-textfour flex items-center gap-3 px-3'
                onClick={toggleDropdown}
            >
                <p>Select Session Status</p>
                <img
                    src={DownArrow}
                    width={20}
                    height={20}
                />
            </button>
            {isDropdownOpen && (
                <div className="absolute z-30 drop-shadow-lg dropdown-menu flex flex-col w-[150px] h-[122px] bg-white rounded-lg pl-3 justify-around mt-1">
                    {options.map(option => (
                        <div key={option.value} className="dropdown-item flex gap-2 cursor-pointer">
                            <input
                                type="checkbox"
                                id={option.value}
                                value={option.value}
                                checked={isValueChecked(option.value)}
                                onChange={() => handleCheckboxChange(option.value)}
                                className=' accent-[#000]'
                            />
                            <label className='text-[12px] text-graymod-textfour cursor-pointer w-[100%] h-[100%]' htmlFor={option.value}>
                                {option.label}
                            </label>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default SessionHistoryFilter;
