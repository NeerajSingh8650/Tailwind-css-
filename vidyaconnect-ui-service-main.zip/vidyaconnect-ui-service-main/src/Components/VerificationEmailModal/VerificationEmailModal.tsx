import React from "react";
import { useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import { closeModal } from "../../Redux/slices/authSlice";
import CloseIcon from "../../assets/close.svg";

interface VerificationEmailModalProps {
  onClose: () => void;
  onSignIn: () => void;
}

const VerificationEmailModal: React.FC<VerificationEmailModalProps> = ({
  onClose,
  onSignIn,
}) => {
  const dispatch = useDispatch();
  const handleSignIn = () => {
    onClose();
    onSignIn();
  };
  return (
    <>
      <div className={"social-modal open w-[28rem]"}>
        <div className="h-5 w-5 absolute right-5 top-4 text-[#00000048] cursor-pointer">
          <img
            src={CloseIcon}
            className="cross-icon"
            onClick={() => {
              onClose()
              dispatch(closeModal())
            }}
          />
        </div>
        <h3 className="font-medium text-[28px] text-center mb-24">
          Check Your Inbox
        </h3>
        <div className="mb-[8rem]">
          <p className="text-[20px] font-normal text-center">
            We have sent a verification link to your email.
          </p>
          <p className="text-[20px] font-normal text-center">
            Please verify using link to sign up
          </p>
        </div>

        <p className="font-normal text-[18px] text-center">
          Already have an account?{" "}
          <Link to="" onClick={() => handleSignIn()} className="underline">
            Sign In
          </Link>
        </p>
      </div>
    </>
  );
};

export default VerificationEmailModal;
