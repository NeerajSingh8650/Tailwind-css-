import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '@/Redux/store/store';
import { bookingSessionModalFlagUpdate, bookSessionResponseModalUpdate, ExploreBookSessionModalUpdate } from '@/Redux/slices/FlagsSLice';
import SessionBookedResponseModal from './SessionBookedResponseModal';
import ExplorePageBookSessionModal from './ExploreBookSessionModal/ExplorePageBookSessionModal';
import LearnerBookSessionsModal from './LearnerBookSessionsModal/LearnerBookSessionsModal';
import React from 'react';

interface Props {
    domainId: number;
}

const ExpertBookSessionModalManager: React.FC<Props> = ({domainId}) => {
    const dispatch = useDispatch();
    const bookSessionDetailsModalVisible = useSelector((state: RootState) => state.flags.ExploreBookSessionModal);
    const bookSessionAvailableSlotsModalVisible = useSelector((state: RootState) => state.flags.bookingSessionModalFlag);
    const bookSessionResponseModalVisible = useSelector((state: RootState) => state.flags.bookSessionResponseModal);

    const handleClickOutside = (event: any) => {
        if (event.target.className.includes("modal-backdrop")) {
            closeAllModals();
        }
    };

    const closeAllModals = () => {
        dispatch(ExploreBookSessionModalUpdate(false));
        dispatch(bookingSessionModalFlagUpdate(false));
        dispatch(bookSessionResponseModalUpdate(false));
    }

    const isAnyModalOpen = bookSessionDetailsModalVisible || bookSessionAvailableSlotsModalVisible || bookSessionResponseModalVisible;

    return (
        isAnyModalOpen && (<div
            className="modal-backdrop fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50"
            onClick={handleClickOutside}>
            {bookSessionDetailsModalVisible && <ExplorePageBookSessionModal />}
            {bookSessionAvailableSlotsModalVisible && <LearnerBookSessionsModal openFrom = "explore" domainId={domainId} />}
            {bookSessionResponseModalVisible && <SessionBookedResponseModal/>}
        </div>)
    );
};

export default ExpertBookSessionModalManager;
