import { SESSION_MIN_DURATION_MINUTES } from '@/constants';
import React, { useState, useEffect } from 'react'

interface TimePickerProps {
  selectedSlot: string,
  onTimeChange: (str: string) => void
}

type MapProps = Map<number, string[]>;



const TimePicker: React.FC<TimePickerProps> = ({ selectedSlot, onTimeChange }) => {



  const [currentMinutes, setCurrentMinutes] = useState<string[]>([]);
  const [hours, setHours] = useState<number>(0);
  const [minutes, setMinutes] = useState<number>(0);
  const [map, setMap] = useState<MapProps >(new Map());
  

   


  const updateMinutes = () => {
    const [startTime, endTime] = selectedSlot.split('-');
    const [startHour, startMin] = startTime.split(':').map(Number);
    const [endHour, endMin] = endTime.split(':').map(Number);

    const startTotalMinutes = startHour * 60 + startMin;
    const endTotalMinutes = endHour * 60 + endMin;

    let duration = endTotalMinutes - startTotalMinutes - SESSION_MIN_DURATION_MINUTES;


    const numHours = Math.floor(duration / 60);

    const endHourMinutes = duration % 60;

    const map: Map<number, string[]> = new Map();


    if (numHours == 0) {
      const minOptions: string[] = [];
      for (var i = startMin; i <= startMin + endHourMinutes; i++) {
        minOptions.push(i.toString().padStart(2, "0"))
      }
      map.set(startHour, minOptions);

    } else {
      for (var i = startHour; i < startHour + numHours; i++) {
        const minOptions: string[] = [];
        if (i == startHour) {
          for (var j = startMin; j < 60; j++) {
            minOptions.push(j.toString().padStart(2, "0"))
          }
        } else {
          for (var j = 0; j < 60; j++) {
            minOptions.push(j.toString().padStart(2, "0"))
          }
        }
        map.set(i, minOptions);
      }
      const minOptions: string[] = [];
      for (var i = 0; i <= endHourMinutes; i++) {
        minOptions.push(i.toString().padStart(2, "0"))
      }
      map.set(startHour + numHours, minOptions);
    }

    setHours(startHour)
    setMinutes(startMin);
    setCurrentMinutes(map.get(startHour) || []);
    onTimeChange(`${startHour.toString()}:${startMin.toString().padStart(2, "0")}`);
    return map
  }





  useEffect(() => {
    const map = updateMinutes()
    setMap(map)
  }, [selectedSlot])





  const handleHoursChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const newHour = parseInt(event.target.value, 10);
    setHours(newHour);
    const minutesOptions = map.get(newHour);
    if (minutesOptions) {
      setCurrentMinutes(minutesOptions);
      setMinutes(parseInt(minutesOptions[0], 10));
      onTimeChange(`${newHour.toString().padStart(2, '0')}:${minutesOptions[0]}`);
    }
    onTimeChange(`${newHour.toString()}:${minutes.toString().padStart(2, "0")}`)
  };


  const handleMinutesChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const newMinutes = parseInt(event.target.value, 10);
    setMinutes(newMinutes);
    onTimeChange(`${hours.toString().padStart(2, "0")}:${newMinutes.toString().padStart(2, "0")}`)
  };






   
  
  return (
    <>
      <div className="flex items-center space-x-2">
        <select value={hours} onChange={handleHoursChange} className="border rounded p-2">
          {Array.from(map.keys()).map(hour => (
            <option key={hour} value={hour}>{hour.toString().padStart(2, '0')}</option>
          ))}
        </select>
        <span>:</span>
        <select value={minutes} onChange={handleMinutesChange} className="border rounded p-2">
          {currentMinutes.map(minute => (
            <option key={minute} value={minute}>{minute}</option>
          ))}
        </select>
      </div>
    </>
  )
}


export default TimePicker
