import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '@/Redux/store/store';
import { expertPreferenceModalFlagUpdate, learnerGetLiveHelpModalUpdate, learnerTimePreferenceModalUpdate } from '@/Redux/slices/FlagsSLice';
import LearnerGetLiveHelpModal from './LearnerGetLiveHelpModal/LearnerGetLiveHelpModal';
import LearnerTimePreferenceModal from './LearnerTimePreferenceModal/LearnerTimePreferenceModal';
import ExpertBucketPriceModal from './ExpertBucketPriceModal/ExpertBucketPriceModal';
import SessionBookedResponseModal from './SessionBookedResponseModal';


const GetLiveHelpModalManager = () => {
    const dispatch = useDispatch();
    const learnerGetLiveHelpModal = useSelector((state: RootState) => state.flags.learnerGetLiveHelpModalFlag);
    const learnerTimePreferenceModal = useSelector((state: RootState) => state.flags.learnerTimePreferenceModalFlag);
    const expertPriceBucketModal = useSelector((state: RootState) => state.flags.expertPreferenceModalFlag);
    const bookedSessionResponseModalFlag = useSelector((state: RootState) => state.flags.bookSessionResponseModal);
    const handleClickOutside = (event: any) => {
        if (event.target.className.includes("modal-backdrop")) {
            closeAllModals();
        }
    };

    const closeAllModals = () => {
        dispatch(learnerGetLiveHelpModalUpdate(false));
        dispatch(learnerTimePreferenceModalUpdate(false));
        dispatch(expertPreferenceModalFlagUpdate(false));
    }

    const isAnyModalOpen = learnerGetLiveHelpModal || learnerTimePreferenceModal || expertPriceBucketModal || bookedSessionResponseModalFlag;

    return (
        isAnyModalOpen && (<div
            className="modal-backdrop fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50"
            onClick={handleClickOutside}>
            {learnerGetLiveHelpModal && (<LearnerGetLiveHelpModal />)}
            {learnerTimePreferenceModal && (<LearnerTimePreferenceModal />)}
            {expertPriceBucketModal && (<ExpertBucketPriceModal />)}
            {bookedSessionResponseModalFlag && (<SessionBookedResponseModal />)}
        </div>)
    );
};

export default GetLiveHelpModalManager;
