function FindAnExpertModal() {
  return (
    <div className="absolute px-6 z-50 top-[50%] left-[50%] translate-x-[-50%] translate-y-[-50%] h-[618px] w-[440px] drop-shadow-sm rounded-lg">
        <h1 className="text-[24px] font-medium mt-5">Get Live Help!</h1>
        <div>
            <label htmlFor="minutes">No. of minutes</label>
            <input id="minutes" type="number" className="w-[110px] mt-10"/>
        </div>
    </div>
  )
}

export default FindAnExpertModal