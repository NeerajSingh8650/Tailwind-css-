import "../SignUpModal/SignUpModal.css";
import { useState } from "react";
import SignUpSocialModal from "../SignUpSocialModal/SignUpSocialModal";
import { PiChalkboardTeacher } from "react-icons/pi";
import { PiStudent } from "react-icons/pi";
import close from "../../assets/close.svg";
import { Button } from "@/shadcn/ui/button";

interface SignUpModalProps {
  onSignIn: () => void;
  onClose: () => void;
}

const SignUpModal = ({ onClose, onSignIn }: SignUpModalProps) => {
  const [showSocialModal, setShowSocialModal] = useState(false);
  const [error, setError] = useState(false);
  const [userType, setUserType] = useState("");

  const openSocialModal = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    if (!userType) {
      setError(true);
      return;
    }
    setShowSocialModal(true);
  };

  const handleRadioChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const userTypeValue = e.target.value.toUpperCase();
    setUserType(userTypeValue);
    sessionStorage.setItem("profile", userTypeValue);
    setError(false); // Clear error when a radio button is selected
  };

  const handleSignIn = () => {
    onClose();
    onSignIn();
  };

  return (
    <>
      {!showSocialModal && (
        <div className={"social-modal open w-[28rem] p-[30px]"}>
          <div className="flex flex-col gap-16 lg:gap-10">
            <div className="h-5 w-5 absolute right-5 top-4 text-[#00000048] cursor-pointer">
              <img src={close} className="cross-icon" onClick={onClose} />
            </div>
            <h3 className="text-[26px] font-regular text-center">
              Choose Your Profile
            </h3>
            <form>
              <div className="flex flex-row lg:flex-row justify-around">
                <label className="flex items-center sm:mb-0 cursor-pointer">
                  <input
                    type="radio"
                    name="userType"
                    id="learner"
                    value="learner"
                    onChange={handleRadioChange}
                    className="w-4 h-4"
                  />
                  <PiStudent className="w-12 h-auto ml-3" />
                  <p className="text-[18px] font-regular ml-2">Learner</p>
                </label>
                <label className="flex items-center cursor-pointer">
                  <input
                    type="radio"
                    name="userType"
                    id="expert"
                    value="expert"
                    onChange={handleRadioChange}
                    className="w-4 h-4"
                  />
                  <PiChalkboardTeacher className="w-12 h-auto ml-3" />
                  <p className="text-[18px] font-regular ml-2">Expert</p>
                </label>
              </div>
              {error && (
                <p className="text-red-500">Please select an option.</p>
              )}
            </form>
            <div className="flex justify-center">
              <Button
                className="text-lg px-8 py-2"
                onClick={openSocialModal}
              >
                Next
              </Button>
            </div>
            <p className="font-normal text-[14px] text-center">
              Already have an account?{" "}
              <Button  onClick={() => handleSignIn()} variant={"link"} className="px-0">
                Sign In
              </Button>
            </p>
          </div>
        </div>
      )}
      {showSocialModal && (
        <SignUpSocialModal
          onSignIn={() => onSignIn()}
          onBack={() => setShowSocialModal(false)}
          onClose={onClose}
          userTypeValue={userType}
        />
      )}
    </>
  );
};

export default SignUpModal;
