import axiosInstance from "../../api/axios";

const FetchTenantId = async () => {
  const storedUserData = localStorage.getItem("userEmail");
  if (storedUserData) {
    try {


      const tenantResponse = await axiosInstance.get(
        `/api/v1/tenant/${storedUserData}`
      );
      const tenantId = tenantResponse.data.data.id;
      return tenantId;
    } catch (error) {
      console.error("Error fetching tenant ID:", error);
      return null;
    }
  }
};

export default FetchTenantId;
