import React, { useState, useEffect } from "react";
import { Link, useNavigate, generatePath } from "react-router-dom";
import axios from "axios";
import openEye from "../../assets/openEyeSvg.svg"
import closeEye from "../../assets/closeEye.svg"
import { COOKIES, setCookie } from "@/config/sessionHelper";
import { validatePassword } from "@/utils/PasswordUtitilities";
import { Button } from "@/shadcn/ui/button";
axios.defaults.withCredentials = true;

interface PasswordModalProps {
  onClose: () => void;
  onSignIn: () => void;
}

const PasswordModal: React.FC<PasswordModalProps> = ({ onSignIn, onClose }) => {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [confirmPasswordError, setConfirmPasswordError] = useState<string>("");
  const [userData, setUserData] = useState<{ email: string; profile: string }>({
    email: "",
    profile: "",
  });
  const navigate = useNavigate();

  useEffect(() => {
    const storedUserData = localStorage.getItem("userdata");
    if (storedUserData) {
      try {
        const parsedUserData = JSON.parse(storedUserData);
        setUserData(parsedUserData);
      } catch (error) {
        console.error("Error parsing user data from localStorage:", error);
      }
    }
  }, []);

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newPassword = e.target.value;
    setPassword(newPassword);
    setPasswordError(validatePassword(newPassword));
  };

  

  const handleConfirmPasswordChange = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const newPassword = e.target.value;
    setConfirmPassword(newPassword);
    validateConfirmPassword(newPassword);
  };

  const validateConfirmPassword = (confirmPassword: string) => {
    if (confirmPassword !== password) {
      setConfirmPasswordError("Password and confirm password do not match.");
    } else {
      setConfirmPasswordError("");
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (!password || !confirmPassword) {
      setPasswordError("Password and confirm password cannot be empty.");
      return;
    }

    localStorage.removeItem("userData");

    try {
      const apiUrl = import.meta.env.VITE_REACT_APP_API_BASE_URL;
      const response = await axios.post(
        `${apiUrl}/registration`,
        {
          email: userData.email,
          password,
          profile: userData.profile,
        },
        {
          withCredentials: true,
        }
      );

      if (response.data.success) {
        onClose();
        const profile = { profile: [userData.profile] };
        setCookie(COOKIES.USER_INFO, profile);
        sessionStorage.setItem("isLoggedIn", "true");
        navigate(generatePath("onboarding"));
      } else {
        console.error("API Error:", response.data.error);
      }
    } catch (error) {
      console.error("API Call Error:", error);
    }
  };

  const handleSignIn = () => {
    onClose();
    onSignIn();
  };

  return (
    <div className="social-modal open w-[28rem]">
      <h3 className="font-medium text-[28px] text-center mb-14">Create Password</h3>
      <form onSubmit={handleSubmit}>
        <div className="relative">
          <input
            type={showPassword ? "text" : "password"}
            name="create-password"
            value={password}
            onChange={handlePasswordChange}
            placeholder="Create password"
            className={`border ${
              passwordError ? "border-red-500" : "border-graymod"
            } w-full font-extralight text-[16px] rounded-xl py-2 ps-3 outline-none`}
          />
          <span
            className="absolute right-3 top-1/2 transform -translate-y-1/2 cursor-pointer"
            onClick={() => setShowPassword(!showPassword)}
          >
            {showPassword ? (
              <img src={closeEye} className="h-[17px]" alt="" />
            ) : (
              <img src={openEye} className="h-[17px]" alt="" />
            )}
          </span>
        </div>
        {passwordError && (
          <p className="text-red-500 text-sm mt-1">{passwordError}</p>
        )}
        <div className="relative mt-10">
          <input
            type={showConfirmPassword ? "text" : "password"}
            name="Confirm-password"
            value={confirmPassword}
            onChange={handleConfirmPasswordChange}
            placeholder="Confirm password"
            className={`border ${
              confirmPasswordError ? "border-red-500" : "border-graymod"
            } w-full font-extralight text-[16px] rounded-xl py-2 ps-3 outline-none`}
          />
          <span
            className="absolute right-3 top-1/2 transform -translate-y-1/2 cursor-pointer"
            onClick={() => setShowConfirmPassword(!showConfirmPassword)}
          >
            {showConfirmPassword ? (
              <img src={closeEye} className="h-[17px]" alt="" />
            ) : (
              <img src={openEye} className="h-[17px]" alt="" />
            )}
          </span>
        </div>
        {confirmPasswordError && (
          <p className="text-red-500 text-sm mt-1">{confirmPasswordError}</p>
        )}
        <div className="flex justify-center mt-12 mb-[40px]">
          <Button
            type="submit"
          >
            Continue
          </Button>
        </div>
        <p className="font-normal text-[18px] text-center mb-6">
          Already have an account?{" "}
          <Link to="" onClick={() => handleSignIn()} className="underline">
            Sign In
          </Link>
        </p>
        <p className="font-regular text-[15px] policy text-center">
          I agree to the{" "}
          <Link to="/terms" className="underline" onClick={() => onClose()}>
            Terms & Conditions{" "}
          </Link>
          and{" "}
          <Link to="/privacy" className="underline" onClick={() => onClose()}>
            Privacy Policy
          </Link>
        </p>
      </form>
    </div>
  );
};

export default PasswordModal;
