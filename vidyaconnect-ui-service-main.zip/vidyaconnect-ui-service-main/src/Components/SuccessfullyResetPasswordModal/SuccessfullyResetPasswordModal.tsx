import { Link } from "react-router-dom"
import { FaCheck } from "react-icons/fa"
import close from "../../assets/close.svg";
import React from "react"
import { ChevronRight } from "lucide-react"
import { useDispatch } from "react-redux"
import { setIsSigninModal, setisSigninOptionsModal } from "@/Redux/slices/authSlice"
import "../../App.css"
const SuccessfullyResetPasswordModal: React.FC<any> = ({ onClose }) => {
    const dispatch = useDispatch()
    return (
        <div className="social-modal open w-[28rem]">
            <div className="h-5 w-5 absolute left-5 top-4 text-[#00000048] cursor-pointer">
                <img src={close} className="cross-icon" onClick={onClose} />
            </div>
            <div className="flex flex-col items-center">
                <div className="h-20 w-20 mb-10 border-4 rounded-[50%] flex items-center justify-center border-cyanmod">
                    <FaCheck className=" text-[35px]  text-cyanmod" />
                </div>
                <h1 className="inter font-medium text-[18px] mb-10">Password Reset Successfully</h1>
                <Link
                    onClick={() => {
                        dispatch(setIsSigninModal(true));
                        dispatch(setisSigninOptionsModal(true));
                        onClose();
                    }}
                    className="text-cyanmod text-[18px] hover:text-cyan-400 flex items-center underline decoration"
                    to={'/'}>
                        <span >Sign in</span> <ChevronRight />
                </Link>
            </div>
        </div>
    )
}

export default SuccessfullyResetPasswordModal