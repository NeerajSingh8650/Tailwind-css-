import { Link } from "react-router-dom";
import LogoutOutlinedIcon from "@mui/icons-material/LogoutOutlined";
import { useDispatch } from "react-redux";
import { AppDispatch } from "@/Redux/store/store";
import { logoutUser } from "@/Redux/slices/authSlice";

const RemoveCookies = () => {
  const dispatch: AppDispatch = useDispatch();

  return (
    <>
      <Link to="/">
        <button
          className="h-10 w-[195px] flex flex-row items-center gap-2 rounded-[5px] pl-2 pt-3"
          onClick={() => dispatch(logoutUser())}
        >
          <span>
            <LogoutOutlinedIcon />
          </span>
          <p>Logout</p>
        </button>
      </Link>
    </>
  );
};

export default RemoveCookies;
