import React, { useEffect, useRef, useState } from "react";
import MoreHorizIcon from "@mui/icons-material/MoreHoriz";
import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import userIcon from "../../assets/user-icon.svg";
import moment from "moment";
import "./SessionCard.css";
import {
  BOOKING_STATUS_EXPIRED,
  BOOKING_STATUS_CANCELLED,
  BOOKING_STATUS_REJECTED,
  BOOKING_STATUS_COMPLETED,
  EXPERT_APPROVAL_PENDING_LABEL,
  EXPERT_ASSIGNMENT_PENDING_LABEL,
  BOOKING_STATUS_SCHEDULED,
  PROFILE,
  BOOKING_STATUS_PENDING,
} from "../../constants";
import { Button } from "@/shadcn/ui/button";
import { sessionIdUpdate } from "@/Redux/slices/SessionDetailsSlice";
import { useDispatch } from "react-redux";
import ViewDetailsCard from "../ViewDetailsCard/ViewDetailsCard";
import { compareWithCurrentTime } from "@/lib/utils";
import Swal from "sweetalert2";
import { ExploreBookSessionModalUpdate } from "@/Redux/slices/FlagsSLice";
import { AppDispatch } from "@/Redux/store/store";
interface SessionCardProps {
  session: any;
  buttonText?: string;
  labelClass?: string;
  isCancel?: boolean;
  onCancel?: () => void;
  isAmount?: boolean;
  isApprovalCTA?: boolean;
  AcceptCTAClick?: () => void;
  RejectCTAClick?: () => void;
  isLearnerPending?: boolean;
  profile: string;
}

const SessionCard: React.FC<SessionCardProps> = ({
  session,
  isCancel = false,
  onCancel,
  isApprovalCTA = false,
  AcceptCTAClick,
  RejectCTAClick,
  profile
}) => {
  const dispatch: AppDispatch = useDispatch();
  const [isViewSession, setIsViewSession] = useState<boolean>(false);
  const [showEllipseMenu, setShowEllipseMenu] = useState<boolean>(false);
  const ellipsesRef = useRef<HTMLDivElement|null>(null);

  useEffect(() => {
  function handleClickOutside(event: MouseEvent) {
    if (ellipsesRef.current && !ellipsesRef.current.contains(event.target as Node)) {
      closeEllipseMenu();
    }
  };
  document.addEventListener('mousedown', handleClickOutside);
  return () => {
    document.removeEventListener('mousedown', handleClickOutside);
  };
}, []);

const toggleEllipseMenu = () => {
  setShowEllipseMenu(!showEllipseMenu)
}

const closeEllipseMenu = () => {
  setShowEllipseMenu(false);
}

  const onViewDetails = (id: any) => {
    setIsViewSession(true);
    dispatch(sessionIdUpdate(id));
    closeEllipseMenu();
  };

  const onCancelSession = () => {
    closeEllipseMenu();
    if (onCancel) {
      onCancel();
    }
  }

  const getUsername = () => {
    if (profile == "LEARNER") {
      return session.expert;
    } else {
      return session.learner;
    }
  }

  const getLabelText = () => {
    if (session.status == "PENDING") {
      if (profile.toLowerCase() === PROFILE.EXPERT) {
        return `₹ ${session.amount}`
      } else {
        if (session.expert == null) {
          return EXPERT_ASSIGNMENT_PENDING_LABEL;
        } else {
          return EXPERT_APPROVAL_PENDING_LABEL;
        }
      }
    } else {
      return session.status;
    }
  }


  const getStatusBgColor = (labelText: string) => {
    switch (labelText) {
      case EXPERT_APPROVAL_PENDING_LABEL:
        return "#ffb373";
      case EXPERT_ASSIGNMENT_PENDING_LABEL:
        return "#ffe589";
      case BOOKING_STATUS_EXPIRED:
        return "#c9c9c9";
      case BOOKING_STATUS_COMPLETED:
        return "#84d28f";
      case BOOKING_STATUS_REJECTED:
        return "#f88c8c";
      case BOOKING_STATUS_CANCELLED:
        return "#f88c8c";
      case BOOKING_STATUS_SCHEDULED:
        return "#a9d2ff";
    }
  };

  const handleJoinMeeting = () => {
    const isMeetingTime = compareWithCurrentTime(session.sessionStart);
    const zoomBaseUrl = import.meta.env.VITE_REACT_APP_ZOOM_BASE_URL;
    if (typeof isMeetingTime === "boolean") {
      const newTab = window.open(
        `${zoomBaseUrl}/meeting/${session.zoomMeetingId}`,
        "_blank"
      );
      if (newTab) {
        newTab.focus();
      }
    } else {
      Swal.fire({
        text: isMeetingTime,
        icon: "info",
      });
    }
  };

  function convertUTCtoLocalDateTime(utcDateTime: string): any {
    let localTime = moment.utc(utcDateTime).toDate();
    const local = moment(localTime);
    return local;
  }
  const startTime = convertUTCtoLocalDateTime(session.sessionStart).format(
    "LT"
  );
  const endTime = convertUTCtoLocalDateTime(session.sessionStart)
    .add(session.duration, "minutes")
    .format("LT");
  const date = convertUTCtoLocalDateTime(session.sessionStart).format("ll");

  let sessionCta = "Join";
  let showSessionCta = false;
  if (
    [
      BOOKING_STATUS_COMPLETED,
      BOOKING_STATUS_EXPIRED,
      BOOKING_STATUS_CANCELLED,
      BOOKING_STATUS_REJECTED,
    ].includes(session.status)
  ) {
    showSessionCta = true;
    sessionCta = "Book Again";
  }

  if (session.status === BOOKING_STATUS_SCHEDULED) {
    showSessionCta = true;
  }

  const labelText1: string = getLabelText();


  return (
    <div className="bg-white px-6 pt-4 pb-4 relative rounded-[10px] mb-2">
      {isViewSession && (
        <div
          className="modal-backdrop fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50"
          onClick={() => {
            setIsViewSession(false);
          }}
        >
          <ViewDetailsCard onClose={() => setIsViewSession(false)} />
        </div>
      )}
      <div className="flex justify-between items-center mb-4">
        {profile.toLowerCase() === PROFILE.EXPERT && session.status == BOOKING_STATUS_PENDING 
        ? (<div><h6 className="font-semibold text-xl text-gray-700">₹ {session.amount}</h6></div>) 
        : (<div
          className="flex justify-between items-center w-auto h-[25px] rounded-full px-4 gap-1"
          style={{
            backgroundColor: getStatusBgColor(labelText1),
          }}
        >
          <p className="badge-new-info text-[10.42px] text-white text-nowrap">
            {labelText1}
          </p>
        </div>)}


        <div
          className="text-[26px] w-8 h-8 rounded-full cursor-pointer flex justify-center duration-200 ease items-center"
          onClick={() => {
            toggleEllipseMenu();
          }}
        >
          <MoreHorizIcon className="hover:bg-[#e2e2e2] text-[#2C3E50] rounded-[50%] duration-200" />
        </div>


        {showEllipseMenu && (
          <div ref = {ellipsesRef} className="absolute top-12 right-5 bg-white border border-[#dddddd] outline-none rounded-lg shadow-md z-10 py-2 w-[138px]">
            <p
              onClick={() => {
                onViewDetails(session.id);
              }}
              className="cursor-pointer text-[12px] ms-3"
            >
              View Details
            </p>
            {isCancel && (
              <>
                <hr className="my-1.5" />
                <p
                  onClick={onCancelSession}
                  className=" cursor-pointer text-[12px] ms-3"
                >
                  Cancel Session
                </p>
              </>
            )}
          </div>
        )}
      </div>
      <h2 className="font-medium text-[20px] text-[#656565] mb-6 truncate">
        {session.title}
      </h2>
      <div className="flex flex-col gap-2">
        <div className="flex items-center mb-4">
          <img className="w-[22px] h-[22px]" src={userIcon} alt="" />
          <h2 className="font-normal text-[16px] text-graymod-texttwo ms-4">
            {labelText1 == EXPERT_ASSIGNMENT_PENDING_LABEL
              ? "-"
              : getUsername()}
          </h2>
        </div>
        <div className="flex items-center mb-4">
          <CalendarMonthIcon className="w-[22px] h-[22px]" />
          <h2 className="font-normal text-[16px] text-graymod-texttwo ms-4">
            {labelText1 == EXPERT_ASSIGNMENT_PENDING_LABEL ? "-" : date}
          </h2>
        </div>
        <div className="flex items-center mb-4">
          <AccessTimeIcon className="w-[22px] h-[22px]" />
          <h2 className="font-normal text-[16px] text-graymod-texttwo ms-4">
            {labelText1 == EXPERT_ASSIGNMENT_PENDING_LABEL
              ? "-"
              : `${startTime} - ${endTime}`}
          </h2>
        </div>
      </div>
      {isApprovalCTA && (
        <div className="flex justify-center items-center space-x-5 mt-4">
          <Button onClick={RejectCTAClick} variant="red">
            Reject
          </Button>
          <Button onClick={AcceptCTAClick} variant="green">
            Accept
          </Button>
        </div>
      )}
      <div className="mt-4 flex justify-end">
        {showSessionCta && (
          <Button
            onClick={() =>
              session.status === "SCHEDULED"
                ? handleJoinMeeting()
                : dispatch(ExploreBookSessionModalUpdate(true))
            }
          >
            {sessionCta}
          </Button>
        )}
      </div>
    </div>
  );
};

export default SessionCard;
