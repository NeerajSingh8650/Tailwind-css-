import React, { useState } from 'react';
import { FaChevronDown } from 'react-icons/fa';

interface RateCardDropDownProps {
    silverPrice: number;
    goldPrice: number;
    platinumPrice: number;
    domainName: string
}

const RateCardDropDown: React.FC<RateCardDropDownProps> = ({ silverPrice, goldPrice, platinumPrice, domainName }) => {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <div className="absolute right-0 top-56 flex items-center pl-5 w-[238px] text-[16px] h-[39px] rounded-l-3xl bg-[#002834] text-white">
            <div className="relative">
                <ul
                    className="flex items-center justify-around gap-5"
                    onClick={() => setIsOpen(!isOpen)}
                >
                    <FaChevronDown className={`h-[17px] transition-transform duration-200 ${isOpen ? 'transform rotate-180' : ''}`} />
                    <li>Expert Rate Card</li>
                </ul>

                {isOpen && (
                    <div className='flex rounded-lg flex-col justify-between absolute top-12 -right-8 overflow-hidden h-[205px] shadow-lg bg-white z-10 w-[337px]'>
                        <div className='flex items-center justify-center h-[39px] bg-[#002834]'>{domainName}</div>
                        <ul className="">
                            <div className='hover:bg-gray-100 cursor-pointer flex items-center px-12 justify-between'>
                                <h1 className='text-[18px] font-semibold text-[#656460]'>PLATINUM</h1>
                                <li
                                    className="hover:bg- block px-4 py-2 text-[18px] text-[#515151] font-semibold  cursor-pointer"
                                >
                                    ₹{platinumPrice ? platinumPrice : "0"}
                                </li>
                            </div>
                            <div className='hover:bg-gray-100 cursor-pointer flex items-center  px-12 justify-between'>
                                <h1 className='text-[18px] font-semibold text-[#B88401]'>GOLD</h1>
                                <li
                                    className="block px-4 py-2 text-[18px] text-[#515151] font-semibold hover:bg-gray-100 cursor-pointer"
                                >
                                    ₹{goldPrice ? goldPrice : "0"}
                                </li>
                            </div>
                            <div className='hover:bg-gray-100 cursor-pointer flex justify-between px-12 items-center '>
                                <h1 className='text-[18px] font-semibold text-[#919191]'>SILVER</h1>
                                <li
                                    className="block px-4 py-2 text-[18px] text-[#515151] font-semibold hover:bg-gray-100 cursor-pointer"
                                >
                                    ₹{silverPrice ? silverPrice : "0"}
                                </li>
                            </div>
                        </ul>
                        <span className='text-[#B9B9B9] text-[14px] flex justify-center mb-2'>Charges are displayed in INR on hourly basis</span>
                    </div>
                )}
            </div>
        </div>
    );
};

export default RateCardDropDown;
