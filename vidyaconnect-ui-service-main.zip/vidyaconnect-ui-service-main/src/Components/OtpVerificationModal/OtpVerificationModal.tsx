import React, { useEffect, useRef, useState } from "react";
import CloseIcon from "@mui/icons-material/Close";
import axiosInstance from "../../api/axios";
import "./OtpVerificationModal.css";
import { OTP_EXPIRY_TIME_SECONDS, OTP_LENGTH } from "../../constants";
import { Button } from "@/shadcn/ui/button";
import { AppDispatch } from "@/Redux/store/store";
import { useDispatch } from "react-redux";
import { generateOtp } from "@/Redux/slices/OtpGenerationSlice";

interface Props {
  isOpen: boolean;
  onClose: () => void;
  phoneNumber: string;
countryCode: string;
  onValidationSuccess: () => void;
}

const OtpVerificationModal: React.FC<Props> = ({
  isOpen,
  onClose,
  countryCode,
  phoneNumber,
  onValidationSuccess 
}) => {
  const [otp, setOtp] = useState<string[]>(new Array(OTP_LENGTH).fill(""));
  const inputRefs = useRef<HTMLInputElement[]>([]);
  const [error, setError] = useState<string>("");
  const [timeLeft, setTimeLeft] = useState<number>(OTP_EXPIRY_TIME_SECONDS);
  const dispatch: AppDispatch = useDispatch();

  useEffect(()=>{
    const handlePaste = (event: ClipboardEvent) => {
      const paste = event.clipboardData?.getData('text').trim();
      if (paste && paste.length === OTP_LENGTH) {
        const digits = paste.split('');
        setOtp(digits);
        inputRefs.current[digits.length - 1]?.focus();
      }
    };

    window.addEventListener("paste", handlePaste);
    return () => window.removeEventListener("paste", handlePaste);
  },[])

  useEffect(() => {
    if (isOpen && inputRefs.current[0]) {
      inputRefs.current[0].focus();
    }
  }, [isOpen]);

  useEffect(() => {
    if (timeLeft === 0) return;
    const timerId = setInterval(() => {
      setTimeLeft((prevTime) => prevTime - 1);
    }, 1000);

    return () => clearInterval(timerId);
  }, [timeLeft]);

  const handleChange = (
    index: number,
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const value = e.target.value;
    if (!/^\d*$/.test(value)) return; // Allow only numeric input

    const newOtp = [...otp];
    newOtp[index] = value.substring(value.length - 1);
    setOtp(newOtp);

    // Move to next input if current field is filled
    if (value && index < OTP_LENGTH - 1 && inputRefs.current[index + 1]) {
      inputRefs.current[index + 1].focus();
    }
  };

  const handleClick = (index: number) => {
    inputRefs.current[index].setSelectionRange(0, 1); // Select text on click

    // Optional: Move focus to the first empty input
    if (!otp[index] && index > 0 && inputRefs.current[index - 1]) {
      inputRefs.current[index - 1].focus();
    }
  };

  const handleKeyDown = (
    index: number,
    e: React.KeyboardEvent<HTMLInputElement>
  ) => {
    if (
      e.key === "Backspace" &&
      !otp[index] &&
      index > 0 &&
      inputRefs.current[index - 1]
    ) {
      // Move focus to the previous input field on backspace
      inputRefs.current[index - 1].focus();
    }
  };

  const handleOtpSubmit = async (e: React.FormEvent<HTMLButtonElement>) => {
    e.preventDefault();
    try {
      const response = await axiosInstance.post(
        "/otp/validation",
        {
          otp: parseInt(otp.join("")), // Convert array to string and then to integer
        }
      );
      if (response.status === 200) {
        onValidationSuccess();
      } else {
        setError("OTP verification failed. Please try again.");
      }
    } catch (err) {
      setError("An error occurred during OTP verification. Please try again.");
    }
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes.toString().padStart(2, "0")}:${secs
      .toString()
      .padStart(2, "0")}`;
  };

  const resendOtp = () => {
    dispatch(generateOtp({
      countryCode,
      phoneNumber}));
    setTimeLeft(OTP_EXPIRY_TIME_SECONDS);
  };
  return (
    <>
      {isOpen && (<div
            className="modal-backdrop fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
        <div className={`otp-verification-modal ${isOpen ? "open" : ""}`}>
          <div className="h-5 w-5 absolute right-5 top-2 text-[#00000048] cursor-pointer">
          <CloseIcon
              onClick={onClose}
              className="cursor-pointer close-icon"
            />
          </div>
          <div className="mb-[47px]">
            <h3 className="font-medium text-center text-[24px] text-[#000000] mb-5 mt-5">
              OTP Verification
            </h3>
            <p className="font-normal text-center text-[16px] text-[#000000]">
              Enter the code sent to +{countryCode}-{phoneNumber}
            </p>
          </div>

          <div className="flex justify-center gap-[1rem] mb-4">
            {otp.map((value, index) => (
              <input
                key={index}
                type="text"
                ref={(input) => input && (inputRefs.current[index] = input)}
                value={value}
                onChange={(e) => handleChange(index, e)}
                onClick={() => handleClick(index)}
                onKeyDown={(e) => handleKeyDown(index, e)}
                className="otpInput border border-graymod w-[52px] h-[52px] rounded-[5px] text-center gap-2"
              />
            ))}
          </div>
          <p className="font-normal text-center text-[16px] text-[#000000]">
            OTP expires in {formatTime(timeLeft)}
          </p>
          {error && (
            <p className="text-red-500 text-sm text-center mt-2">{error}</p>
          )}
          <div className="flex justify-center items-center mt-10 mb-[9px]">
            <Button onClick={handleOtpSubmit}>
              Verify OTP
            </Button>
          </div>
          <div className="flex justify-center items-center mt-5 mb-10">
          <p className="font-medium text-[16px] text-graymod-one">
            Didn’t receive the code?</p>
            <Button variant={"link"} onClick={resendOtp} className="px-1.5">
              Resend OTP
            </Button>
            </div>
        </div>
        </div>
      )}
    </>
  );
};

export default OtpVerificationModal;
