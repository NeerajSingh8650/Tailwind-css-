import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import {
  getOAuthUserDetails,
  getProfileDetails,
  updateTenantProfile,
} from "@/Redux/slices/userSlice";
import { AppDispatch } from "@/Redux/store/store";
import { COOKIES, setCookie } from "@/config/sessionHelper";

const OAuth2Redirect: React.FC = () => {
  const navigate = useNavigate();
  const dispatch: AppDispatch = useDispatch();

  useEffect(() => {
    const handleRedirect = async () => {
      try {
        const authDetails = await dispatch(getOAuthUserDetails()).unwrap();
        sessionStorage.setItem("isLoggedIn", "true");
        if (!authDetails?.profile) {
          await dispatch(
            updateTenantProfile({ profile: sessionStorage.profile })
          );
        } 
        const response = await dispatch(getProfileDetails()).unwrap();
        setCookie(COOKIES.USER_INFO, response);
        if (authDetails?.onboardingCompleted) {
          if (authDetails?.payload?.profile?.toLowerCase() === "expert") {
            navigate("/dashboard/expert-home");
          } else {
            navigate("/explore-experts");
          }
        } else {
          navigate("/onboarding");
        }
        
      } catch (err) {
        console.log(err);
      }
    };

    handleRedirect();
  }, []);

  return <></>;
};

export default OAuth2Redirect;
