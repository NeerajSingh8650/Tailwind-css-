import { useState } from "react";
import "./SignUpSocialModal.css";
import back from "../../assets/back.svg";
import MailOutlineIcon from "@mui/icons-material/MailOutline";
import google from "../../assets/google.svg";
import linkedin from "../../assets/linkedin.png";
import { Link } from "react-router-dom";
import SignUpWithEmailModal from "../SignUpWithEmailModal/SignUpWithEmailModal";
import { getSocialLoginUrl } from "../misc/Helper";
import { SOCIAL_LOGIN_GOOGLE_NAME, SOCIAL_LOGIN_LINKEDIN_NAME } from "@/constants";

interface SignUpSocialModalProps {
  onClose: () => void;
  onBack: () => void;
  onSignIn: () => void;
  userTypeValue: string;
}

const SignUpSocialModal = ({
  onClose,
  onBack,
  onSignIn,
  userTypeValue,
}: SignUpSocialModalProps) => {
  const [signupEmailModal, setSignupEmailModal] = useState(false);

  const openSignupEmailModal = () => {
    setSignupEmailModal(true);
  };
  const handleSignIn = () => {
    onClose();
    onSignIn();
  };
  return (
    <>
      {signupEmailModal ?
        <SignUpWithEmailModal
          onClose={onClose}
          onBack={() => setSignupEmailModal(false)}
          userTypeValue={userTypeValue}
          onSignIn={() => onSignIn()}
        />
      :
      <div className="social-modal open w-[28rem]">
        <div className="h-5 w-5 absolute left-5 top-4 text-[#00000048] cursor-pointer">
          <img src={back} className="cross-icon" onClick={onBack} />
        </div>
        <h3 className="font-medium text-[28px] text-center mb-14">Sign Up</h3>
        <div>
          <form>
            <div>
              <a href={getSocialLoginUrl(SOCIAL_LOGIN_GOOGLE_NAME)}>
                <div className="border-2 border-graymod rounded-[10px] px-3 py-2 justify-between items-center flex mb-10">
                  <img src={google} alt="" className="w-auto h-8" />
                  <h3 className="text-[18px] font-medium">
                    Continue with Google
                  </h3>
                  <div className="w-10"></div>
                </div>
              </a>
              <a href={getSocialLoginUrl(SOCIAL_LOGIN_LINKEDIN_NAME)}>
              <div className="border-2 border-graymod rounded-[10px] px-3 py-2 justify-between items-center flex mb-10">
                <img src={linkedin} alt="" className="w-auto h-8" />
                <h3 className="text-[18px] font-medium ms-2">
                  Continue with LinkedIn
                </h3>
                <div className="w-10"></div>
              </div>
              </a>
              <div
                className="border-2 border-graymod rounded-[10px] px-3 py-2 flex mb-10 justify-between items-center cursor-pointer"
                onClick={openSignupEmailModal}
              >
                <MailOutlineIcon style={{ width: "auto", height: "36px" }} />
                <h3 className="text-[18px] font-medium ms-8">
                  Continue with Email
                </h3>
                <div className="w-10"></div>
              </div>
            </div>

            <p className="font-normal text-[18px] text-center mb-6 mt-[40px]">
              Already have an account?{" "}
              <Link to="" onClick={() => handleSignIn()} className="underline">
                Sign In
              </Link>
            </p>
            <p className="font-regular text-[15px] policy text-center">
              I agree to the{" "}
              <Link to="/terms" className="underline" onClick={onClose}>
                Terms & Conditions{" "}
              </Link>
              and{" "}
              <Link to="/privacy" className="underline" onClick={onClose}>
                Privacy Policy
              </Link>
            </p>
          </form>
        </div>
      </div>
      }
    </>
  );
};

export default SignUpSocialModal;
