import React from 'react';
import './ExpertApprovalPendingModal.css'
import Close from '@mui/icons-material/Close';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { bookSessionResponseModalUpdate } from '../../Redux/slices/FlagsSLice';
interface ExpertApprovalPendingModal {
    onClose: () => void;
    onClearDues: () => void;
    desc: string;
}



const ExpertApprovalPendingModal: React.FC<ExpertApprovalPendingModal> = ({ onClearDues, onClose, desc }) => {
    const navigate = useNavigate()
    const dispatch = useDispatch()
    
    
    const handleClick = () => {
        dispatch(bookSessionResponseModalUpdate(false))
        navigate("/explore-experts");
    }


    return (
        <div className="h-[365px] w-[483px] paymentDueModal fixed top-[50%] left-[50%] flex items-center justify-center bg-white rounded-lg mx-auto text-center">
            <div className='w-[340px] h-[220px] flex items-center gap-[80px] flex-col'>
                <div className="absolute right-5 top-5 text-[#00000047]">
                    <Close onClick={() => {
                        onClose()
                        dispatch(bookSessionResponseModalUpdate(false))
                    }}
                        className="cursor-pointer scale-125" />
                </div>
                <div className='flex flex-col justify-center items-center'>
                    <h2 className="text-[#000000] text-[24px] font-medium mb-3 ">Approval Pending</h2>
                    <p className="text-black text-[16px]4">
                        {desc} <span onClick={() => {
                            dispatch(bookSessionResponseModalUpdate(false))
                            navigate('/dashboard/learner-portal-home')
                            onClearDues()
                        }}
                            className='cursor-pointer text-cyanmod'>here</span>
                    </p>
                </div>
                <button
                    onClick={handleClick}
                    className="bg-cyanmod text-white px-4 py-2 rounded-lg transition">
                    Okay
                </button>
            </div>
        </div>
    );
};

export default ExpertApprovalPendingModal;
