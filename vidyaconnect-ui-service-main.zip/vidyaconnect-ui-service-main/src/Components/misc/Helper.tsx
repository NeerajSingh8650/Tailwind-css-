

    export function getSocialLoginUrl(name: string) {
    return `${import.meta.env.VITE_REACT_APP_SERVER_URL}/oauth2/authorization/${name}`
  }