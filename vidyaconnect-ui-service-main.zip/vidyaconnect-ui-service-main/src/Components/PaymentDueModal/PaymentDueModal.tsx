import React from 'react';
import './PaymentDueModal.css'
import Close from '@mui/icons-material/Close';
interface PaymentDueModalProps {
    amountDue: any;
    onClearDues: () => void;
    onClose: () => void;
}

const PaymentDueModal: React.FC<PaymentDueModalProps> = ({ amountDue, onClearDues, onClose }) => {
    return (
        <div className="paymentDueModal fixed top-[50%] left-[50%] flex  items-center justify-center bg-white rounded-lg p-6 mx-auto text-center">
            <div className='w-[326px] h-[296px] flex items-center justify-between flex-col'>
            <div className="absolute right-5 top-5 text-[#00000047]">
              <Close onClick={onClose} className="cursor-pointer scale-125" />
            </div>
                <div>
                    <h2 className="text-[#C30B0B] text-[24px] font-bold mb-3 ">Payment Due!</h2>
                    <p className="text-black text-[16px]4">
                        Your payment for a session you booked earlier is pending. Please clear dues before moving further.
                    </p>
                </div>
                <p className="text-black text-[20px]">Amount due: ₹{amountDue === null ? "0" : amountDue.toLocaleString()}</p>
                <button
                    onClick={onClearDues}
                    className="bg-cyanmod text-white px-4 py-2 rounded-lg transition"
                >
                    Clear Dues
                </button>
            </div>
        </div>
    );
};

export default PaymentDueModal;
