import React from "react";
import close from '../../../assets/close.svg';
import add from '../../../assets/add.svg';
import edit from "../../../assets/editButton.svg"
import { useDispatch } from "react-redux";
import { SlotDeleteData } from "@/Redux/slices/AvaliableTimeSlotSlice";
import { DayOfWeek } from "@/constants";

const SlotWithWeek: React.FC<any> = ({ availability, handleAddSlot, handleRemoveSlot, Name, EditFlag, flagChanger, delSlot }) => {
    const dispatch = useDispatch()

    return (
        <div className={`availability-slots-list-main mt-10`}>
            <ul className="weekdays">
                {Object.values(DayOfWeek).map((day: string) => (
                    <li className={`${Name === "ExpertEditSlot" && "mt-10"} mb-[40px]`} key={day}>
                        <div className={`flex w-full items-center ${Name === "ExpertEditSlot" ? "justify-between" : ""} gap-5`}>
                            <span className="mr-[30px] inline-block w-[60px]">{day}</span>
                            <div className="flex gap-5 items-center">
                                <img
                                    src={add}
                                    alt="add"
                                    className="w-[25px] h-[auto] cursor-pointer"
                                    onClick={() => handleAddSlot(day)}
                                />
                                {Name === "ExpertEditSlot" && <div>
                                    {EditFlag && <img className="cursor-pointer" onClick={flagChanger} src={edit} alt="" />}
                                </div>}
                            </div>
                        </div>
                        <div className="mt-4">
                            <ul className="flex items-center flex-wrap">
                                {(availability[day] || []).map((slot: any, index: number) => (
                                    <li
                                        className="rounded-lg border-slate-300 w-[145px] text-[16px] border flex items-center justify-center py-2 relative mr-3 mb-3"
                                        key={index}
                                    >
                                        {slot.startTime} - {slot.endTime}
                                        <button onClick={() => {
                                            
                                            Name === "ExpertEditSlot" && dispatch(SlotDeleteData({
                                                day: day,
                                                startTime: slot.startTime,
                                                endTime: slot.endTime
                                            }))
                                            Name === "ExpertEditSlot" && delSlot()
                                            Name !== "ExpertEditSlot" && handleRemoveSlot(day, slot.startTime, slot.endTime)
                                            }}>
                                            {Name !== "ExpertEditSlot" && <img
                                                src={close}
                                                alt="close"
                                                className="absolute w-[15px] h-[auto] top-[3px] right-[3px] cursor-pointer"
                                                style={{ filter: 'invert(0.4)' }}
                                            />}
                                            {!EditFlag && <img
                                                src={close}
                                                alt="close"
                                                className="absolute w-[15px] h-[auto] top-[3px] right-[3px] cursor-pointer"
                                                style={{ filter: 'invert(0.4)' }}
                                            />}
                                        </button>
                                     </li>
                                ))}
                            </ul>
                        </div>
                    </li>
                ))}
            </ul>
        </div>
    )
}

export default SlotWithWeek