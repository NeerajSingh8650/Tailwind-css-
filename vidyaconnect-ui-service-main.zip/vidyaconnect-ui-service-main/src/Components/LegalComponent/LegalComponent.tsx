interface LegalComponentProps {
    htmlContent: string
}

const LegalComponent: React.FC<LegalComponentProps> = ({htmlContent}) => {
    return (
        <div>
            <div dangerouslySetInnerHTML={{ __html: htmlContent }} />
        </div>
    );
}

export default LegalComponent;