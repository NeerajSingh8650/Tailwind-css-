import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import "./Header.css";
import logo from "../../assets/sagenest_logo.svg";
import SignUpModal from "../SignUpModal/SignUpModal";
import SignInModal from "../SignInModal/SignInModal";
import { PRODUCT_NAME } from "../../constants";
import ProfileOptionDialog from "../LogoutPopup/ProfileOptionDialog";
import MenuItems from "./MenuItems";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "@/Redux/store/store";
import { clearError, setIsSigninModal, setisSigninOptionsModal, setIsSignUpModal } from "@/Redux/slices/authSlice";
import SignInFormWithEmailPassword from "../SignInFormWithEmailPassword/SignInFormWithEmailPassword";
import { learnerGetLiveHelpModalUpdate } from "@/Redux/slices/FlagsSLice";
import GetLiveHelpModalManager from "../GetLiveHelpModalManager";
import BannerCard from "@/Pages/LandingPage/BannerCard";

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);

  const location = useLocation();

  const dispatch = useDispatch()

  const signInModalIsOpen = useSelector((state: RootState) => state.auth.isSigninOptionsModal);
  const isSignUpModal = useSelector((state: RootState) => state.auth.isSignUpModal);
  const showEmailPasswordModal = useSelector((state: RootState) => state.auth.isSigninModal);
  const learnerGetLiveHelpModal = useSelector((state: RootState) => state.flags.learnerGetLiveHelpModalFlag);

  const toggleNavbar = () => {
    setIsOpen(!isOpen);
  };

  const closeNavbar = () => {
    setIsOpen(false);
  };

  const closeSignupModal = () => {
    dispatch(setIsSignUpModal(false));
  };

  const openSignInModal = () => {
    dispatch(setisSigninOptionsModal(true))
    closeNavbar();
  };

  const closeSignInModal = () => {
    dispatch(setisSigninOptionsModal(false))
  };

  const openSignUpModal = () => {
    dispatch(setIsSignUpModal(true));
  };

  const openProfileModal = () => {
    setShowProfileModal(!showProfileModal);
  };

  const openGetLiveHelpModal = () => {
    dispatch(learnerGetLiveHelpModalUpdate(!learnerGetLiveHelpModal));
  };

  const closeAllModals = () => {
    closeSignupModal();
    dispatch(setisSigninOptionsModal(false));
    setShowProfileModal(false);
    dispatch(setisSigninOptionsModal(false))
    dispatch(learnerGetLiveHelpModalUpdate(false));
    dispatch(setIsSigninModal(false));
  };

  const handleClickOutside = (event: any) => {
    if (event.target.className.includes("modal-backdrop")) {
      closeAllModals();
    }
  };

  const closeEmailPasswordModal = () => {
    dispatch(setisSigninOptionsModal(true));
    dispatch(setIsSigninModal(false));
    dispatch(clearError())
  };

  const isHomepage = location.pathname === "/";

  const isLandingPage = location.pathname === "/LandingPage";
  const isExpertTab = location.pathname === "/expert-opportunities";
  const isLearnerTab = location.pathname === "/learner-opportunities";

  return (
    <nav className="bg-[#002834]">
      <div className="bg-[#002834] text-white">
        <div className="px-4 sm:px-6 py-3 lg:px-14 xl:px-20 border-graymod-one">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <div className="flex justify-center items-center space-x-2">
                <Link to="/" className="inline-flex items-center space-x-2">
                  <img
                    src={logo}
                    alt={`${PRODUCT_NAME} Logo`}
                    className="w-44 h-[auto] bg-none"
                  />
                </Link>
              </div>
            </div>
            <div className="flex items-center">
              <div className="hidden lg:block ml-auto">
                <div className="flex items-center">
                  <MenuItems
                    closeNavbar={closeNavbar}
                    openSignInModal={openSignInModal}
                    openSignUpModal={openSignUpModal}
                    openGetLiveHelpModal={openGetLiveHelpModal}
                    openProfileModal={openProfileModal}
                  />
                </div>
              </div>
              <div className="-mr-2 flex lg:hidden">
                <button
                  onClick={toggleNavbar}
                  type="button"
                  className="text-white bg-cyanmod  w-[100%] lg:w-[15%] text-[16px] font-normal py-2 px-2 rounded-lg cursor-pointer"
                  aria-controls="mobile-menu"
                  aria-expanded="false"
                >
                  <span className="sr-only">Open main menu</span>
                  {!isOpen ? (
                    <svg
                      className="block h-6 w-6"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      aria-hidden="true"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M4 6h16M4 12h16M4 18h16"
                      />
                    </svg>
                  ) : (
                    <svg
                      className="block h-6 w-6"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      aria-hidden="true"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M6 18L18 6M6 6l12 12"
                      />
                    </svg>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="lg:hidden" id="mobile-menu">
            <div className="px-4 sm:px-6 py-3 lg:px-2">
              <MenuItems
                closeNavbar={closeNavbar}
                openSignInModal={openSignInModal}
                openSignUpModal={openSignUpModal}
                openGetLiveHelpModal={openGetLiveHelpModal}
                openProfileModal={openProfileModal}
              />
            </div>
          </div>
        )}
      </div>

      {isSignUpModal && (
        <div
          className="modal-backdrop fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50"
          onClick={handleClickOutside}
        >
          <SignUpModal
            onSignIn={openSignInModal}
            onClose={closeSignupModal}
          />
        </div>
      )}
      <GetLiveHelpModalManager />

      {signInModalIsOpen && (
        <div
          className="modal-backdrop fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50"
          onClick={handleClickOutside}
        >
          <SignInModal
            onSignUp={openSignUpModal}
            onClose={closeSignInModal}
          />
        </div>
      )}
      {showProfileModal && (
        <div
          className="modal-backdrop absolute inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50"
          onClick={handleClickOutside}
        >
          <ProfileOptionDialog onClose={() => setShowProfileModal(false)} />
        </div>
      )}

      {showEmailPasswordModal && (
        <div
          className="modal-backdrop absolute inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50"
          onClick={handleClickOutside}
        >
          <SignInFormWithEmailPassword
            onSignUp={() => {
              openSignUpModal();
              closeSignInModal();
            }}
            onBack={closeEmailPasswordModal}
            onSignInSuccess={closeAllModals}
          />
        </div>
      )}

      {/* {isHomepage && <Slider onGetStarted={openModal} />} */}

      
      {isHomepage &&
        <div className="blue-outer overflow-hidden">
          <div className="flex-1 py-14 max-w-[1170px] m-[auto] z-20 relative overflow-hidden">
            <BannerCard onGetStarted={openSignUpModal}  />
          </div> </div>
      }

      {isLandingPage &&
        <div className="blue-outer overflow-hidden">
          <div className="flex-1 py-14 max-w-[1170px] m-[auto] z-20 relative overflow-hidden">
            <BannerCard onGetStarted={openSignUpModal}  />
          </div> </div>
      }

      {isExpertTab &&
        <div className="blue-outer overflow-hidden">
          <div className="flex-1 py-14 max-w-[1170px] m-[auto] z-20 relative overflow-hidden bg-[#002834]">
            <BannerCard onGetStarted={openSignUpModal}  />
          </div> </div>
      }

      {isLearnerTab &&
        <div className="blue-outer overflow-hidden">
          <div className="flex-1 py-14 max-w-[1170px] m-[auto] z-20 relative overflow-hidden">
            <BannerCard onGetStarted={openSignUpModal}  />
          </div> </div>
      }
    </nav>
  );
};

export default Header;
