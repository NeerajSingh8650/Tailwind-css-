import { Link } from "react-router-dom";
import { Button, buttonVariants } from "@/shadcn/ui/button";
import UserIcon from "../../assets/user_white.svg";
import { useSelector } from "react-redux";
import { RootState } from "@/Redux/store/store";
import NotificationSystem from '../Notifications' 

interface MenuItemsProps {
  closeNavbar: () => void;
  openSignInModal: () => void;
  openSignUpModal: () => void;
  openGetLiveHelpModal: () => void;
  openProfileModal: () => void;
}


const MenuItems = ({
  closeNavbar,
  openSignInModal,
  openSignUpModal,
  openGetLiveHelpModal,
  openProfileModal,
}: MenuItemsProps) => {
  const { userDetails } = useSelector((state: RootState) => state.user);
  const isLoggedIn = JSON.parse(sessionStorage?.isLoggedIn || false);
  return (
    <>
      {isLoggedIn && userDetails?.onboardingCompleted ? (
        <>
          {userDetails?.profile?.toLowerCase() === "learner" ? (
            <>
              <Link
                to="/explore-experts"
                onClick={closeNavbar}
                className={`text-white ${buttonVariants({ variant: "link" })}`}
              >
                Explore
              </Link>
              <Link
                to="/dashboard/learner-portal-home"
                onClick={closeNavbar}
                className={`text-white ${buttonVariants({ variant: "link" })}`}
              >
                Dashboard
              </Link>
              <Link
                to="/ask-ai"
                onClick={closeNavbar}
                className={`text-white ${buttonVariants({ variant: "link" })}`}
              >
                Ask AI
              </Link>
              <Button
                className="text-white no-hover"
                variant="link"
                onClick={openGetLiveHelpModal}
              >
                Get Live Help
              </Button>
              <NotificationSystem />
            </>
          ) : (
            <>
              <Link
                to="/dashboard/expert-home"
                onClick={closeNavbar}
                className={`text-white ${buttonVariants({ variant: "link" })}`}
              >
                Home
              </Link>
              <Link
                to="/expert-feedback"
                onClick={closeNavbar}
                className={`text-white ${buttonVariants({ variant: "link" })}`}
              >
                My Feedback
              </Link>
              <Link
                to="/ask-ai"
                onClick={closeNavbar}
                className={`text-white ${buttonVariants({ variant: "link" })}`}
              >
                Ask AI
              </Link>
               <NotificationSystem />
            </>
          )}
            <div className="relative w-[2.25rem] h-[2.25rem] rounded-[50%] overflow-hidden ml-8">
          <img
            src={userDetails?.picUrl || UserIcon}
            alt="Personal Information"
            className="cursor-pointer h-[100%] w-[100%]"
            onClick={() => openProfileModal()}
          />
          </div>
        </>
      ) : isLoggedIn ? null : (
        <>
          <Link
            to="/expert-opportunities"
            className={`text-white ${buttonVariants({ variant: "link" })}`}
          >
            For Expert
          </Link>
          <Link
            to="/learner-opportunities"
            className={`text-white ${buttonVariants({ variant: "link" })}`}
          >
            For Learner
          </Link>
          <Link
            to="/"
            state={{
              item: "Home"
            }}
            className={`text-white ${buttonVariants({ variant: "link" })}`}
          >
            Home
          </Link>
          <Link
            to="#"
            className={`text-white mr-6 ${buttonVariants({ variant: "link" })}`}
            onClick={openSignInModal}
          >
            Sign in
          </Link>
          <Button onClick={openSignUpModal}>Sign up</Button>
        </>
      )}
    </>
  );
};

export default MenuItems;
