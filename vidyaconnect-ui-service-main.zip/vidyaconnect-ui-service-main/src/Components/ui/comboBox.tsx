import { filteredCompaniesUpdater } from '@/Redux/slices/LearnerSettingSlice';
import React, { useState, ChangeEvent, useRef, useEffect } from 'react';
import { useDispatch } from 'react-redux';


interface SuggestionWithName {
  id: any;
  name: string;
  title?: never;
}

interface SuggestionWithTitle {
  id: any;
  title: string;
  name?: never;
}

type Suggestion = SuggestionWithName | SuggestionWithTitle;

interface ComboBoxProps {
  suggestions: Suggestion[];
  onSelect: (suggestion: Suggestion) => void;
  selectedItem?: string;
  onValueChange?: (e: any) => void
  className?: string
  onChange?: any
  placeholder?: string
}

const ComboBox: React.FC<ComboBoxProps> = ({ suggestions, onSelect, selectedItem, className, onValueChange, onChange, placeholder }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredSuggestions, setFilteredSuggestions] = useState<Suggestion[]>([]);
  const [intialvalueFlag, setinitailvalueFlag] = useState(true)
  const dispatch = useDispatch()
  const handleInputChange = (event: ChangeEvent<HTMLInputElement>) => {
    const term = event.target.value;
    if (onChange) {
      onChange(term);
    }

    setSearchTerm(term);
    setinitailvalueFlag(false)
    if (term.length > 0) {
      const filtered = suggestions.filter((suggestion) => {
        const nameMatch = suggestion.name?.toLowerCase().includes(term.toLowerCase()) ?? false;
        const titleMatch = suggestion.title?.toLowerCase().includes(term.toLowerCase()) ?? false;
        return nameMatch || titleMatch;
      });
      setFilteredSuggestions(filtered);
      dispatch(filteredCompaniesUpdater(filtered))
      onSelect({ 'name': term, id: null });
    } else {
      setFilteredSuggestions([]);
    }
  };


  const [isOpen, setIsOpen] = useState<boolean>(false);
  const componentRef = useRef<HTMLDivElement | null>(null);

  const handleClickOutside = (event: MouseEvent) => {
    if (componentRef.current && !componentRef.current.contains(event.target as Node)) {
      setIsOpen(false);
    }
  };

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);



  const handleSuggestionClick = (suggestion: Suggestion) => {
    const suggestionValue = suggestion.name ?? suggestion.title ?? '';
    setSearchTerm(suggestionValue);
    setFilteredSuggestions([]);
    onSelect(suggestion);
  };

  return (
    <div className="relative">
      <input
        placeholder={placeholder}
        type="text"
        onKeyDown={(e)=>{
          if (e.key === 'Enter') {
            setIsOpen(false);
          }
        }}
        value={intialvalueFlag ? selectedItem ? selectedItem : "" : searchTerm}
        onChange={(e) => {
          handleInputChange(e)
          setIsOpen(true)
          if (onValueChange) {
            onValueChange(e)
            setIsOpen(true)
          }
        }}
        className={`border rounded-md px-3 placeholder:text-graymod  w-full outline-none ${className}`}
      />
      {filteredSuggestions.length > 0 && (
        <>
          {isOpen && <div ref={componentRef} className="absolute max-h-96 overflow-y-auto top-full left-0 z-[999] bg-white border rounded-md shadow-md w-full">
            {filteredSuggestions.map((suggestion) => (
              <div key={suggestion.id} className="px-3 py-2 hover:bg-gray-100" onClick={() => handleSuggestionClick(suggestion)}>
                {suggestion.name || suggestion.title}
              </div>
            ))}
          </div>}
        </>
      )}
    </div>
  );
};

export default ComboBox;
