import React from "react";
import { FaTimes } from "react-icons/fa";
import "./PendingRequestAcceptModal.css";

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

const PendingRequestAcceptModal: React.FC<Props> = ({ isOpen, onClose }) => {
  return (
    <>
      {isOpen && (
        <>
          <div
            className={`overlay ${isOpen ? "open" : ""}`}
            onClick={onClose}
          ></div>
          <div className={`request-modal ${isOpen ? "open" : ""}`}>
            <div className="flex justify-end text-4xl mb-4">
              <FaTimes onClick={onClose} className="cursor-pointer" />
            </div>
            <button className="font-normal text-[30.5px] mb-10 py-2 px-4 text-center bg-cyanmod text-white rounded-xl">
              Add to my calendar
            </button>
            <div className="mt-5 flex justify-between items-center">
              <div className="flex items-center">
                <input type="checkbox" className="w-5 h-5" name="" id="" />
                <h2 className="text-[16px] font-normal ms-4">
                  Don’t Ask Again
                </h2>
              </div>
              <div>
                <button className="font-normal text-[17.74px] py-2 px-8 text-center bg-cyanmod text-white rounded-lg">
                  Save
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </>
  );
};

export default PendingRequestAcceptModal;
