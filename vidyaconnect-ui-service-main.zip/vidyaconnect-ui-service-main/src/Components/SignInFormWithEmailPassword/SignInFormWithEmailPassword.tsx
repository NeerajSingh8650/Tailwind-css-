import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import back from "../../assets/back.svg";
import { useDispatch, useSelector } from "react-redux";
import * as Yup from "yup";
import { useFormik } from "formik";
import { clearError, loginWithEmail } from "../../Redux/slices/authSlice";
import ForgotPasswordModal from "../ForgotPasswordModal/ForgotPassword";
import { Button, buttonVariants } from "@/shadcn/ui/button";
import openEye from "../../assets/openEyeSvg.svg"
import closeEye from "../../assets/closeEye.svg"

interface Props {
  onBack: () => void;
  onSignUp: () => void;
  onSignInSuccess: () => void;
  userTypeValue?: any;
}

const loginSchema = Yup.object().shape({
  email: Yup.string().email("Please enter valid email").required(),
  password: Yup.string().required(),
});

const SignInFormWithEmailPassword: React.FC<Props> = ({
  onBack,
  onSignUp,
  onSignInSuccess,
  userTypeValue,
}) => {
  const [showPassword, setShowPassword] = useState(false);
  const [forgotPasswordModal, setforgotPasswordModal] = useState(false);
  const dispatch: any = useDispatch();
  const navigate = useNavigate();
  const { error: errorSelector } = useSelector(
    (state: { auth: { error: any } }) => state.auth
  );

  useEffect(() => {
    dispatch(clearError())
  }, [])

  const { values, handleChange, handleSubmit, errors, touched } =
    useFormik({
      initialValues: {
        email: "",
        password: "",
        navigate,
        onSignInSuccess
      },
      validationSchema: loginSchema,
      onSubmit: async (values) => {
        values.navigate = navigate;
        values.onSignInSuccess = onSignInSuccess;
        dispatch(loginWithEmail(values))
      },
    });

  const handleEyeClick = () => {
    setShowPassword(!showPassword);
  };
  const handleForgotPassword = () => {
    setforgotPasswordModal(true);
  };


  return (
    <>
      {forgotPasswordModal ?
        <ForgotPasswordModal
          onClose={() => setforgotPasswordModal(false)}
          userTypeValue={userTypeValue}
          onSignIn={() => { }}
        />
      :
        <div
          className={"social-modal open w-[28rem]"}
        >
          <div className="h-5 w-5 absolute left-5 top-4 text-[#00000048] cursor-pointer">
            <img src={back} className="cross-icon" onClick={onBack} />
          </div>
          <h3 className="font-medium text-[28px] text-center mb-16">Sign In</h3>
          <form onSubmit={handleSubmit}>
            <div className="mb-6">
              <input
                type="email"
                className="border border-graymod w-full font-extralight text-[16px] rounded-xl py-2 ps-3 outline-none"
                placeholder="Enter email"
                name="email"
                value={values.email}
                onChange={handleChange}
              />
              {touched.email && errors.email && (
                <p className="text-red-500 text-[14px] mt-1">{errors.email}</p>
              )}
            </div>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                name="password"
                placeholder="Enter password"
                className="border border-graymod w-full font-extralight text-[16px] rounded-xl py-2 ps-3 outline-none"
                value={values.password}
                onChange={handleChange}
              />
              <span
                className="absolute right-3 top-1/2 transform -translate-y-1/2 cursor-pointer"
                onClick={handleEyeClick}
              >
                {showPassword ? (
                  <img src={closeEye} className="h-[17px]" alt="" />
                ) : (
                  <img src={openEye} className="h-[17px]" alt="" />
                )}
              </span>
            </div>
            {touched.password && errors.password && (
              <p className="text-red-500 text-[14px] mt-1">{errors.password}</p>
            )}
            <Link to="#" className={`${buttonVariants({ variant: "link", size: "zeroPadding" })}  px-0`} onClick={handleForgotPassword}>Forgot Password?</Link>
            <div className="flex flex-col items-center justify-center mt-12 mb-[40px]">
              <Button type="submit" >
                Continue
              </Button>

              {errorSelector && (
                <div className="absolute top-[110px] error-info-sign-up w-[75%]">
                  <span className="p-2 text-red-500 text-[14px] text-center mt-6">{errorSelector.apiResponse}</span>
                </div>
              )}
            </div>
            <p className="font-normal text-[18px] text-center mb-6 mt-[40px]">
              Don’t have an account?{" "}
              <Link to={""} onClick={() => onSignUp()} className="underline">
                Sign Up
              </Link>
            </p>
            <p className="font-regular text-[15px] policy text-center">
              I agree to the{" "}
              <Link to="/terms" className="underline" onClick={() => onSignInSuccess()}>
                Terms & Conditions{" "}
              </Link>
              and{" "}
              <Link to="/privacy" className="underline" onClick={() => onSignInSuccess()}>
                Privacy Policy
              </Link>
            </p>
          </form>
        </div>
      }
    </>
  );
};

export default SignInFormWithEmailPassword;