import { FC } from "react"


interface headingProps {
    title: string
}


const PageHeading: FC<headingProps> = ({ title }) => {
    return (
        <div className="bg-white flex flex-col">
            <h1 className="text-[24px] text-[#515151] font-medium">
                {title}
            </h1>
            <hr className="border-none h-[4px] mt-2 bg-[#dddddd] mb-12" />
        </div>
    )
}

export default PageHeading