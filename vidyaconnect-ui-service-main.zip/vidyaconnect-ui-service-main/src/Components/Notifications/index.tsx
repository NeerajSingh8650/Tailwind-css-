import { useState, useEffect, useRef } from 'react';
import { firebaseDB, ref, onValue, update  } from "../../config/firebaseConfig";
import { FaRegBell } from "react-icons/fa";
import { useSelector } from "react-redux";
import { RootState } from "@/Redux/store/store";
import NotificationList, { Notification } from "./notificationList";

const NotificationSystem = () => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [notificationCount, setNotificationCount] = useState(0);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const { userDetails } = useSelector((state: RootState) => state.user);
  const isLoggedIn = JSON.parse(sessionStorage?.isLoggedIn || false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isLoggedIn && userDetails) {
      const notificationRef = ref(firebaseDB, `users/${userDetails.tenantId}/notifications`);
      
      const unsubscribe = onValue(notificationRef, (snapshot) => {
        const data = snapshot.val();
        if (data) {
          const loadedNotifications = Object.values(data) as Notification[];
          loadedNotifications.sort((a, b) => b.timestamp - a.timestamp);
          setNotifications(loadedNotifications);
          const unreadCount = loadedNotifications.filter(n => !n.isRead).length;
          setNotificationCount(unreadCount);
        } else {
          setNotifications([]);
          setNotificationCount(0);
        }
      });

      return () => {
        unsubscribe();
      };
    }
  }, [isLoggedIn, userDetails]);



    useEffect(() => {
        function handleClickOutside(event: MouseEvent) {
        if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
            setIsDropdownOpen(false);
            markAllAsRead();
        }
        }

        document.addEventListener('mousedown', handleClickOutside);
        return () => {
        document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    
    const markAllAsRead = () => {
        if (userDetails) {
          notifications.forEach(notification => {
            if (!notification.isRead) {
              const notificationRef = ref(firebaseDB, `users/${userDetails.tenantId}/notifications/${notification.id}`);
              update(notificationRef, { isRead: true })
                .then(() => {
                  console.log(`Notification ${notification.id} marked as read`);
                })
                .catch((error) => {
                  console.error(`Error updating notification ${notification.id}:`, error);
                });
            }
          });
        }
    };

    const handleNotificationClick = () => {
    setIsDropdownOpen((prev) => !prev);
    setNotificationCount(0);
    };


 
    const handleModalClickOutside = () => {
        setIsDropdownOpen(false);
        markAllAsRead();
    };


  return (
  <div className="relative">
      <div className="cursor-pointer" onClick={handleNotificationClick}>
        <div className="relative">
          <FaRegBell className="w-6 h-6 text-white " />
          {notificationCount > 0 && (
            <span className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full px-1 text-xs">
              {notificationCount}
            </span>
          )}
        </div>
      </div>

      {isDropdownOpen && (
        <div ref={dropdownRef}  className="modal-backdrop fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50" onClick={handleModalClickOutside}>
          <div className='w-64 bg-white border border-gray-200 rounded-lg shadow-lg absolute top-[70px] right-[150px]'>
          <NotificationList notifications={notifications} onClose={handleNotificationClick} />
          </div>
        </div>
      )}
    </div>
  );
};

export default NotificationSystem;