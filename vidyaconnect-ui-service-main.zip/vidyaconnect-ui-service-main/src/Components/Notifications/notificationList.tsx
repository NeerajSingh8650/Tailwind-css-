import {cancelledSessionDrawerFlagUpdate} from '../../Redux/slices/FlagsSLice'
import {useNavigate} from 'react-router-dom'
import {NotificationTypes} from '../../constants'

import {useDispatch} from 'react-redux'
export interface Notification {
    id: string; 
    title: string;
    body: string;
    timestamp: number;
    isRead: boolean;
    image?: string;
} 


interface ComponentProps  {
  notifications : Notification[] ,
  onClose : ()=> void
}


  
  const NotificationList: React.FC<ComponentProps> = ({ notifications, onClose }) => {
    
   const dispatch: any = useDispatch();
   const navigate = useNavigate();


   const handleNotificationClick = (notification : any)=>{
      if([NotificationTypes.NOTIFICATION_BOOKING_CANCELLED, NotificationTypes.NOTIFICATION_BOOKING_EXPIRED, NotificationTypes.NOTIFICATION_BOOKING_REJECTED]
        .includes(notification.type)) {
        dispatch(cancelledSessionDrawerFlagUpdate(true))
      } else{
        navigate("/")
      }
    onClose();
   }


    return (
      <div className="p-2 max-h-[500px] overflow-y-auto relative">
      {notifications.length > 0 ? (
        notifications.map((notification, index) => (
          <div key={index} className=" flex items-start p-2 border-b last:border-none" onClick={()=>{handleNotificationClick(notification)}}>
            {notification.image && (
              <img src={notification.image} width={50} alt="Notification" className="mr-4 rounded" />
            )}
            <div className="w-[100%] cursor-pointer">
              <strong className="text-sm  text-foreground font-medium">{notification.title}</strong>
              <p className="text-xs text-gray-600 overflow-auto">{notification.body}</p>
            </div>
          </div>
        ))
      ) : (
        <p className="text-sm text-gray-500">No new notifications</p>
      )}

      
    </div>
    );
  };
  
  export default NotificationList;