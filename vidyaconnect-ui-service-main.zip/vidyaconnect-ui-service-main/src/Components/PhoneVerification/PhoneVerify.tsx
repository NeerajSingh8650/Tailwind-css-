import React from "react";
import PhoneInput from "react-phone-input-2";

interface PhoneVerificationProps {
  phoneNumber: string;
  setPhoneNumber: React.Dispatch<React.SetStateAction<string>>;
  countryCode: string;
  setCountryCode: React.Dispatch<React.SetStateAction<string>>;
}

const PhoneVerification: React.FC<PhoneVerificationProps> = ({
  phoneNumber,
  setPhoneNumber,
  countryCode,
  setCountryCode,
}) => {
  const handlePhoneChange = (
    value: string,
    newCountry: string | any // Disable type checking for newCountry
  ) => {
    setCountryCode(newCountry.code);
    setPhoneNumber(value);
  };

  const validatePhoneNumber = (phoneNumber: string) => {
    const phoneNumberPattern = /^\+?[1-9]\d{1,14}$/;
    return phoneNumberPattern.test(phoneNumber);
  };

  return (
    <div className="mt-8">
      <div>
        <label className="font-normal text-[32px] mb-4">Phone Number</label>
        <span className="text-red-500 text-lg ms-1">*</span>
        <div className="w-full relative">
          <div className="absolute inset-y-0 left-0 flex items-center pl-3">
            <span className="country-code text-gray-700 font-bold">
              {countryCode}
            </span>
          </div>
          <PhoneInput
            country={countryCode as string | undefined}
            value={phoneNumber}
            onChange={(value, newCountry) => {
              handlePhoneChange(value, newCountry);
            }}
            inputProps={{
              required: true,
              className:
                "border border-graymod-one w-full ps-12 font-extralight rounded-lg outline-none py-2 phone-input md:w-[48.5%]",
            }}
            onlyCountries={["in"]}
          />
          {!validatePhoneNumber(phoneNumber) && (
            <p className="text-red-500 mt-1">
              Please enter a valid phone number.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default PhoneVerification;
