import React from "react";
import { Link } from "react-router-dom";
import close from "../../assets/close.svg";
import MailOutlineIcon from "@mui/icons-material/MailOutline";
import google from "../../assets/google.svg";
import linkedin from "../../assets/linkedin.png";
import { useDispatch } from "react-redux";
import { setIsSigninModal, setisSigninOptionsModal } from "@/Redux/slices/authSlice";
import { getSocialLoginUrl } from "../misc/Helper";
import { SOCIAL_LOGIN_GOOGLE_NAME, SOCIAL_LOGIN_LINKEDIN_NAME } from "@/constants";

interface Props {
  onSignUp: () => void;
  onClose: () => void;
}

const SignInModal: React.FC<Props> = ({ onClose, onSignUp }) => {
  const dispatch = useDispatch()

  function openEmailPasswordModal(){
    dispatch(setIsSigninModal(true));
    dispatch(setisSigninOptionsModal(false));
  };

  const handleSignUp = () => {
    onClose();
    onSignUp();
  };

  return (
    <>
      <div className={"social-modal open w-[28rem]"}>
        <div className="h-5 w-5 absolute right-5 top-4 text-[#00000048] cursor-pointer">
          <img src={close} className="cross-icon" onClick={onClose} />
        </div>
        <h3 className="font-medium text-[28px] text-center mb-14">Sign In</h3>
        <div>
          <form>
            <a href={getSocialLoginUrl(SOCIAL_LOGIN_GOOGLE_NAME)}>
              <div className="border-2 border-graymod rounded-[10px] px-3 py-2 flex mb-10 justify-between items-center cursor-pointer">
                <img src={google} alt="" className="w-auto h-8" />
                <h3 className="text-[18px] font-medium">
                  Continue with Google
                </h3>
                <div className="w-10"></div>
              </div>
            </a>
            <a href={getSocialLoginUrl(SOCIAL_LOGIN_LINKEDIN_NAME)}>
              <div className="border-2 border-graymod rounded-[10px] px-3 py-2 flex mb-10 justify-between items-center cursor-pointer">
                <img src={linkedin} alt="" className="w-auto h-8" />
                <h3 className="text-[18px] font-medium">
                  Continue with LinkedIn
                </h3>
                <div className="w-10"></div>
              </div>
            </a>
            <div
              className="border-2 border-graymod rounded-[10px] px-3 py-2 flex mb-10 justify-between items-center cursor-pointer"
              onClick={() => openEmailPasswordModal()}
            >
              <MailOutlineIcon style={{ width: "auto", height: "36px" }} />
              <h3 className="text-[18px] font-medium">
                Continue with Email
              </h3>
              <div className="w-10"></div>
            </div>
            <p className="font-normal text-[18px] text-center mb-6 mt-[60px]">
              Don’t have an account?{" "}
              <Link to="" onClick={() => handleSignUp()} className="underline">
                Sign Up
              </Link>
            </p>
            <p className="font-regular text-[15px] policy text-center">
              I agree to the{" "}
              <Link to="/terms" className="underline" onClick={() => onClose()}>
                Terms & Conditions{" "}
              </Link>
              and{" "}
              <Link to="/privacy" className="underline" onClick={() => onClose()}>
                Privacy Policy
              </Link>
            </p>
          </form>
        </div>
      </div>
    </>
  );
};

export default SignInModal;
