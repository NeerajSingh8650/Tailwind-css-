import DateComponent from "./DateComponent";
import { Button } from "@/shadcn/ui/button";
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { MoveLeft } from "lucide-react";
import { RootState } from "@/Redux/store/store";
import { expertPreferenceModalFlagUpdate, learnerGetLiveHelpModalUpdate, learnerTimePreferenceModalUpdate } from "@/Redux/slices/FlagsSLice";
import { minutesUpdate } from "@/Redux/slices/FindAnExpertSlice";



const LearnerTimePreferenceModal = () => {
  const dispatch: any = useDispatch()
  const [slotsFlag, setSlotsFlag] = useState<boolean>(false)
  const [min, setMin] = useState<any>(0)
  const timeSlotSelector = useSelector((state: RootState) => state.FindAnExpertApi.timeslots)


  const slotsFlagChecker = () => {
    timeSlotSelector?.map((data: string) => {
      if (data !== "") {
        setSlotsFlag(true)
        return;
      }
    })
  }

  useEffect(() => {
    slotsFlagChecker()
  }, [timeSlotSelector])

  useEffect(() => {
    setSlotsFlag(false)
  }, [])


  return (
    <>
      <div
        className="get-live-schedule-modal px-7 pt-10 pl-10 border">
        <MoveLeft
          onClick={() => {
            dispatch(learnerTimePreferenceModalUpdate(false));
            dispatch(learnerGetLiveHelpModalUpdate(true))
          }}
          className="absolute top-6 left-4 text-black/40 w-[30px] cursor-pointer"
        />
        <h3 className="font-medium text-[24px] mb-10 mt-4">
          Get Live Help!
        </h3>
        <div>
          <div className="flex justify-between items-center mb-6 gap-2 mt-4">
            <h3 className="font-regular text-nowrap">Preferred Slots</h3>
            <DateComponent slot={0} />
          </div>
          <div className="flex justify-end items-center mb-6 gap-2">
            <DateComponent slot={1} />
          </div>
          <div className="flex justify-end items-center mb-6 gap-2">
            <DateComponent slot={2} />
          </div>
          <div className="flex justify-between items-center gap-3 mb-14 mt-4">
            <h3 className="font-regular text-nowrap">No. of Minutes</h3>
            <input
              min={5}
              onChange={(e: any) => {
                if (e.target.value > 5) {
                  dispatch(minutesUpdate(e.target.value));
                  setMin(e.target.value);
                }
              }}
              type="number"
              className="border  w-[96px] border-graymod  font-normal  rounded-md pl-2 outline-none "
            />
          </div>

          <div className="flex justify-end mt-[150px] mb-16">
            {min !== 0 && slotsFlag ? (
              <Button
                onClick={() => {
                  dispatch(learnerTimePreferenceModalUpdate(false))
                  dispatch(expertPreferenceModalFlagUpdate(true));
                }}
              >
                Next
              </Button>
            ) : (
              <Button className="bg-gray-400 hover:bg-gray-400">Next</Button>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default LearnerTimePreferenceModal;