import React, { forwardRef } from "react";
import { FaCalendarAlt } from "react-icons/fa";
import "./LearnerGetLiveScheduleModal.css";

interface CustomInputProps {
  value: string;
  placeholderText: string;
  onClick: (event: React.MouseEvent<HTMLDivElement, MouseEvent>) => void;
}

const CustomInput = forwardRef<HTMLDivElement, CustomInputProps>(
  ({ value, placeholderText, onClick }, ref) => {
    return (
      <div className="custom-input" onClick={onClick} ref={ref}>
        <div className="value">{value || placeholderText}</div>
        <div className="calendar-icon ps-6">
          <FaCalendarAlt />
        </div>
      </div>
    );
  }
);

export default CustomInput;
