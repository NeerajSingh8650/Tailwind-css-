
import { DatePicker, Space } from "antd";
import "./LearnerTimePreferenceModal.css";
import { useDispatch } from "react-redux";
import { timeSlotsUpdate } from "@/Redux/slices/FindAnExpertSlice";
import dayjs from "dayjs";
import utc from 'dayjs/plugin/utc';
import { USER_DATE_FORMAT } from "@/constants";


let timeSlotsArray: string[] = ["", "", ""];

interface DateComponentProps {
  slot: number;
}

const DateComponent: React.FC<DateComponentProps> = ({ slot }) => {
  const dispatch: any = useDispatch();
  dayjs.extend(utc);

  function range(start: number, end: number) {
    const result = [];
    for (let i = start; i <= end; i++) {
      result.push(i);
    }
    return result;
  }

  return (
    <div className="flex flex-col justify-center items-center text-[20px]">
      <div className="flex items-center gap-2">
        <Space direction="vertical" size={12}>
          <DatePicker
            showTime
            format="DD-MM-YYYY hh:mm a"
            placeholder="Select Slot"
            disabledDate={(current) => {
              return current && current < dayjs().startOf('day');
            }}
            disabledTime={(current) => {
              const isToday = current && current.format(USER_DATE_FORMAT) === dayjs().format(USER_DATE_FORMAT);
              if (isToday) {
                return {
                  disabledHours: () => range(0, dayjs().hour() - 1),
                  disabledMinutes: (hour) => {
                    if (hour === dayjs().hour()) {
                      return range(0, dayjs().minute());
                    }
                    return [];
                  },

                };
              }
              return {};
            }}
            onOk={(value) => {
              const date = value.utc().toISOString();
              const newArr = [...timeSlotsArray];
              newArr[slot] = date;
              dispatch(timeSlotsUpdate(newArr));
              timeSlotsArray = newArr;
            }}
          />
        </Space>
      </div>
    </div>
  );
};

export default DateComponent;
