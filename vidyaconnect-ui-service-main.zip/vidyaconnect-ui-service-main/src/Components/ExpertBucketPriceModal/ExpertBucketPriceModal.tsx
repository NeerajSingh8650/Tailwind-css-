import React, { useState, useCallback, useEffect } from "react";
import silverIcon from "../../assets/silver_user.svg";
import goldIcon from "../../assets/gold_user.svg";
import platinumIcon from "../../assets/platinum_user.svg";
import { Button } from "@/shadcn/ui/button";
import { MoveLeft } from "lucide-react";
import { useDispatch, useSelector } from "react-redux";
import {
    triggerExpertSearch,
} from "@/Redux/slices/FindAnExpertSlice";

import { RootState } from "@/Redux/store/store";
import { bookSessionResponseModalUpdate, expertPreferenceModalFlagUpdate, learnerTimePreferenceModalUpdate } from "@/Redux/slices/FlagsSLice";


const BucketCard: React.FC<{
    img: string;
    desc: string;
    color: string;
    label: string;
    bucket: string;
    border: string;
    isChecked: boolean;
    onChange: (label: string) => void;
}> = ({ img, desc, color, label, bucket, isChecked, onChange, border }) => {
    return (
        <label
            htmlFor={label}
            className={`mt-5 w-[350px] relative h-[123px] flex cursor-pointer items-center duration-75 gap-8 px-6 rounded-tl-none rounded-xl ${isChecked ? `shadow-[0_10px_10px_rgba(0,_0,_0,_0.7)]` : ""
                } border-2 ${border} ''}`}
        >
            <input
                className="absolute -left-7 top-1"
                type="checkbox"
                id={label}
                checked={isChecked}
                onChange={() => onChange(label)}
                aria-label={`Select ${label}`}
            />
            <div
                className={`absolute -left-[1.2px] w-[137px] h-[30px] rounded-t-xl flex items-center justify-center text-white ${color} -top-[30.8px]`}
            >
                {label}
            </div>
            <div>
                <img className="w-40" src={img} alt={label} />
            </div>
            <div>
                <h1 className="text-[18px] font-medium">₹{bucket}</h1>
                <p className="text-[14px]">{desc}</p>
            </div>
        </label>
    );
};

const ExpertBucketPriceModal = () => {
    const [selectedLabels, setSelectedLabels] = useState<string[]>([]);
    const [bucketFlag, setBucketFlag] = useState<boolean>(false);
    const dispatch: any = useDispatch();
    //const [bucketsPreference, setBucketsPreference] = useState<string[]>([]);
    // const bucketPref = useSelector(
    //     (state: RootState) => state.FindAnExpertApi.bucketArray
    // );
    const sessionDetails = useSelector((state: RootState) => state.getHelp);
    const timeslots = useSelector((state: RootState) => state.FindAnExpertApi.timeslots);
    const minutes = useSelector((state: RootState) => state.FindAnExpertApi.minutes);
    const domain = useSelector((state: RootState) => state.domainData.domain);


    const handleCheckboxChange = useCallback((label: string) => {
        setSelectedLabels((prev) =>
            prev.includes(label)
                ? prev.filter((item) => item !== label)
                : [...prev, label]
        );
    }, []);


    useEffect(() => {
        if (selectedLabels.length === 0) {
            setBucketFlag(false);
        } else {
            setBucketFlag(true);
        }
    }, [selectedLabels]);

 
    const onBack = () => {
        dispatch(expertPreferenceModalFlagUpdate(false));
        dispatch(learnerTimePreferenceModalUpdate(true));
    }

    const bookSession = () => {;
        const expertPreferences: string[] = selectedLabels.map(label => label.toUpperCase());
        dispatch(triggerExpertSearch({
            sessionDetails: sessionDetails,
            preferredSlots: timeslots,
            sessionDurationMinutes: minutes, 
            expertPreferences: expertPreferences,
            domainId: domain.id
        }))
    }

        return (
            <div className="h-screen w-screen fixed top-0 z-[999] left-0 bg-black/70">
                <div className="gap-8 py-5 w-[472px] flex items-center flex-col bg-white rounded-xl absolute z-40 translate-x-[-50%] translate-y-[-50%] top-[50%] left-[50%]">
                    <MoveLeft
                        onClick={onBack}
                        className="absolute top-7 left-4 text-black/40 w-[30px] cursor-pointer"
                    />
                    <h1 className="text-[24px] font-medium text-graymod-textfour">
                        Expert Preference
                    </h1>

                    <BucketCard
                        border="border-platinumText"
                        img={platinumIcon}
                        desc="Top-tier experts with unparalleled skills and exceptional ratings."
                        color="bg-platinumText"
                        label="Platinum"
                        bucket={"8000"}
                        isChecked={selectedLabels.includes("Platinum")}
                        onChange={handleCheckboxChange}
                    />

                    <BucketCard
                        img={goldIcon}
                        border="border-goldText"
                        desc="Experts with solid industry experience offering guidance at economical price point"
                        color="bg-goldText"
                        label="Gold"
                        bucket={"6000"}
                        isChecked={selectedLabels.includes("Gold")}
                        onChange={handleCheckboxChange}
                    />
                    <BucketCard
                        border="border-silverText"
                        img={silverIcon}
                        desc="Seasoned experts with advanced knowledge and extensive experience"
                        color="bg-silverText"
                        label="Silver"
                        bucket={"4000"}
                        isChecked={selectedLabels.includes("Silver")}
                        onChange={handleCheckboxChange}
                    />

                    {bucketFlag ? (
                        <Button
                            onClick={() => {
                                dispatch(expertPreferenceModalFlagUpdate(false))
                                dispatch(bookSessionResponseModalUpdate(true))
                                bookSession();
                            }}
                            className="mr-12 self-end"
                        >
                            Book
                        </Button>
                    ) : (
                        <Button className="bg-gray-400 mr-12 self-end hover:bg-gray-400">
                            Book
                        </Button>
                    )}
                </div>
            </div>
        );
};

export default ExpertBucketPriceModal;