import { X } from "lucide-react"
import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import userIcon from "../../assets/user-icon.svg";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchBookingDetails } from "@/Redux/slices/SessionDetailsSlice";
import { RootState } from "@/Redux/store/store";
import moment from "moment";
import { FaMoneyBills } from "react-icons/fa6";


interface ViewDetailsCardProps {
    onClose: () => void;
}

function ViewDetailsCard({ onClose}: ViewDetailsCardProps) {
    const dispatch: any = useDispatch()
    const sessionData = useSelector((state: RootState) => state.sessionDetails.booking);
    const sessionId = useSelector((state: RootState) => state.sessionDetails.sessionId);

    useEffect(() => {
        dispatch(fetchBookingDetails(sessionId))
    }, [])

    function convertUTCtoLocalDateTime(utcDateTime: string): moment.Moment {
        let localTime = moment.utc(utcDateTime).toDate();
        const local = moment(localTime);
        return local;
    }

    const sessionTime = (data: string) => {
        const a = convertUTCtoLocalDateTime(data)
        return a
    }

    return (
        <div className='fixed top-0 left-0 z-[999] w-screen h-screen bg-black/30 flex items-center justify-center'>
            <div className='h-[596px] w-[820px] rounded-lg overflow-hidden bg-white'>
                <div className='text-white flex items-center justify-between  h-[71px] rounded-lg bg-cyanmod-dark px-6'>
                    <p className="text-[24px] font-medium">Session Details</p>
                    <X onClick={onClose} className="cursor-pointer" />
                </div>
                <div className="flex flex-col gap-7 mt-6 px-[60px]">
                    <h1 className="text-[20px] font-medium px-[10px] text-graymod-textfour ">{sessionData?.title}</h1>
                    <p className="text-graymod-textthree px-[10px]">{sessionData?.description === "" ? "-" : sessionData?.description}</p>
                    <hr />
                    <div className="flex flex-col gap-3 px-[10px]">
                        <div className="grid grid-cols-2 gap-3">
                            <div className="flex items-center gap-2">
                                <img src={userIcon} alt="" />
                                <span className="text-graymod-texttwo">Expert</span>
                            </div>
                            <p className="text-graymod-texttwo text-nowrap">{sessionData?.expert}</p>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                            <div className="flex items-center gap-2">
                                <CalendarMonthIcon />
                                <span className="text-graymod-texttwo">Session Time</span>
                            </div>
                            <p className="text-graymod-texttwo text-nowrap">{sessionTime(sessionData?.sessionStart).format('MMMM D YYYY, h:mm a')} - {sessionTime(sessionData?.sessionStart).add(sessionData?.duration, 'minutes').format('h:mm a')}</p>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                            <div className="flex items-center gap-2">
                                <AccessTimeIcon />
                                <span className="text-graymod-texttwo">Booking request time</span>
                            </div>
                            <p className="text-graymod-texttwo text-nowrap">{sessionTime(sessionData?.createdAt).format('MMMM D YYYY, h:mm a')}</p>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                            <div className="flex items-center gap-2">
                                <FaMoneyBills/>
                                <span className="text-graymod-texttwo">Booking Amount</span>
                            </div>
                            <p className="text-graymod-texttwo text-nowrap">₹{sessionData?.amount}</p>
                        </div>
                    </div>
                    <hr />
                    <div className="flex flex-col gap-3 px-[10px]">
                        <p className="text-[14px] font-medium">Skills</p>
                        <div className="flex gap-2 flex-wrap">
                            {
                                sessionData?.skills === null ? "-" : sessionData?.skills?.map((data: any) => (
                                    <span
                                        key={data.id}
                                        className="py-1 px-3 rounded-3xl border text-[14px] text-graymod-darker border-graymod">{data}</span>
                                ))
                            }
                        </div>
                    </div>
                </div>

            </div>
        </div>
    )
}

export default ViewDetailsCard