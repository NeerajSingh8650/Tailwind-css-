import { useNavigate } from 'react-router-dom'
import "./LearnerGetLiveHelpModal.css";
import { useState, useEffect, useRef } from "react";
import CloseIcon from "@mui/icons-material/Close";
import { Skill, descriptionUpdate, getMatchedExperts, skillUpdate, titleUpdate } from "../../Redux/slices/GetLiveHelpSlice";
import axiosInstance from "../../api/axios"
import { useDispatch } from "react-redux";
import { Button } from "@/shadcn/ui/button";
import close from '../../assets/close.svg';
import { fetchDomainDetails } from '@/Redux/slices/DomainSlice';
import { learnerGetLiveHelpModalUpdate} from '@/Redux/slices/FlagsSLice';


const LearnerGetLiveHelpModal = () => {

  const dispatch: any = useDispatch()
  const skillInputRef = useRef<HTMLInputElement>(null);
  const titleFieldErrorRef = useRef<HTMLUListElement>(null);
  const skillsFieldErrorRef = useRef<HTMLUListElement>(null);
  const [title, setTitle] = useState<string>("");
  const [tagValue, setTagValue] = useState<string>('');
  const [skillsDropDown, setSkillsDropDown] = useState<Skill[]>([])
  const [selectedIndex, setSelectedIndex] = useState<number>(0);
  const [selectedSkills, setSelectedSkills] = useState<Skill[]>([]);
  const [isDropdownVisible, setIsDropdownVisible] = useState(false);

  const ulRef = useRef<HTMLUListElement>(null);
  const navigate = useNavigate();

  const toggleDropdown = () => {
    setIsDropdownVisible(!isDropdownVisible);
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTagValue(e.target.value);
    if (!isDropdownVisible) setIsDropdownVisible(true);
  };

  const onKey = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowDown') {
      if (selectedIndex < finalData.length - 1) {
        setSelectedIndex(prev => prev + 1)
      } else {
        setSelectedIndex(0)
      }
    }
    if (e.key === 'ArrowUp') {
      if (selectedIndex >= 1) {
        setSelectedIndex(prev => prev - 1)
      } else {
        setSelectedIndex(0)
      }
    }
    if (e.key === 'Enter') {
      setSelectedSkills([...selectedSkills, finalData[selectedIndex]])
      dispatch(skillUpdate([...selectedSkills, finalData[selectedIndex]]))
      handleZero()
      setIsDropdownVisible(false);
    }
    if(e.key === 'Backspace') {
      setIsDropdownVisible(false);
    }
  }

  // const openGetLiveScheduleModal = () => {
  //   dispatch(learnerTimePreferenceModalUpdate(true));
  //   modalStateFalse();
  // };


  // const updateDomainDetails = () => {
  //   const skillIds = selectedSkills.map(skill => skill.id)
  //   dispatch(fetchDomainDetails({
  //     skillIds
  //   }));
  //   return skillIds;
  // }

  const fetchAndStoreData = () => {
    const skillIds = selectedSkills.map(skill => skill.id)
    dispatch(getMatchedExperts({
      skillIds
    }));
    dispatch(fetchDomainDetails({
      skillIds
    }));
  };

  const handleRemoveTag = (indexToRemove: number) => {
    setSelectedSkills(selectedSkills.filter((_, index) => index != indexToRemove));
    dispatch(skillUpdate(selectedSkills));
  };


  const modalStateFalse = () => {
    dispatch(learnerGetLiveHelpModalUpdate(false));
  };


  const finalData = skillsDropDown.filter((data) => {
    if (selectedSkills.includes(data)) {
      return false
    }
    return tagValue === '' ? data : data.name.toLowerCase().includes(tagValue.toLowerCase())
  })


  const handleZero = () => {
    if (skillInputRef.current) {
      skillInputRef.current.value = '';
    }
  };

  useEffect(() => {
    if (ulRef.current && selectedIndex !== null) {
      ulRef.current.scrollTo({
        behavior: 'smooth',
      });
    }
  }, [selectedIndex]);




  useEffect(() => {
    const fetchData = async () => {
      try {
        const skillsRes = await axiosInstance.get(
          `/skills`,
        );
        if (skillsRes.status === 200) {
          setSkillsDropDown(skillsRes.data.data.skills)
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    fetchData()
  }, [])


  return (
    <>
      <div
        className={`getlivemodal w-[450px] rounded-lg flex flex-col gap-4 p-8`}
      >
        <div className="h-5 w-5 absolute right-5 top-2 text-[#00000048] cursor-pointer">
          <img src={close} className="cross-icon" onClick={modalStateFalse} />
        </div>
        <h1 className="text-[24px] font-medium">
          Get Live Help!
        </h1>
        <div>
          <div className="text-[16px] mb-8 mt-3 justify-between items-center">
            <label htmlFor="title">
              Name Your Session <span className="text-red-400">*</span>
            </label>
            <div className='block mt-2'>
              <input
                onChange={(e) => {
                  dispatch(titleUpdate(e.target.value))
                  setTitle(e.target.value)
                }}
                type="text"
                className="border border-graymod w-full text-[14px] rounded-lg outline-none py-2 ps-3"
                placeholder='Eg: Mastering French Formal Writing Skills'
              />
              <span ref={titleFieldErrorRef} className="hidden text-[14px] text-red-400 ml-2">Enter the Session Name</span>
            </div>
          </div>


          <div className="text-[16px] mb-8 justify-between items-center">
            <label htmlFor="title">
              Describe Your Request
            </label>
            <div className='block mt-2'>
              <textarea
                name=""
                id=""
                placeholder='Eg: I want to improve my grammar and writing skills in French, with a focus on formal communication.'
                onChange={(e) => dispatch(descriptionUpdate(e.target.value))}
                className="border border-graymod w-full h-[100px] text-[14px] rounded-lg py-2 ps-3 outline-none resize-none"
              ></textarea>
            </div>
          </div>
          <div className="text-[16px] mb-6 justify-between items-center">
            <label htmlFor="title">
              Desired Skills in your Expert <span className="text-red-400">*</span><span ref={skillsFieldErrorRef} className="hidden text-nowrap text-[16px] text-red-600 ml-2">Select atleast one skill</span>
            </label>

            <div className="flex p-2 h-28  flex-wrap  border rounded-lg border-[#dddd] mt-2">
              <div className="relative flex w-full">
                <div className="flex overflow-y-auto flex-wrap gap-2 mb-2 h-24">
                  {selectedSkills.map((data, index) => (
                    <div
                      key={index}
                      className="rounded-3xl px-3 py-1 gap-0 h-8 w-auto flex text-[14px] items-center justify-center bg-[#fcfcfd] border border-gray-300 hover:border-blue-300"
                    >
                      {data.name}
                      <button
                        onClick={() => {
                          handleRemoveTag(index)
                        }}
                        className="rounded-[50%] flex items-center justify-center h-6 pl-2 p-0"
                      >
                        <CloseIcon style={{ fontSize: "12px" }} />
                      </button>
                    </div>
                  ))}

                  <input
                    ref={skillInputRef}
                    type="text"
                    onChange={handleInputChange}
                    onFocus={toggleDropdown}
                    onClick={toggleDropdown}
                    onMouseEnter={() => {
                      setSelectedIndex(0)
                    }}
                    onKeyDown={(e) => {
                      onKey(e)
                    }}
                    placeholder="Enter skills here..."
                    className="outline-none px-2 text-wrap h-8"
                  />
                </div>
              </div>
              {isDropdownVisible && (
                <div className="block relative w-full">
                  <div
                    tabIndex={0}
                    className="w-full"
                  >
                    <ul ref={ulRef} className="shadow border-2 outline-none w-full absolute bg-white max-h-60 overflow-y-auto" tabIndex={0}>
                      {finalData.map((item, index) => (
                        <li
                          key={item.id}
                          className={` cursor-pointer h-10 flex px-2 items-center w-full ${selectedIndex === index ? 'border-2 border-cyanmod' : ''}`}
                          onMouseEnter={() => setSelectedIndex(index)}
                          onClick={() => {
                            setSelectedSkills([...selectedSkills, item])
                            dispatch(skillUpdate([...selectedSkills, item]))
                            handleZero()
                            setIsDropdownVisible(false);
                          }}
                        >
                          {item.name}
                        </li>
                      ))}
                    </ul>
                  </div>
                  </div>)}
            </div>
          </div>
        </div>


        <div className="flex justify-end my-1 gap-2">
          <Button
            onClick={() => {
              if (title !== '') {
                titleFieldErrorRef.current?.classList.add("hidden")
                titleFieldErrorRef.current?.classList.remove("inline")
                if (selectedSkills.length !== 0) {
                  fetchAndStoreData()
                  navigate("learner-select-expert")
                  modalStateFalse()
                  skillsFieldErrorRef.current?.classList.add("hidden")
                  skillsFieldErrorRef.current?.classList.remove("inline")
                } else {
                  skillsFieldErrorRef.current?.classList.add("inline")
                  skillsFieldErrorRef.current?.classList.remove("hidden")
                }
              } else {
                titleFieldErrorRef.current?.classList.add("inline")
                titleFieldErrorRef.current?.classList.remove("hidden")
              }
            }}
          >
            Next
          </Button>

          {/* <Button className='w-[180px]'
            onClick={() => {
              if (title !== '') {
                titleFieldErrorRef.current?.classList.add("hidden")
                titleFieldErrorRef.current?.classList.remove("inline")
                if (selectedSkills.length !== 0) {
                  openGetLiveScheduleModal()
                  updateDomainDetails();
                  skillsFieldErrorRef.current?.classList.add("hidden")
                  skillsFieldErrorRef.current?.classList.remove("inline")
                } else {
                  skillsFieldErrorRef.current?.classList.add("inline")
                  skillsFieldErrorRef.current?.classList.remove("hidden")
                }
              } else {
                titleFieldErrorRef.current?.classList.add("inline")
                titleFieldErrorRef.current?.classList.remove("hidden")
              }
            }}
          >
            Quick Match Session
          </Button> */}
        </div>
      </div>
    </>
  );
};

export default LearnerGetLiveHelpModal;
