import { Button } from "@/shadcn/ui/button";
import femaleAvatar from "../../assets/female-avatar-lg.svg";
import maleAvatar from "../../assets/male-avatar-lg.svg";
import learnerEditIcon from "../../assets/learner-edit-icon.svg"; 
import learnerTrashIcon from "../../assets/trash.svg"; 

interface childData {
    name : string;
    dob : string;
    gender : string;
    school : string;
    grade : string;
}

interface propsData {
    data : childData;
    onEdit : () => void;
    onDelete : () => void;
}

const ChildCard = ({data, onEdit, onDelete} : propsData) => {
    return (
        <div className="child-info-card border border-graymod border-25 px-10 py-10 mb-10">
                    <table className="full-width">
                        <tr>
                            <td className="w-[30%] justify-center align-center flex w-full">
                                <img
                                    src={data.gender.toLowerCase() == 'male'? maleAvatar : femaleAvatar}
                                    alt="Profile image"
                                    className="rounded-full"
                                    />
                            </td>
                            <td className="w-[70%] child-info-card-list">
                                <table className="w-[100%]">
                                    <tr>
                                        <th colSpan={2}><h3 className="font-medium text-[5px] lg:text-[24px] mb-10 justify-left" style={{ color: '#656565' }} >{data.name}</h3></th>
                                        <th className="mb-10 flex justify-end">
                                            <Button
                                                variant={'ghost'}  
                                                onClick={() => onEdit()} 
                                                className="py-2 px-2"
                                            >
                                                <img
                                                    src={learnerEditIcon}
                                                    alt="Edit"
                                                />
                                            </Button>
                                            <Button 
                                                variant={'ghost'} 
                                                onClick={onDelete} 
                                                className="py-2 px-2"
                                            >
                                                <img
                                                    src={learnerTrashIcon}
                                                    alt="Trash Card"
                                                    className="h-6 w-6"
                                                />
                                            </Button>
                                        </th>
                                    </tr>
                                    <tr>
                                        <td className="grey">Date of Birth</td>
                                        <td>{data.dob}</td>
                                    </tr>
                                    <tr>
                                        <td className="grey">Gender</td>
                                        <td>{data.gender}</td>
                                    </tr>
                                    <tr>
                                        <td className="grey">School</td>
                                        <td>{data.school}</td>
                                    </tr>
                                    <tr>
                                        <td className="grey">Grade</td>
                                        <td>{data.grade}</td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </div>
    )
}

export default ChildCard;