import { bookSessionResponseModalUpdate } from "@/Redux/slices/FlagsSLice";
import { RootState } from "@/Redux/store/store";
import { useDispatch, useSelector } from "react-redux";
import ExpertApprovalPendingModal from "./ExpertApprovalPendingModal/ExpertApprovalPendingModal";
import PaymentDueModal from "./PaymentDueModal/PaymentDueModal";

 const SessionBookedResponseModal = () => {
    const paymentAmountSelector = useSelector(
        (state: RootState) => state.expertExploreApi.prevPaymentAmount
      );

    const dispatch = useDispatch();

    const handleCloseBookSessionResponseModal = () => {
        dispatch(bookSessionResponseModalUpdate(false));
      };

      return (
        <div>
            {paymentAmountSelector ? (
                <PaymentDueModal
                    amountDue={paymentAmountSelector}
                    onClose={handleCloseBookSessionResponseModal}
                    onClearDues={handleCloseBookSessionResponseModal}
                />
            ) : (
                <ExpertApprovalPendingModal
                    onClose={handleCloseBookSessionResponseModal}
                    onClearDues={handleCloseBookSessionResponseModal}
                    desc="The expert has been notified about the session request and is pending for approval. You can track the status"
                />
            )}
        </div>
    ); 
}

export default SessionBookedResponseModal;
