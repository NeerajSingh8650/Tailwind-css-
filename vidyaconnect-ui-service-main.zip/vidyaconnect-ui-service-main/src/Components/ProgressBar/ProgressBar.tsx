import React from 'react';

interface ProgressBarProps {
    progress: number; // Expected to be between 0 and 3
}

const ProgressBar: React.FC<ProgressBarProps> = ({ progress }) => {

    const getBackgroundColor = (section: number) => {
        if (progress >= section) {
            if (section === 0) return 'bg-gray-200';
            if (section === 1) return 'bg-cyan-500';
            if (section === 2) return 'bg-cyan-500';
            if (section === 3) return 'bg-cyan-500';
        }
        return 'bg-gray-200'; 
    };

    return (
        <div className="grid grid-cols-6 gap-4">
            <div className='col-start-2 col-span-4 mb-[40px]'>
                <div className="h-2 w-full rounded flex progress-bar">
                    <div
                        className={`h-full ${getBackgroundColor(1)} rounded-l`}
                        style={{ width: `33.33%` }}
                    ></div>
                    <div
                        className={`h-full ${getBackgroundColor(2)}`}
                        style={{ width: `33.33%` }}
                    ></div>
                    <div
                        className={`h-full ${getBackgroundColor(3)} rounded-r`}
                        style={{ width: `33.33%` }}
                    ></div>
                </div>
            </div>
        </div>
    );
};

export default ProgressBar;
