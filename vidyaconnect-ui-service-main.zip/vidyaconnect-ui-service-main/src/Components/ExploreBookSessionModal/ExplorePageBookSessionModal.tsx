import './ExplorePageBookSession.css'
import { useState, useRef } from 'react';
import { useDispatch } from 'react-redux';
import { descriptionUpdate, titleUpdate } from '../../Redux/slices/GetLiveHelpSlice';
import { bookingSessionModalFlagUpdate, ExploreBookSessionModalUpdate } from '../../Redux/slices/FlagsSLice';
import { Button } from '@/shadcn/ui/button';
import close from '../../assets/close.svg'



const ExplorePageBookSessionModal = ()  => {
    const inputRef: any = useRef<HTMLInputElement>(null);
    const [titleFlag, setTitleFlag] = useState<boolean>(false)
    const dispatch = useDispatch()
 

    const handleChange = () => {
        if (inputRef.current?.value) {
            dispatch(titleUpdate(inputRef.current.value));
            dispatch(bookingSessionModalFlagUpdate(true));  
            dispatch(ExploreBookSessionModalUpdate(false));
          } else {
            setTitleFlag(true);
          }
    }

    const TitleInput = () => {
        return (
            <div className='text-[16px] mb-3 mt-4 justify-between items-center'>
                <label htmlFor="title">Name Your Session <span className={`text-red-400 "inline"}`}>*</span></label>
                <div className='block mt-2'>
                    <input
                        ref={inputRef}
                        onChange={(e) => {
                            dispatch(titleUpdate(e.target.value))
                        }}
                        className='w-full block text-[16px] border border-graymod rounded-md outline-none px-2 py-2' id='title' type="text" />
                    {titleFlag && <span className='text-red-600 text-xs'>Field is required</span>}
                </div>
            </div>
        )
    }

    const DesInput = () => {
        return (
            <div className='text-[16px] mb-3 justify-between items-center'>
                <label htmlFor="title">Describe Your Request</label>
                <div className='block mt-2'>
                    <textarea
                        onChange={(e) => {
                            dispatch(descriptionUpdate(e.target.value));
                        }}
                        className="border border-graymod w-full h-[181px] font-normal text-[14px] rounded-lg py-2 ps-3 outline-none resize-none"
                    ></textarea>
                </div>
            </div>
        )
    }

    
    const closeModal = () => {
        dispatch(ExploreBookSessionModalUpdate(false));
    };
  
  
    return (
        <>
            <div
                className="modal-backdrop fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50"
                onClick={closeModal}
            >
            </div>
            <div className='exploreBookSession  w-[405px] rounded-lg flex flex-col gap-4 p-8'>
                <div onClick={() => closeModal()} className='h-5 w-5 text-[16px] absolute right-5 top-4 text-[#00000048] cursor-pointer'>
                    <img src={close} className="cross-icon" alt="" />
                </div>
                <h1 className='text-[24px] font-medium text-left'>Book Session</h1>
                <TitleInput />
                <DesInput />
                <div className='w-[100%] text-right'>
                <Button className='self-end' onClick={handleChange}>
                    Next
                </Button>
                </div>
            </div>
        </>
    )
    }
   
export default ExplorePageBookSessionModal