import React, { useState, useEffect } from "react";
import axios from "axios";
import { toast } from 'react-toastify';
import { Button } from '@/shadcn/ui/button';
import { useNavigate } from "react-router-dom";
import { setIsResetPasswordModal, setisSuccessPasswordModal } from "@/Redux/slices/authSlice";
import { useDispatch } from "react-redux";
import openEye from "../../assets/openEyeSvg.svg"
import closeEye from "../../assets/closeEye.svg"
import { validatePassword } from "@/utils/PasswordUtitilities";
axios.defaults.withCredentials = true;

interface ResetPasswordModalProps {
  onClose: () => void;
  onSignIn: () => void;
  showResetPasswordModal: (value: boolean) => void;

}

const ResetPasswordModal: React.FC<ResetPasswordModalProps> = ({ onClose, showResetPasswordModal }) => {

  const navigate = useNavigate()
  const dispatch  = useDispatch()
  const [showPassword, setShowPassword] = useState(false);
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [confirmPasswordError, setConfirmPasswordError] = useState<string>("");
  const [userData, setUserData] = useState<{ email: string; profile: string }>({
    email: "",
    profile: "",
  });


  useEffect(() => {
    const storedUserData = localStorage.getItem("userdata");
    if (storedUserData) {
      try {
        const parsedUserData = JSON.parse(storedUserData);
        setUserData(parsedUserData);
      } catch (error) {
        console.error("Error parsing user data from localStorage:", error);
      }
    }
  }, []);

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newPassword = e.target.value;
    setPassword(newPassword);
    setPasswordError(validatePassword(newPassword));
  };



  const handleConfirmPasswordChange = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const newPassword = e.target.value;
    setConfirmPassword(newPassword);
    validateConfirmPassword(newPassword);
  };

  const validateConfirmPassword = (confirmPassword: string) => {
    if (confirmPassword !== password) {
      setConfirmPasswordError("Password and confirm password do not match.");
    } else {
      setConfirmPasswordError("");
    }
  };

  const handleEyeClick = () => {
    togglePasswordVisibility();
  };


  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (!password || !confirmPassword) {
      setPasswordError("Password and confirm password cannot be empty.");
      return;
    }
    const email = userData.email
    try {
      const apiUrl = import.meta.env.VITE_REACT_APP_API_BASE_URL;
      const response = await axios.put(
        `${apiUrl}/tenant/password/${email}`,
        {
          password,
        },
        {
          withCredentials: true,
        }
      );
      if (response.data.success) {
        toast.success('Password updated successfully!');
        showResetPasswordModal(false);
        onClose();
        navigate("/")
        dispatch(setIsResetPasswordModal(false))
        dispatch(setisSuccessPasswordModal(true))
      } else {
        toast.error(response.data.error);
      }
    } catch (error) {
      console.error("API Call Error:", error);
    }
  };



  return (
    <div className="social-modal open w-[28rem]">
      <h3 className="font-medium text-[28px] text-center mb-14">Reset Password</h3>
      <form onSubmit={handleSubmit}>
        <div className="relative">
          <input
            type={showPassword ? "text" : "password"}
            name="create-password"
            value={password}
            onChange={handlePasswordChange}
            placeholder="Create password"
            className={`border ${passwordError ? "border-red-500" : "border-graymod"
              } w-full font-extralight text-[16px] rounded-xl py-2 ps-3 outline-none`}
          />
          <span
            className="absolute right-3 top-1/2 transform -translate-y-1/2 cursor-pointer"
            onClick={handleEyeClick}
          >
            {showPassword ? (
              <img src={closeEye} className="h-[17px]" alt="" />
            ) : (
              <img src={openEye} className="h-[17px]" alt="" />
            )}
          </span>
        </div>
        {passwordError && (
          <p className="text-red-500 text-sm mt-1">{passwordError}</p>
        )}
        <div className="relative mt-10">
          <input
            type={showPassword ? "text" : "password"}
            name="Confirm-password"
            value={confirmPassword}
            onChange={handleConfirmPasswordChange}
            placeholder="Confirm password"
            className={`border ${confirmPasswordError ? "border-red-500" : "border-graymod"
              } w-full font-extralight text-[16px] rounded-xl py-2 ps-3 outline-none`}
          />
          <span
            className="absolute right-3 top-1/2 transform -translate-y-1/2 cursor-pointer"
            onClick={handleEyeClick}
          >
            {showPassword ? (
              <img src={closeEye} className="h-[17px]" alt="" />
            ) : (
              <img src={openEye} className="h-[17px]" alt="" />
            )}
          </span>
        </div>
        {confirmPasswordError && (
          <p className="text-red-500 text-sm mt-1">{confirmPasswordError}</p>
        )}
        <div className="flex justify-center mt-12 mb-[40px]">
          <Button
            type="submit"
          >
            Continue
          </Button>
        </div>
      </form>
    </div>
  );
};

export default ResetPasswordModal;
