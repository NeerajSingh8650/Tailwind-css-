import React from "react";
import { useDispatch } from "react-redux";
import { closeModal } from "../../Redux/slices/authSlice";
import close from '../../assets/close.svg';
import { Button } from "@/shadcn/ui/button";


interface PasswordVerificationModalProps {
  onClose: () => void;
  onEmailChange: () => void;
}

const PasswordVerificationModal: React.FC<PasswordVerificationModalProps> = ({
  onClose,
  onEmailChange
}) => {
  const dispatch = useDispatch();

  return (
    <>
      <div className="social-modal open w-[28rem]">
        <div className=" w-5 absolute right-5 top-4 text-[#00000048] cursor-pointer">
          <img src={close} className="cross-icon" onClick={() => {
            onClose();
            dispatch(closeModal())
          }} />
        </div>
        <h3 className="font-medium text-[28px] text-center">
          Check Your Inbox
        </h3>
        <div className="">
          <p className="text-[18px] font-normal text-center mt-3">
            We have sent a verification link to your email. Please click the link to reset your password.
          </p>
          <p className="font-normal text-[16px] text-center mb-6 mt-[60px]">
            Not your account?
            <Button
              className="text-[16px]"
              onClick={onEmailChange}
              variant={"link"}>
              Change Email address
            </Button>
          </p>
        </div>
      </div>
    </>
  );
};

export default PasswordVerificationModal;
