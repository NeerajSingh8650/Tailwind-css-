import { useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import axios, { AxiosResponse } from "axios";
import ResetPasswordModal from "./ResetPasswordModal";
import { useDispatch, useSelector } from "react-redux";
import { setIsResetPasswordModal } from "@/Redux/slices/authSlice";
import { RootState } from "@/Redux/store/store";
import { toast } from "react-toastify";
interface ResetPasswordProps {
  showResetPasswordModal: (value: boolean) => void;
}

interface ResetPasswordResponse {
  data: {
    email: string;
  };
}

const ResetPassword: React.FC<ResetPasswordProps> = ({ showResetPasswordModal }): any => {
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const token = params.get("token") || "";
  const navigate = useNavigate();
const dispatch = useDispatch()
const selector = useSelector((state:RootState) => state.auth.isResetPasswordModal)
  useEffect(() => {
    const resetPassword = async () => {
      try {
        const apiUrl = import.meta.env.VITE_REACT_APP_API_BASE_URL;
        const response: AxiosResponse<ResetPasswordResponse> = await axios.get(
          `${apiUrl}/tenant/forgot-password?token=${token}`
        );
        const { email } = response.data.data;
        console.log("verification done")
        // Serialize data into a single string and store in localStorage
        const userData = JSON.stringify({ email });
        localStorage.setItem("userdata", userData);
        dispatch(setIsResetPasswordModal(true))
        showResetPasswordModal(true);
      } catch (error) {
        toast.error("Link expired")
        dispatch(setIsResetPasswordModal(false))
        console.error("Password reset failed:", error);
      }
    };

    resetPassword();
  }, [token, navigate, showResetPasswordModal]);

  return (<>
    {selector && <ResetPasswordModal onSignIn={() => { }}
      onClose={() => {}}
      showResetPasswordModal={() => true}
    />}
  </>
  )
};

export default ResetPassword;
