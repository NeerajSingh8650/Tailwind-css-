import React, { useState } from "react";
import * as Yup from "yup";
import { useFormik } from "formik";
import { useDispatch } from "react-redux";
import { forgotPassword } from "../../Redux/slices/authSlice";
import { Button } from '@/shadcn/ui/button';
import PasswordVerificationModal from "./PasswordVerificationModal";
import { Input } from "../ui/input";
import close from '../../assets/close.svg';
interface ForgotPasswordModalProps {
  onClose: () => void;
  onSignIn: () => void;
  userTypeValue: string;
}

const signupSchema = Yup.object().shape({
  email: Yup.string().email("Please enter valid email").required(),
});

const ForgotPasswordModal: React.FC<ForgotPasswordModalProps> = ({ onClose, userTypeValue, }) => {
const [isPasswordVerificationModal, setIsPasswordVerificationModal] = useState<boolean>(false)
  const dispatch: any = useDispatch();
  const { values, handleChange, handleSubmit, errors, touched } = useFormik({
    initialValues: {
      email: "",
      profile: userTypeValue,
    },
    validationSchema: signupSchema,
    onSubmit: (values) => {
      dispatch(forgotPassword(values));
      setIsPasswordVerificationModal(true)
    },
  });



  if (isPasswordVerificationModal) {
    return (<>
      <PasswordVerificationModal
        onClose={()=> setIsPasswordVerificationModal(false)}
        onEmailChange={() => {
          setIsPasswordVerificationModal(false);
          values.email = '';
        }}
      />
    </>
    )
  }

  return (
    <>
      <div className="social-modal open w-[28rem] ">
        <div className="h-5 w-5 absolute right-5 top-4 text-[#00000048] cursor-pointer">
          <img src={close} className="cross-icon" onClick={onClose} />
        </div>
        <h3 className="font-medium text-[28px] text-center mb-4">Forgot Password</h3>
        <div>
          <form onSubmit={handleSubmit}>
            <div className="mb-10">
              <h3 className="font-medium text-[18px] text-center mb-8">
                Enter Your Email
              </h3>
              <Input
                type="text"
                className="text-[16px]"
                placeholder="Enter email"
                name="email"
                value={values.email}
                onChange={handleChange}
              />
              {touched.email && errors.email && (
                <p className="text-red-500 text-xl mt-1">{errors.email}</p>
              )}
            </div>
            <div className="flex justify-center">
              <Button
                type="submit"
              >
                Continue
              </Button>
            </div>
            <p className="text-[18px] text-center mb-6 mt-[40px]">
              We will send a link to email to reset your password if the user account exist.
            </p>
          </form>
        </div>
      </div>
    </>
  );
};

export default ForgotPasswordModal;