import React, { useState } from 'react';
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import MoreHorizIcon from "@mui/icons-material/MoreHoriz";
import { parseISO, addMinutes, format } from 'date-fns';
import { sessionIdUpdate } from "@/Redux/slices/SessionDetailsSlice";
import {useDispatch} from 'react-redux'
import ViewDetailsCard from "../ViewDetailsCard/ViewDetailsCard";

import {
  BOOKING_STATUS_EXPIRED,
  BOOKING_STATUS_CANCELLED,
  BOOKING_STATUS_REJECTED,
} from "../../constants";
import { Button } from "@/shadcn/ui/button";



type Data = {
  title: string;
  expert: string;
  sessionStart  : string;
  duration : number,
  status : string,
  id : number 
};

interface ComponentProps{
  sessionData : Data
}



const SessionCards: React.FC<ComponentProps> = ({ sessionData }) => {
 
  const {title, expert , duration, sessionStart , status, id} = sessionData
  const [tooltipShow , setToolTipShow] = useState(false)
 
  const [isViewSession, setIsViewSession] = useState<boolean>(false)
  const dispatch = useDispatch();

  function formatDuration(dateString: string, durationInMinutes: number): string {
    const startDate = parseISO(dateString); // Parse the ISO date string to Date object
  
    const startTime = format(startDate, 'HH:mm'); // Format start time as hh:mm
    const endDate = addMinutes(startDate, durationInMinutes); // Add duration to start time
    const endTime = format(endDate, 'HH:mm'); // Format end time as hh:mm
  
    return `${startTime} - ${endTime}`; // Combine formatted times
  }



  function formatDate(dateString: string): string {
    const date = new Date(dateString);
    const options: Intl.DateTimeFormatOptions = {
      month: 'short',  
      day: 'numeric',  
      year: 'numeric' 
    };
    return date.toLocaleDateString('en-US', options);
  }





  const getStatusBgColor = (labelText: string) => {
    switch (labelText) {
      case BOOKING_STATUS_EXPIRED:
        return "#c9c9c9"; 
      case BOOKING_STATUS_REJECTED:
        return "#f88c8c";
      case BOOKING_STATUS_CANCELLED:
        return "#f88c8c";
    }
  };


  const handleTooltip : any = ()=>{
    
    setToolTipShow(prevstate => !prevstate)
  }
 
 


  const handleViewDetail = ()=>{
    dispatch(sessionIdUpdate(id)) 
    setIsViewSession(true) 
    setTimeout(() => {
      setToolTipShow(false)
    }, 500);
  }

   
   
  return (
    <div className="border border-gray-300 rounded-lg shadow-lg p-4 bg-white mb-2 relative">
       {
         isViewSession && 
         <ViewDetailsCard onClose={() => setIsViewSession(false)}/>
       }
         <div className='relative'>
         <div
          className="w-[100px] h-[25px] rounded-full px-4 gap-1 mb-3 flex justify-center items-center"
          style={{
            backgroundColor: getStatusBgColor(status),
          }}
        >
          <p className="badge-new-info text-[10.42px] text-white text-nowrap">
            {status}
          </p>
        </div>
          <div className="absolute top-0 right-0 cursor-pointer" onClick={handleTooltip}>
            <MoreHorizIcon/>
          </div>
         </div>

        {(tooltipShow)  && (
       <div className='absolute top-12 right-5 bg-white border border-[#dddddd] outline-none rounded-lg shadow-md z-10 py-2 w-[138px] cursor-pointer'>
        <p
              onClick={() => {
                handleViewDetail();
              }}
              className="cursor-pointer text-[12px] ms-3"> View Details 
              </p>    
       </div>
        )}
    

      <h2 className="text-sm font-semibold mb-2 text-[#656565] text-justify">{title}</h2>
    
       <div className='py-6'>

        <p className='mb-2'>
           <PersonOutlineIcon  className='text-[#949494]'/>
            <span className='capitalize text-[#949494] font-[400] ml-3'>{expert}</span>
        </p>

        <p className='mb-2'>
          <CalendarMonthIcon className='text-[#000]'/>
          <span className='capitalize text-[#949494] font-[400] ml-3'>{formatDate(sessionStart)}</span>
        </p>

        <p>
          <AccessTimeIcon className='text-[#000]'/>
          <span className='capitalize text-[#949494] font-[400] ml-3'>{formatDuration(sessionStart, duration)}</span>
        </p>
       </div>

      <div className='text-right'>
      <Button
        onClick={()=>{}}
        className="px-4 py-2 bg-[#09A5D6] text-white rounded hover:bg-[#09A5D6] focus:outline-none focus:ring-2 focus:ring-blue-500 text-[12px] "
      >
           Book Again
      </Button>
      </div>
    </div>
  );
};

export default SessionCards;
