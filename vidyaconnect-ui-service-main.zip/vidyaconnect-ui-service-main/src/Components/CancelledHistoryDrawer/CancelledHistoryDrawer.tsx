
import React, {useEffect} from 'react'
import Classes from './CancelledHistoryDrawer.module.css'
import CloseIcon from '@mui/icons-material/Close';
import {useSelector, useDispatch} from 'react-redux'
import {RootState} from '../../Redux/store/store'
import {cancelledSessionDrawerFlagUpdate} from '../../Redux/slices/FlagsSLice'
import {fetchCancelledSession} from '../../Redux/slices/SessionRequestSlice'
import SessionCard from './SessionsCard';


const CancelledHistoryDrawer: React.FC = () => {
    const dispatch:any = useDispatch();
    const cancelledSessionData = useSelector((state:RootState)=>state.session.cancelledData)


    const handleClose = ()=>{
     dispatch(cancelledSessionDrawerFlagUpdate(false))
    }


     
    useEffect(()=>{
           dispatch(fetchCancelledSession())
    }, [])


     
  return (
    <>
    <div className='absolute z-[101] h-[100vh] w-[100vw] top-0 left-0 bg-[transparent]' onClick={()=>{handleClose()}}>
        <div className={`absolute z-[102] top-0 right-0 w-[300px] mt-[87px] h-[580px] bg-[#fff] ${Classes.mainContainer} overflow-scroll rounded-sm`}
        onClick={(e) => e.stopPropagation()}
        >

          <div className='text-center h-[50px] bg-[#002834] flex justify-center items-center text-[#fff] relative'>
            Cancelled Sessions

            <div onClick={handleClose} className='absolute right-2'>
            <CloseIcon className='cursor-pointer'/>
            </div>

          </div>

            <div className={Classes.sessions_container}>
                {cancelledSessionData.map((SessionData : any)=>{
                    return(
                        <SessionCard sessionData={SessionData}/>
                    )
                })}
            </div>
        </div>
    </div>
    
    </>
  )
}

export default CancelledHistoryDrawer