import RemoveCookies from "../RemoveCookies/RemoveCookies";
import { useNavigate } from "react-router-dom";
import PersonOutlineOutlinedIcon from "@mui/icons-material/PersonOutlineOutlined";
import HistoryOutlinedIcon from "@mui/icons-material/HistoryOutlined";
import QuestionAnswerOutlinedIcon from "@mui/icons-material/QuestionAnswerOutlined";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import PendingOutlinedIcon from "@mui/icons-material/PendingOutlined";
import { useSelector } from "react-redux";
import { RootState } from "@/Redux/store/store";
import { PROFILE } from "@/constants";

interface profileDialogProps{
  onClose: () => void
}

const ProfileOptionDialog = ({onClose} : profileDialogProps) => {
  const { userDetails } = useSelector((state: RootState) => state.user);
  const navigate = useNavigate();

  if (!userDetails?.profile) {
    return null;
  }
  return (
    <>
      <div className="absolute top-[70px] right-[70px] w-[240px] bg-white border border-1 border-[#C7C7C7] rounded-[6px] flex flex-col items-center justify-center z-40 pt-4 pb-4 shadow-[0_5px_15px_0_rgba(0,0,0,0.15)]">
        <div className="flex flex-col mb-4 w-full justify-center items-center">
          <h1 className="font-medium text-[18px]">
            {userDetails?.firstName} {userDetails?.lastName}
          </h1>
          <p className="text-[13px]">{userDetails?.email}</p>
        </div>
        <div className="border border-b-0 border-r-0 border-l-0 w-full py-3 flex flex-col gap-3 px-5">

          
            {userDetails?.profile.toLowerCase() === PROFILE.EXPERT &&
              <button className="h-10 w-[195px] flex flex-row items-center gap-2 rounded-[5px] pl-2 text-[16px]"
              onClick={() => {
                onClose();
                navigate("/expert-work-profile");
              }}>
                <span>
                  <PersonOutlineOutlinedIcon />
                </span>
                <p>My Work Profile</p>
              </button>
            }

          <button
            onClick={() => {
              onClose();
              navigate("/sessions-history-learner");
            }}
            className="h-10 w-[195px] flex flex-row items-center gap-2 rounded-[5px] pl-2 text-[16px]"
          >
            <span>
              <HistoryOutlinedIcon />
            </span>
            <p>Session History</p>
          </button>
          {userDetails?.profile.toLowerCase() === PROFILE.LEARNER && (
            <button onClick={() => {
              navigate("/pending-payments")
              onClose();
            }} className="h-10 w-[195px] flex flex-row items-center gap-2 rounded-[5px] pl-2 text-[16px]">
              <span>
                <PendingOutlinedIcon />
              </span>
              <p>Pending Payments</p>
            </button>
          )}
        </div>
        <div className="border border-r-0 border-l-0 w-full py-3 flex flex-col gap-3 px-5">
          <button className="h-10 w-[195px] flex flex-row items-center gap-2 rounded-[5px] pl-2 text-[16px]"
          onClick={() => {
            navigate("/help")
            onClose();
          }}>
            <span>
              <QuestionAnswerOutlinedIcon />
            </span>
            <p>Help</p>
          </button>


          <button onClick={()=>{
            if(userDetails?.profile.toLowerCase() === PROFILE.LEARNER){
              onClose();
              navigate("/learner-settings")
            } else {
              onClose();
              navigate("/expert-settings")
            }
          }} className="h-10 w-[195px] flex flex-row items-center gap-2 rounded-[5px] pl-2 text-[16px]">
            <span>
              <SettingsOutlinedIcon />
            </span>
            <p>Settings</p>
          </button>
        </div>
        <RemoveCookies />
      </div>
    </>
  );
};

export default ProfileOptionDialog;
