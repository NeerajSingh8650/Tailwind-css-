import { Routes, Route } from "react-router-dom";
import Main from "./Layout/Main";
import "./App.css";
import ConfirmationPage from "./Pages/ExpertOnboarding/ConfirmationPage";
import VerifyUser from "./Pages/VerifyUser/VerifyUser";
import { useState } from "react";
import LearnerSelectExpert from "./Pages/LearnerSelectExpert/LearnerSelectExpert";
import LearnerExpertPreference from "./Pages/LearnerExpertPreference/LearnerExpertPreference";
import LearnerPendingRequests from "./Pages/LearnerPendingRequests/LearnerPendingRequests";
import LearnerPersonalInformation from "./Pages/LearnerPersonalInformation/LearnerPersonalInformation";
import ExpertAccountSetting from "./Pages/ExpertPortal/ExpertAccountSetting/ExpertAccountSetting";
import ExpertFeedback from "./Pages/ExpertPortal/ExpertFeedback/ExpertFeedback";
import LearnerExplorePage from "./Pages/LearnerExplorePage/LearnerExplorePage";
import ExpertPendingRequest from "./Pages/ExpertPortal/ExpertPendingRequest/ExpertPendingRequest";
import LearnerPortalHomepage from "./Pages/Dashboard/LearnerPortalHomepage/LearnerPortalHomepage";
import ExpertDashboardHomepage from "./Pages/Dashboard/ExpertDashboard/ExpertDashboardHomepage/ExpertDashboardHomepage";
import ExpertProfile from "./Pages/Dashboard/ExpertDashboard/ExpertProfile/ExpertProfile";
import ExpertViewProfilePage from "./Pages/UserProfilePage/ExpertViewProfilePage";
import { Provider } from "react-redux";
import { store } from "./Redux/store/store";
import PendingPaymentPage from "./Pages/PendingPaymentPage/PendingPaymentPage";
import Onboarding from "./Pages/onboarding";
import SessionHistoryPageExpert from "./Pages/SessionHistoryPage/SessionHistoryPageExpert";
import SessionHistoryPageLeaner from "./Pages/SessionHistoryPage/SessionHistoryPageLearner";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import ExpertDomainPricePage from "./Pages/ExpertDomainPricePage/ExpertDomainPricePage";
import LearnerChildrenInformation from "./Pages/LearnerChildrenInformationPage/LearnerChildrenInformation";
import LearnerSettingsPage from "./Pages/SettingPersonalPage/LearnerSettingsPage";
import ForgotPasswordPage from "./Pages/ForgotPasswordPage/ForgotPasswordPage";
import OAuth2Redirect from "./Components/SignUpSocialModal/OAuth2Redirect";
import ExpertSettingsPage from "./Pages/SettingPersonalPage/ExpertSettingsPage";
import WorkProfileUpdatedSuccessFullyModal from "./Components/WorkProfileUpdatedSuccessfully/WorkProfileUpdatedSuccessfully";
import HelpPage from "./Pages/Help/HelpPage";
import FAQsPage from "./Pages/Help/FAQsPage";
import ContactUs from "./Pages/Help/ContactUs";
import FeedbackExpert from '@/Pages/FeedbackExpert/index'
import Terms from "./Pages/Legal/Terms";
import Privacy from "./Pages/Legal/Privacy";
import Cookies from "./Pages/Legal/Cookies";

import LandingPage from "./Pages/LandingPage/LandingPage";
import LearnerTab from "./Pages/LandingPage/LearnerTab";
import ExpertTab from "./Pages/LandingPage/ExpertTab";
import AskAI from "./Pages/AskAI/AskAI";


const App = () => {
  const [showPasswordModal, setShowPasswordModal] = useState(false);

  return (
    <Provider store={store}>
          <Main>
            <Routes>
              
              <Route
                path="/"
                element={<LandingPage showPasswordModal={showPasswordModal} />}
              />
              <Route path="/onboarding" element={<Onboarding />} />

              <Route path="/LandingPage" element={<LandingPage showPasswordModal={showPasswordModal} />} />

              <Route path="/expert-opportunities" element={<ExpertTab />} />

              <Route path="/learner-opportunities" element={<LearnerTab  />} />

              <Route
                path="/verify"
                element={
                  <VerifyUser setShowPasswordModal={setShowPasswordModal} />
                }
              />
              <Route path="/confirmation" element={<ConfirmationPage />} />

              <Route path="/ask-ai" element={<AskAI />} />

              <Route
                path="/learner-expert-preference"
                element={<LearnerExpertPreference />}
              />
              <Route
                path="/learner-pending-request"
                element={<LearnerPendingRequests />}
              />
              <Route path="/explore-experts" element={<LearnerExplorePage />} />
              <Route
                path="/learner-select-expert"
                element={<LearnerSelectExpert />}
              />
              <Route
                path="/learner-personal-information"
                element={<LearnerPersonalInformation />}
              />
              <Route
                path="/learner-children-information"
                element={<LearnerChildrenInformation />}
              />

              <Route
                path="/expert-account-setting"
                element={<ExpertAccountSetting />}
              />
              <Route path="/expert-feedback" element={<ExpertFeedback />} />
              <Route
                path="/expert-pending-request"
                element={<ExpertPendingRequest />}
              />
              <Route
                path="/succesfullyupdated"
                element={<WorkProfileUpdatedSuccessFullyModal />}
              />
              <Route
                path="/pending-payments"
                element={<PendingPaymentPage />}
              />
              <Route
                path="/sessions-history-expert"
                element={<SessionHistoryPageExpert />}
              />
              <Route
                path="/sessions-history-learner"
                element={<SessionHistoryPageLeaner />}
              />
              <Route
                path="/expert-settings"
                element={<ExpertSettingsPage />}
              />
              <Route
                path="/learner-settings"
                element={<LearnerSettingsPage />}
              />
              <Route
                path="/expert-pricing"
                element={<ExpertDomainPricePage />}
              />
              <Route
                path="/dashboard/learner-portal-home"
                element={<LearnerPortalHomepage />}
              />
              <Route
                path="/dashboard/expert-home"
                element={<ExpertDashboardHomepage />}
              />

              <Route
                path="/expert-work-profile"
                element={<ExpertProfile />}
              />
              <Route
                path="/forgot-password"
                element={<ForgotPasswordPage />}
              />
              <Route
                path="/help"
                element={<HelpPage />}
              />
              <Route
                path="/help/faqs"
                element={<FAQsPage />}
              />
              <Route
                path="/help/contact-us"
                element={<ContactUs />}
              />
              <Route path="/feedback/:sessionToken" Component={FeedbackExpert}/>
              <Route path="/oauth2/redirect" element={<OAuth2Redirect />} />
              <Route path="/terms" element={<Terms/>} />
              <Route path="/privacy" element={<Privacy/>} />
              <Route path="/cookies-policy" element={<Cookies/>} />
              <Route path="/expert/profile/:expertIdParam" Component={ExpertViewProfilePage}/>
            </Routes>

            

          </Main>
      <ToastContainer />
    </Provider>
  );
};

export default App;
