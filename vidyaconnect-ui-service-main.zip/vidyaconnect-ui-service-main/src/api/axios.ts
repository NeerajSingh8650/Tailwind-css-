import { removeCookies } from "@/config/sessionHelper";
import axios from "axios";

const baseURL = import.meta.env.VITE_REACT_APP_API_BASE_URL;

if (!baseURL) {
  console.error("VITE_REACT_APP_API_BASE_URL is not defined");
}

const axiosInstance = axios.create({
  baseURL,
  withCredentials: true,
});

axiosInstance.interceptors.request.use((request) => {
  return request;
});

axiosInstance.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    if (error.response.status === 401) {
      sessionStorage.clear();
      localStorage.clear();
      removeCookies()
      if (error.config && !error.config.url.includes('/auth/login')) {
        window.location.href = "/";
      }
    }
    return Promise.reject(error);
  }
);

export default axiosInstance;
