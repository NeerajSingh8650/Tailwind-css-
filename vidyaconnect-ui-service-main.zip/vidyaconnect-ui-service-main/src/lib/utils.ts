import { type ClassValue, clsx } from "clsx";
import moment from "moment";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const getQueryParamsFormUrl = (url: string) => {
  const urlObj = new URL(url);
  const queryString = urlObj.search;

  // Extract query parameters
  const queryParams = new URLSearchParams(queryString);
  const queryParamsObject: any = {};

  queryParams.forEach((value, key) => {
    queryParamsObject[key] = value;
  });
  return queryParamsObject;
};

export const getLocalTimeZone = () => {
  return Intl.DateTimeFormat().resolvedOptions().timeZone;
};

export const compareWithCurrentTime = (timeString: string) => {
  // Get the current time
  const currentTime = moment();

  const givenTime = moment(timeString, "HH:mm:ss").set({
    year: currentTime.year(),
    month: currentTime.month(),
    date: currentTime.date(),
  });
  const fiveMinutesAgo = currentTime.subtract(5, "minutes");
  if (givenTime.isBefore(fiveMinutesAgo)) {
    return true;
  }

  if (givenTime.isAfter(currentTime)) {
    return true;
  } else if (givenTime.isBefore(currentTime)) {
    return `The session will start on ${moment(timeString).format("lll")}`;
  }
};
