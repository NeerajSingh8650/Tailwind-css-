import { PRICE_BUCKET_GOLD, PRICE_BUCKET_PLATINUM, PRICE_BUCKET_SILVER } from "@/constants";
import GoldUser from "../assets/gold_user.svg"
import SilverUser from "../assets/silver_user.svg"
import PlatinumUser from "../assets/platinum_user.svg"
import silverLabel from '../assets/silverLabel.svg'
import goldLabel from '../assets/goldLabel.svg'
import platinumLabel from '../assets/platinumLabel.svg';

/**
 * Selects the appropriate label based on the membership bucket.
 * @param bucket - The membership bucket.
 * @returns The corresponding label image path.
 */
export const getExpetLabelImage = (bucket: string): string | undefined => {
    switch (bucket.toUpperCase()) {
        case PRICE_BUCKET_PLATINUM:
            return platinumLabel;
        case PRICE_BUCKET_GOLD:
            return goldLabel;
        case PRICE_BUCKET_SILVER:
            return silverLabel;
            default:
                return '';
    }
};

/**
 * Gets the text label for a given membership bucket.
 * @param bucket - The membership bucket.
 * @returns The label text.
 */
export const getExpertLabelText = (bucket: string): string => {
    switch (bucket.toUpperCase()) {
        case PRICE_BUCKET_PLATINUM:
            return 'Platinum';
        case PRICE_BUCKET_GOLD:
            return 'Gold';
        case PRICE_BUCKET_SILVER:
            return 'Silver';
        default:
            return '';
    }
};

/**
 * Selects the user icon based on the membership bucket.
 * @param bucket - The membership bucket.
 * @returns The corresponding user icon image path.
 */
export const getExpertDefaultUserIcon = (bucket: string): string | undefined => {
    switch (bucket.toUpperCase()) {
        case PRICE_BUCKET_PLATINUM:
            return PlatinumUser;
        case PRICE_BUCKET_GOLD:
            return GoldUser;
        case PRICE_BUCKET_SILVER:
            return SilverUser;
        default:
            return ''; 
    }
};