const PASSWORD_PATTERN_REGEX = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;

const PASSWORD_FIELD_ERROR = "Your password must be at least 8 characters long and include a combination of letters, numbers, and special characters (e.g., @, #, $, !)"

export const validatePassword = (password: string) => {
    if (!PASSWORD_PATTERN_REGEX.test(password)) {
      return PASSWORD_FIELD_ERROR;
    } 
    return null;
  };