import cookie from "react-cookies";

export const COOKIES = {
  USER_INFO: "user_info",
};

export const setCookie = (key: string, value: any) => {
  cookie.save(key, value, { path: '/' });
};

export const loadCookie = (key: string) => {
  return cookie.load(key);
};

export const removeCookie = (key: string) => {
  cookie.remove(key);
};

export const removeCookies = () => {
  const options = { expires: new Date() };
  cookie.remove(COOKIES.USER_INFO, options);
};
