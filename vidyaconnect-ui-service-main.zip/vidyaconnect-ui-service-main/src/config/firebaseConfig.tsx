import { initializeApp } from "firebase/app";

// import { getMessaging } from "firebase/messaging";
import { getDatabase, ref, get, onValue, update } from "firebase/database";

// //Firebase Config values imported from .env file
 const firebaseConfig = {
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  databaseURL: import.meta.env.VITE_FIREBASE_DATABASE_URL,
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Messaging service
export const firebaseDB = getDatabase(app);

export { ref, get, onValue, update };

