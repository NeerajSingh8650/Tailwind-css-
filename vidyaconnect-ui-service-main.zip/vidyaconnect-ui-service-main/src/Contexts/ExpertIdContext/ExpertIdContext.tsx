import React, { createContext, useContext, useState, ReactNode } from "react";

interface ExpertIdContextType {
  expertId: number | null;
  setExpertId: (id: number | null) => void;
}

const ExpertIdContext = createContext<ExpertIdContextType>({
  expertId: null,
  setExpertId: () => {},
});

export const useExpertId = () => useContext(ExpertIdContext);

interface ExpertIdProviderProps {
  children: ReactNode;
}

export const ExpertIdProvider: React.FC<ExpertIdProviderProps> = ({
  children,
}) => {
  const [expertId, setExpertId] = useState<number | null>(null);

  return (
    <ExpertIdContext.Provider value={{ expertId, setExpertId }}>
      {children}
    </ExpertIdContext.Provider>
  );
};
