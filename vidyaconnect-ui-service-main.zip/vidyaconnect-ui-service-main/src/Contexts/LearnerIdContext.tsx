import React, { createContext, useContext, useState, ReactNode } from "react";

interface LearnerIdContextType {
  learnerId: number | null;
  setLearnerId: (id: number | null) => void;
}

const LearnerIdContext = createContext<LearnerIdContextType>({
  learnerId: null,
  setLearnerId: () => {},
});

export const useLearnerId = () => useContext(LearnerIdContext);

interface LearnerIdProviderProps {
  children: ReactNode;
}

export const LearnerIdProvider: React.FC<LearnerIdProviderProps> = ({
  children,
}) => {
  const [learnerId, setLearnerId] = useState<number | null>(null);

  return (
    <LearnerIdContext.Provider value={{ learnerId, setLearnerId }}>
      {children}
    </LearnerIdContext.Provider>
  );
};
