import { createContext, useContext, useState, ReactNode } from "react";

interface TenantContextType {
  tenantId: number | null;
  setTenantId: (id: number | null) => void;
}

const TenantContext = createContext<TenantContextType>({
  tenantId: null,
  setTenantId: () => {},
});

export const useTenant = () => useContext(TenantContext);

interface TenantProviderProps {
  children: ReactNode;
}

export const TenantProvider: React.FC<TenantProviderProps> = ({ children }) => {
  const [tenantId, setTenantIdState] = useState<number | null>(null);

  const setTenantId = (id: number | null) => {
    setTenantIdState(id);
  };

  return (
    <TenantContext.Provider value={{ tenantId, setTenantId }}>
      {children}
    </TenantContext.Provider>
  );
};
