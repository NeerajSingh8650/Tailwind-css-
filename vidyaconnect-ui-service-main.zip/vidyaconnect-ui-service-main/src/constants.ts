export const PRODUCT_NAME = "SageNest";
export const COMPANY_NAME = "Glofluent Vidyatech Pvt. Ltd.";

export const SECURITY = "Your Security is our top priority.";
export const SIGN_UP_AS_PARENT_USER_SECURITY_MESSAGE =
  "Please sign up as a parent/authorized Guardian to continue.";
export const PAGE_SIZE = 16;
export const NUMBER_OF_PAGES = 0;
export const FEEDBACK_MAX_CHARACTER_LENGTH = 243;
export const FEEDBACK_SEE_MORE = "See More";
export const FEEDBACK_SEE_LESS = "See Less";
export const BOOKING_STATUS_SCHEDULED = "SCHEDULED";
export const BOOKING_STATUS_PENDING = "PENDING";
export const BOOKING_STATUS_COMPLETED = "COMPLETED";
export const BOOKING_STATUS_EXPIRED = "EXPIRED";
export const BOOKING_STATUS_CANCELLED = "CANCELLED";
export const BOOKING_STATUS_REJECTED = "REJECTED";
export const OTP_EXPIRY_TIME_SECONDS = 180;
export const OTP_LENGTH = 6;
export const BOOKING_ACTION_ACCEPT = "ACCEPT";
export const BOOKING_ACTION_REJECT = "REJECT";
export const PRICE_BUCKET_SILVER = "SILVER";
export const PRICE_BUCKET_GOLD = "GOLD";
export const PRICE_BUCKET_PLATINUM = "PLATINUM";
export const CANCELLED_SESSIONS_NOTIFICATIONS_SIZE = 5;
export const START_PAGE = 0 ;
export const SORT_FILTER_ID_DESCENDING = "id,desc"
export const SESSION_MIN_DURATION_MINUTES = 5;
export const MAX_RATING = 5
export enum LearnerProfileType {
  PARENT = "PARENT",
  PROFESSIONAL = "PROFESSIONAL",
  SEEKING_OPPORTUNITIES = "SEEKING OPPORTUNITY",
  STUDENT = "STUDENT"
}

export enum DayOfWeek {
  MONDAY = "Monday",
  TUESDAY = "Tuesday",
  WEDNESDAY = "Wednesday",
  THURSDAY = "Thursday",
  FRIDAY = "Friday",
  SATURDAY = "Saturday",
  SUNDAY = "Sunday"
}

export enum GenderType {
  MALE = "MALE",
  FEMALE = "FEMALE",
}

export const MIN_SLOT_AVAILABILITY_DURATION_MINUTES = 20;


//SOCIAL LOGINS
export const SOCIAL_LOGIN_GOOGLE_NAME = "google";
export const SOCIAL_LOGIN_LINKEDIN_NAME = "linkedin";

export const PROFILE = {
  LEARNER: "learner",
  EXPERT: "expert",
};

export const EXPERT_APPROVAL_PENDING_LABEL = "APPROVAL PENDING";
export const EXPERT_ASSIGNMENT_PENDING_LABEL = "ASSIGNMENT PENDING";


export enum NotificationTypes {
  NOTIFICATION_BOOKING_ACCEPTED ="BOOKING_ACCEPTED",
  NOTIFICATION_BOOKING_REJECTED = "BOOKING_REJECTED",
  NOTIFICATION_BOOKING_CANCELLED ="BOOKING_CANCELLED",
  NOTIFICATION_BOOKING_EXPIRED = "BOOKING_EXPIRED",
  NOTIFICATION_BOOKING_REQUEST = "NEW_BOOKING_REQUEST"
}

// onboarding
export const LINKED_IN_URL_REGEX_PATTERN = "https://www\.linkedin\.com/.*"

//legal documents
export const TERMS_CONDITIONS_DOCUMENT_TYPE = "Terms_and_Conditions";
export const PRIVACY_POLICY_DOCUMENT_TYPE = "Privacy_Policy";
export const COOKIES_POLICY_DOCUMENT_TYPE = "Cookies_Policy";

export const USER_DATE_FORMAT = "DD-MM-YYYY";
export const API_DATE_FORMAT = "YYYY-MM-DD";

export const SUPPORT_EMAIL = "contact@glofluent.com"

export const PASSWORD_FIELD_ERROR = "Your password must be at least 8 characters long and include a combination of letters, numbers, and special characters (e.g., @, #, $, !)"