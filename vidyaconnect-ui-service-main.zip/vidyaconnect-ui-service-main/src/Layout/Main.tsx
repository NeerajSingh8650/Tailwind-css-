import { ReactNode, useEffect } from "react";
import Header from "../Components/Header/Header";
import Footer from "../Components/Footer/Footer";
import { useDispatch, useSelector } from "react-redux";
import { getProfileDetails } from "@/Redux/slices/userSlice";
import { AppDispatch, RootState } from "@/Redux/store/store";
import { COOKIES, loadCookie } from "@/config/sessionHelper";
import CancelledHistoryDrawer from "@/Components/CancelledHistoryDrawer/CancelledHistoryDrawer";


const Main = ({ children }: { children: ReactNode }) => {
  const dispatch: AppDispatch = useDispatch();
  const { isLoggedIn } = useSelector((state: RootState) => state.user);
  const CancelledSessionDrawerFlag =  useSelector((state:RootState)=> state.flags.CancelledSessionDrawerFlag )



  useEffect(() => {
    if (loadCookie(COOKIES.USER_INFO)) {
      dispatch(getProfileDetails());
    }
  }, [isLoggedIn]);



  return (
    <div className="relative">
      <Header />
      <main className="main-parent-cls">{children}</main>
      <Footer />
      {CancelledSessionDrawerFlag &&  <CancelledHistoryDrawer/>}
    </div>
  );
};

export default Main;
