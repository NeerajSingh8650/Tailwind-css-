import React, { useEffect, useRef, useState } from "react";
import profileImage from "../../assets/userIcon.svg";
import cameraIcom from "../../assets/camera.svg";
import type { DatePickerProps } from "antd";
import { DatePicker } from "antd";
import PhoneInput, { CountryData } from "react-phone-input-2";
import OtpVerificationModal from "@/Components/OtpVerificationModal/OtpVerificationModal";
import { useDispatch, useSelector } from "react-redux";
import { fetchTimezones } from "@/Redux/slices/ExpertSlice";
import { RootState } from "@/Redux/store/store";
import { Button } from "@/Components/ui/button";
import dayjs from "dayjs";
import { fetchTimeZones } from "@/Redux/slices/TimeZoneSlices";
import dropDownIcon from "../../assets/down_arrow.svg"
import { API_DATE_FORMAT, GenderType, USER_DATE_FORMAT } from "@/constants";
import { generateOtp } from "@/Redux/slices/OtpGenerationSlice";
import editPencil from '../../assets/editButton.svg';


interface Step1Data {
  id?: number;
  firstName: string;
  lastName: string;
  dob: string;
  gender: string;
  phoneNumber: string;
  timezone: string;
  countryCode: number;
  picUrl: string | null;
}
interface Step1Props {
  nextStep: (data: Step1Data) => void;
  data: Step1Data;
}

const Step1 = ({ nextStep, data }: Step1Props) => {
  const dispatch: any = useDispatch();
  const [otpVerificationModalIsOpen, setOtpVerificationModalIsOpen] = useState<boolean>(false);
  const [isPhoneEdit, setIsPhoneEdit] = useState<boolean>(true);
  const [selectedTimezoneIndex, setSelectedTimezoneIndex] = useState(0);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [phoneNumber, setPhoneNumber] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const [firstName, setFirstName] = useState<string>("");
  const [lastName, setLastName] = useState<string>("");
  const [dob, setDob] = useState<string>("");
  const [selectedTimezone, setSelectedTimezone] = useState<string>(Intl.DateTimeFormat().resolvedOptions().timeZone);
  const [gender, setGender] = useState<string>("");
  const [countryCode, setCountryCode] = useState<string>("");
  const timezoneRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    dispatch(fetchTimezones());
    if (data) {
      setFirstName(data.firstName);
      setLastName(data.lastName);
      setDob(data.dob);
      setGender(data.gender);
      setPhoneNumber(data.phoneNumber);

      if (data.timezone) {
        setSelectedTimezone(data.timezone);
      }
      
      setCountryCode(data.countryCode?.toString());
      setSearchTerm(selectedTimezone)
      setSelectedImage(data.picUrl);
    }

    if (data.phoneNumber) {
      console.log("phone number exists");
      setIsPhoneEdit(false);
    }

    function handleClickOutside(event: MouseEvent) {
      if (timezoneRef.current && !timezoneRef.current.contains(event.target as Node)) {
        setFilteredItems([]);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const openOtpVerificationModal = () => {
    setOtpVerificationModalIsOpen(true);
  };

  const closeOtpVerificationModal = () => {
    setOtpVerificationModalIsOpen(false);
  };

  const handleChange = (
    e: string | undefined,
    value: CountryData | undefined,
    name: string
  ) => {
    if (name === "phoneNumber" && e && value) {
      let splitMobile = e.split(value?.dialCode || "");
      setCountryCode(value?.dialCode || "");
      setPhoneNumber(splitMobile[1] || "");
    }
  };

  const handleImageClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault();
    const fileInput = document.getElementById("fileInput") as HTMLInputElement;
    if (fileInput) {
      fileInput.click();
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const imageUrl = URL.createObjectURL(e.target.files[0]);
      setSelectedImage(imageUrl);
    }
  };

  const handleGetOTP = () => {
    dispatch(generateOtp({
      countryCode,
      phoneNumber}))
      .then(() => openOtpVerificationModal());
  };

  const onOtpValidationSuccess = () => {
    closeOtpVerificationModal();
    setIsPhoneEdit(false);
  }

  const onDobChange: DatePickerProps["onChange"] = (date) => {
    if (date) {
    const dateString: string = date.format(API_DATE_FORMAT);
    setDob(dateString)
    }
  };

  const timezonesSelector = useSelector(
    (state: RootState) => state.timezone.timezones
  );

  const [searchTerm, setSearchTerm] = useState<string>('');
  const [filteredItems, setFilteredItems] = useState<string[]>([]);

  const handleTimezoneSearch = (event: React.ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value.toLowerCase();
    setSearchTerm(value);
    setFilteredItems(
      timezonesSelector.filter((timezonesSelector: any) => timezonesSelector.toLowerCase().includes(value))
    );
  };

  const handleTimezoneDropdownKeyDown = (event: React.KeyboardEvent) => {
    if (event.key === "ArrowDown" && selectedTimezoneIndex < filteredItems.length - 1) {
      setSelectedTimezoneIndex(selectedTimezoneIndex + 1);
    } else if (event.key === "ArrowUp" && selectedTimezoneIndex > 0) {
      setSelectedTimezoneIndex(selectedTimezoneIndex - 1);
    } else if (event.key === "Enter" && filteredItems.length > 0) {
      setSelectedTimezone(filteredItems[selectedTimezoneIndex]);
      setFilteredItems([]);
      setSearchTerm(filteredItems[selectedTimezoneIndex]);
    }
  };


  useEffect(() => {
    dispatch(fetchTimeZones());
  }, [])


  const handleNext = () => {
    if (
      firstName == "" ||
      lastName == "" ||
      dob == "" ||
      gender == "" ||
      phoneNumber == ""
    ) {
      setError("Please fill the required fields");
    } else if (isPhoneEdit) {
       setError("Please verify your phone number before proceeding further.")
    } else {
      setError(null);
      nextStep({
        id: data.id,
        firstName: firstName,
        lastName: lastName,
        dob: dob,
        gender: gender,
        phoneNumber: phoneNumber,
        timezone: selectedTimezone,
        countryCode: parseInt(countryCode),
        picUrl: selectedImage
      });
    }
  };

  return (
    <>
      <div className="relative">
        <label htmlFor="fileInput">
          <img
            src={selectedImage || profileImage}
            alt="Upload Image"
            className="w-[300px] h-[auto] mt-12"
            style={{ borderRadius: "600px" }}
          />
          <div className="w-[2rem] h-[2rem] cursor-pointer flex items-center justify-center rounded-[50%] bg-[#dddddd] absolute right-[1.8rem] bottom-[2rem]">
            <img
              src={cameraIcom}
              className="w-[2rem] h-[1rem]"
              onClick={handleImageClick}
            />
          </div>
        </label>
        <input
          id="fileInput"
          type="file"
          style={{ display: "none" }}
          accept="image/*"
          onChange={handleImageChange}
        />
      </div>
      <div className="mt-12 lg:mt-12">
        <div className="flex flex-col mb-8 md:flex-row justify-between md:space-x-3">
          <div>
            <label
              htmlFor=""
              className="font-normal text-[20px] lg:text-[16px]"
            >
              First Name
            </label>
            <span className="text-red-500 text-lg ms-1">*</span>
            <input
              type="text"
              className="border border-graymod w-full font-extralight text-[16px] rounded-lg py-2 ps-3 outline-none mt-2"
              placeholder="First Name"
              value={firstName}
              onChange={(e) => {
                setFirstName(e.target.value);
              }}
            />
          </div>
          <div className="mt-8 md:mt-0">
            <label
              htmlFor=""
              className="font-normal text-[20px] lg:text-[16px] mb-4"
            >
              Last Name
            </label>
            <span className="text-red-500 text-lg ms-1">*</span>
            <input
              type="text"
              className="border border-graymod w-full font-extralight text-[16px] rounded-lg py-2 ps-3 outline-none mt-2"
              placeholder="Last Name"
              value={lastName}
              onChange={(e) => setLastName(e.target.value)}
            />
          </div>
        </div>
        <div className="flex flex-col md:flex-row justify-between md:space-x-3 mb-8">
          <div className="w-full flex flex-col">
            <label
              htmlFor=""
              className="font-normal text-[20px] lg:text-[16px]"
            >
              Date of Birth
              <span className="text-red-500 text-lg ms-1">*</span>
            </label>
            <DatePicker
              value={dob ? dayjs(dob) : null}
              onChange={onDobChange}
              placeholder={USER_DATE_FORMAT}
              format={USER_DATE_FORMAT}
              className="h-[44px] border border-graymod font-extralight text-[16px] rounded-lg py-2 ps-3 outline-none mt-2 lg:w-full w-full"
              id="dateSel"
            />
          </div>
          <div className="w-full mt-8 md:mt-0">
            <label
              htmlFor=""
              className="font-normal text-[20px] lg:text-[16px] mb-4"
            >
              Gender
            </label>
            <span className="text-red-500 text-lg ms-1">*</span>

            <div className="relative">
              <select
                name="gender"
                id="gender"
                className={`appearance-none cursor-pointer h-[44px] border border-graymod bg-white w-full
                ${gender ? 'font-light' : 'font-extralight'}
                text-[16px] rounded-lg py-2 px-4 outline-none mt-2`}
                value={gender}
                onChange={(e) => setGender(e.target.value)}
              >
                <option value="">Select Gender</option>
                <option value={GenderType.MALE}>{GenderType.MALE}</option>
                <option value={GenderType.FEMALE}>{GenderType.FEMALE}</option>
              </select>
              <span className="absolute inset-y-0 mt-2 right-0 flex items-center pr-3 pointer-events-none">
                <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                </svg>
              </span>
            </div>
          </div>
        </div>


        <div className="w-full flex flex-col">
        <label htmlFor="" className="font-normal text-[20px] lg:text-[16px] mb-2">
             Timezone
              <span className="text-red-500 text-lg ms-1">*</span>
            </label>
          <div className="w-full relative" ref = {timezoneRef} onClick={() => {
            filteredItems.length > 0 ? setFilteredItems([]) : setFilteredItems(timezonesSelector)
          }}>
            <input
              type="text"
              value={searchTerm}
              onChange={handleTimezoneSearch}
              onKeyDown={handleTimezoneDropdownKeyDown}
              placeholder="Select Your Timezone"
              className={`h-[42px] border border-graymod w-full rounded-md px-3 placeholder:text-graymod outline-none`}
            />
            <img
              src={dropDownIcon}
              className="absolute z-[999] top-2 right-3 cursor-pointer w-6 " alt="" />
            {filteredItems.length > 0 && (
              <div className="absolute top-full max-h-[35vh] overflow-y-auto left-0 z-[999] bg-white rounded-md shadow-md w-full">
                {filteredItems.map((suggestion, index) => (
                  <div key={index} className="px-3 py-1 border-b cursor-pointer hover:bg-gray-100" onClick={() => {
                    setSelectedTimezone(suggestion)
                    setFilteredItems([])
                    setSearchTerm(suggestion)
                  }}>
                    {suggestion}
                  </div>
                ))}
              </div>
            )}

          </div>
        </div>


        <div className="mt-8">
          <div>
            <label className="font-normal text-[20px] lg:text-[16px] mb-4 md:mb-0 sm:mb-0">
              Phone Number
            </label>
            <span className="text-red-500 text-lg ms-1">*</span>
            {isPhoneEdit ? (<div className="flex flex-row mt-2">
              <div className="w-[92%] sm:w-[92%] lg:w-[45%] md:w-[42%]">
                <PhoneInput
                  country={"in"}
                  value={`${countryCode}${phoneNumber}`}
                  onChange={(e, phone) =>
                    handleChange(e, phone as CountryData, "phoneNumber")
                  }
                  inputStyle={{
                    height: "44px",
                    border: "1px solid #DDDDDD",
                    width: "100%",
                    fontSize: "16px",
                    borderRadius: "8px",
                    padding: "10px 15px",
                    outline: "none",
                    marginTop: "5px",
                    marginLeft: "30px",
                  }}
                  inputProps={{
                    required: true,
                  }}
                />
              </div>
              <Button
              className="ml-12"
                onClick={handleGetOTP}
                disabled={!phoneNumber || phoneNumber?.length < 10} //TODO: change it according to country
              >
                Get OTP
              </Button>
              </div>) : (<div className="flex">
                <p className="text-[16px]">{countryCode}-{phoneNumber}</p>
                <img onClick={() => setIsPhoneEdit(true)} className="cursor-pointer ml-4" src={editPencil} alt="Edit" />
              </div>)}
          </div>
        </div>
        {error && <p className="text-red-500 font-medium mt-4">{error}</p>}
        <div className="flex justify-end mt-[60px]">
          <Button
            onClick={handleNext}
            disabled={
              firstName == "" ||
              lastName == "" ||
              dob == "" ||
              gender == "" ||
              phoneNumber?.length < 10
            }
          >
            Next
          </Button>
        </div>
      </div>
      {otpVerificationModalIsOpen && (
        <OtpVerificationModal
          phoneNumber={phoneNumber}
          countryCode={countryCode}
          isOpen={otpVerificationModalIsOpen}
          onClose={closeOtpVerificationModal}
          onValidationSuccess={onOtpValidationSuccess}
        />
      )}
    </>
  );
};

export default Step1;
