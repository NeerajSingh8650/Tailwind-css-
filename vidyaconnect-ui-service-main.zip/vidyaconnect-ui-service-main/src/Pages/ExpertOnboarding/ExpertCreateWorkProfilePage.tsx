import { Plus, X } from 'lucide-react'
import {
    Select,
    SelectContent,
    SelectGroup,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/Components/ui/select"
import * as React from "react"

import { useState, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { AppDispatch, RootState } from '@/Redux/store/store'
import { addEducation, addWorkExperience, deleteEducation, deleteWorkExperience, fetchDegrees, fetchEducation, fetchWork, profileUpdateId, updateEducation, updateWorkExperience } from '@/Redux/slices/ExpertWorkProfile'
import { DatePicker, DatePickerProps } from 'antd'
import moment from 'moment'
import ExpertRejectSessionPopUp from '@/Components/RejectPopUp/RejectPopUp'
import EditButton from "../../assets/editButton.svg"
import DelButton from "../../assets/trash.svg"
import ComboBox from '@/Components/ui/comboBox'
import { fetchSchools } from '@/Redux/slices/LearnerSlices'
import { fetchCompanies, fetchPositions } from '@/Redux/slices/LearnerSettingSlice'
import { API_DATE_FORMAT, USER_DATE_FORMAT } from '@/constants'
import dayjs from 'dayjs'
import { Education } from '@/Redux/slices/ExpertsDataSlice'
import { Button } from '@/shadcn/ui/button'


const DescriptionBox: React.FC<any> = ({ value, label, onChange }) => {
    return (
        <div className="grid w-full items-center gap-2">
            <p className='text-graymod-textfive'>{label}</p>
            <textarea placeholder={label} value={value} onChange={onChange} className='resize-none h-[77px] border border-graymod outline-none px-2 py-2 rounded-sm placeholder:text-graymod text-graymod-textfour' />
        </div>
    )
}

const Tab: React.FC<any> = ({ title, onPlus, education, work, onEdit }) => {

    const [educationConfirmationModal, seteducationConfirmationModal] = useState(false)
    const [workConfirmationModal, setWorkConfirmationModal] = useState(false)
    const [workId, setWorkId] = useState("")
    const [educationId, setEducationId] = useState("")
    const dispatch: AppDispatch = useDispatch()

    return (
        <div className='bg-white p-4 bg rounded-md flex flex-col gap-5 justify-center mb-5 box-shadow-brdr'>
            {workConfirmationModal && <ExpertRejectSessionPopUp
                onCancel={() => setWorkConfirmationModal(false)}
                heading='Are you sure you want to delete this experience ?'
                onConfirm={() => {
                    dispatch(deleteWorkExperience(workId)).then(() => {
                        dispatch(fetchWork())
                        setWorkConfirmationModal(false)
                    })
                }}
            />}
            {educationConfirmationModal && <ExpertRejectSessionPopUp
                onCancel={() => seteducationConfirmationModal(false)}
                heading='Are you sure you want to delete this education ?'
                onConfirm={() => {
                    dispatch(deleteEducation(educationId)).then(() => {
                        dispatch(fetchEducation())
                        seteducationConfirmationModal(false)
                    })
                }}
            />}
            <div className='flex items-center justify-between '>
                <h1 className='text-[18px] text-graymod-textone font-medium'>{title}</h1>
                <Plus onClick={onPlus} className='text-graymod-textone cursor-pointer rounded-[50%] hover:bg-gray-200 duration-75' />
            </div>
            {education?.map((data: any) => (
                <div key={data.id} className='flex flex-col gap-2 pt-3'>
                    <div className='flex items-center justify-between'>
                        <h1 className='font-medium text-[20px] text-graymod-textthree'>{data.company}</h1>
                        <div className='flex items-center gap-3'>
                            <img src={EditButton}
                                onClick={() => {
                                    dispatch(profileUpdateId(data.id))
                                    onEdit()
                                }}
                                className='cursor-pointer  p-1.5 h-8 w-8 hover:bg-gray-300' />
                            <img src={DelButton} onClick={() => {
                                setEducationId(data.id)
                                seteducationConfirmationModal(true)
                            }} className='cursor-pointer rounded-[50%] h-8 w-8 hover:bg-gray-300 p-1' />
                        </div>
                    </div>
                    <p className='font-light text-[16px] text-graymod-one'>{data.startDate} - {data.endDate === null ? "Present" : data.endDate}</p>
                    <p className='text-graymod-textthree text-[18px]'>{data.description}</p>
                    <hr className='mt-5' />
                </div>
            ))}
            {work?.map((data: any) => (
                <div key={data.id} className='flex flex-col gap-2 pt-3'>
                    <div className='flex items-center justify-between'>
                        <h1 className='font-medium text-[20px] text-graymod-textthree'>{data.position}, {data.company}</h1>
                        <div className='flex items-center gap-3'>
                            <img src={EditButton} onClick={() => {
                                onEdit()
                                dispatch(profileUpdateId(data.id))
                            }} className='cursor-pointer p-1.5 h-8 w-8 hover:bg-gray-300' />
                            <img src={DelButton}
                                onClick={() => {
                                    setWorkId(data.id)
                                    setWorkConfirmationModal(true)
                                }}
                                className='cursor-pointer rounded-[50%] h-8 w-8 hover:bg-gray-300 p-1' />
                        </div>
                    </div>
                    {title === "Education" && <p className='font-light text-[16px] text-graymod-one'>{data.startDate.slice(0, 4)} - {data.endDate === null ? "Present" : data.endDate.slice(0, 4)}</p>}
                    {title === "Work Experience" && <p className='font-light text-[16px] text-graymod-one'>{moment(data.startDate).format("D MMM YYYY")} - {data.endDate === null ? "Present" : moment(data.endDate).format("D MMM YYYY")}</p>}
                    <p className='text-graymod-textthree text-[18px]'>{data.description}</p>
                    <hr className='mt-5' />
                </div>
            ))}
        </div>
    )
}

const SelectComponent: React.FC<any> = ({ value, title, onChange, degree }) => {
    const dispatch: any = useDispatch()
    const degrees: any = useSelector((state: RootState) => state.expertWorkProfile?.degrees)
    useEffect(() => {
        dispatch(fetchDegrees())
    }, [])

    return (<>
        <div className='w-100 grid gap-2'>
            <p>{title}</p>
            <Select onValueChange={onChange} >
                <SelectTrigger className="min-w-[300px]">
                    <SelectValue placeholder={value === "" ? title : value} />
                </SelectTrigger>
                <SelectContent className="w-[300px]">
                    <SelectGroup>
                        {degree === ""
                            ? degrees?.map((data: any) => (
                                <SelectItem key={data.id} value={data.name}>{data.name.toUpperCase()}</SelectItem>
                            ))
                            : <>
                                <SelectItem value="FullTime">Full-Time</SelectItem>
                                <hr />
                                <SelectItem value="PartTime">Part-Time</SelectItem>
                                <hr />
                                <SelectItem value="SelfEmployed">Self-Employed</SelectItem>
                                <hr />
                                <SelectItem value="Freelance">Freelance</SelectItem>
                                <hr />
                                <SelectItem value="Internship">Internship</SelectItem>
                                <hr />
                                <SelectItem value="Trainee">Trainee</SelectItem>
                            </>
                        }
                    </SelectGroup>
                </SelectContent>
            </Select>
        </div>
    </>
    )
}

const DateComponent: React.FC<any> = ({ title, id, value, DisabledDate, onChange }) => {
    const [date, setDate] = useState<any | null>(value ? moment(value) : null);

    const handleDateChange: DatePickerProps["onChange"] = (date) => {
        if (date) {
        const formattedDate = date.format(API_DATE_FORMAT)
        setDate(formattedDate);
        if (onChange) {
            onChange({ target: { id, value: formattedDate.toString() } });
        }
    } else {
        setDate(null);
        if (onChange) {
            onChange({ target: { id, value: ''}});
        }
    }
    };

    const disabledDate = (current: any): boolean => {
        if (DisabledDate) {
            const specificDate = moment(DisabledDate);
            return current ? current.isBefore(specificDate, 'day') : false;
        }
        return false;
    };

    return (
        <div className='grid gap-2'>
            <p>{title}</p>
            <DatePicker
                format={USER_DATE_FORMAT}
                value={date ? dayjs(date): null}
                onChange={handleDateChange}
                disabledDate={disabledDate}
            />
        </div>
    );
};

const EducationForm: React.FC<any> = ({ title, onClose, onChange }) => {

    const [endDateFlag, setEndDateFlag] = useState(true)
    const [validationFlag, setValidationFlag] = useState(false)
    const dispatch: any = useDispatch()
    const education: any = useSelector((state: RootState) => state.expertWorkProfile?.education)
    const educationId: any = useSelector((state: RootState) => state.expertWorkProfile?.id)
    const degrees: any = useSelector((state: RootState) => state.expertWorkProfile?.degrees)
    const institution: any = useSelector((state: RootState) => state.LearnerSetting?.companies)
    const [educationData, setEducationData] = useState<any>({
        "company": "",
        "degree": "",
        "startDate": "",
        "endDate": "",
        "description": ""
    });

    const validation = (): any => {
        let isValid: boolean = true;
        for (let key in educationData) {
            if (educationData[key] === "") {
                if ((key === "endDate" && !endDateFlag) || key === "description") {
                    continue;
                }
                isValid = false;
                break;
            } 
        }
        setValidationFlag(isValid);
    }

    useEffect(() => {
        dispatch(fetchDegrees())
        dispatch(fetchCompanies())
    }, [])

    useEffect(() => {
        if (title.toLowerCase() === "edit education") {
            education.map((data: Education) => {
                if (data.id === educationId) {
                    const startDate = data.startDate + "-01-01"
                    const endDate = data.endDate === null ? "" : data.endDate + "-01-01"
                    if (data.endDate === null) {
                        setEducationData({
                            company: data.company,
                            description: data.description,
                            degree: data.degree,
                            startDate: startDate,
                        })
                    } else {
                        setEducationData({
                            company: data.company,
                            description: data.description,
                            degree: data.degree,
                            startDate: startDate,
                            endDate: endDate,
                        })
                    }
                    return;
                }
            })
        }
    }, [])


    useEffect(() => {
        dispatch(fetchSchools())
    }, [])

    useEffect(() => {
        validation();
    },[educationData, endDateFlag])

    const handleChange = (title: any, e: any) => {
        setEducationData((prevData: any) => {
            const updatedData = { ...prevData, [title]: e };
            return updatedData;
        });
    };


    const endFlagChecker = () => {
        if (endDateFlag) {
            setEducationData((prevData: any) => {
                const updatedData = { ...prevData, ["endDate"]: null };
                return updatedData;
            });
        } else {
            setEducationData((prevData: any) => {
                const updatedData = { ...prevData, ["endDate"]: "" };
                return updatedData;
            });
        }
    }

    const handleSelectDegree = (data: any) => {
        handleChange("degree", data.name)
    }

    const hanldeSelectCompanies = (data: any) => {
        handleChange("company", data.name)
    }

    return (
        <div className='h-screen w-screen fixed top-0 left-0 z-40 bg-black/30 flex items-center justify-center'>
            <div className='w-[881px] h-[650px] rounded-md bg-white'>
                <div className='h-[71px] flex items-center justify-between rounded-md px-12 bg-graymod-background'>
                    <span className='text-graymod-textfive text-[26px] font-medium'>{title}</span>
                    <X onClick={onClose} className='text-graymod-textfive rounded-[50%] hover:bg-gray-300 cursor-pointer ' />
                </div>
                <div className='px-16 mt-10 grid gap-5'>
                    <div className='flex flex-col gap-2'>
                        <p>Institution</p>
                        <ComboBox
                            suggestions={institution}
                            onSelect={hanldeSelectCompanies}
                            selectedItem={educationData.company}
                            className='h-10'
                            placeholder='Institute'
                        />
                    </div>
                    <DescriptionBox
                        label={"Description"}
                        id="Description"
                        className={"h-[77px] "}
                        value={educationData.description}
                        onChange={(e: any) =>
                            handleChange("description", e.target.value)
                        }
                    />
                    <div className='grid grid-cols-4'>
                        <div className='flex flex-col w-80 gap-3'>
                            <p>Degree</p>
                            <ComboBox
                                suggestions={degrees}
                                onSelect={handleSelectDegree}
                                selectedItem={educationData?.degree}
                                className='h-10'
                                placeholder='Degree'
                            />
                        </div>
                    </div>
                    <div className='grid grid-cols-2 gap-20 justify-between'>
                        <DateComponent
                            title="Start Date"
                            id="startDate"
                            value={educationData.startDate}
                            onChange={(e: any) =>
                                handleChange("startDate", e.target.value)
                            }
                        />
                        {endDateFlag && <DateComponent
                            title="End Date"
                            id="endDate"
                            value={educationData.endDate}
                            DisabledDate={educationData.startDate}
                            onChange={(e: any) => {
                                handleChange("endDate", e.target.value)
                            }}
                        />}
                    </div>
                    <div className='flex items-center gap-2 mt-3'>
                        <input checked={!endDateFlag} onChange={() => {
                            setEndDateFlag(prev => !prev)
                            endFlagChecker()
                        }} id='currWorking' type="checkbox" />
                        <label htmlFor="currWorking">I currently study here</label>
                    </div>
                    <div className='flex gap-3 items-end justify-end'>
                        <Button onClick={onClose} variant={"outline"}>Cancel</Button>
                        {validationFlag ?
                            title.toLowerCase() === "edit experience" ?
                                <Button onClick={() => {
                                    dispatch(updateEducation({ educationId, educationData })).then(() => {
                                        dispatch(fetchWork())
                                    })
                                    onClose()
                                }}>Save</Button>
                                : title.toLowerCase() !== "edit education" && <Button onClick={() => {
                                    dispatch(addEducation(educationData)).then(() => {
                                        dispatch(fetchEducation());
                                        onClose();
                                        onChange();
                                    })
                                }}>Save</Button>
                            :
                            title.toLowerCase() !== "edit education" && <Button variant={'disabled'}>Save</Button>
                        }

                        {title.toLowerCase() === "edit education" ?
                            <Button onClick={() => {
                                dispatch(updateEducation({ educationId, educationData })).then(() => {
                                    dispatch(fetchEducation())
                                })
                                onClose()
                            }}>Save</Button> : ""
                        }

                    </div>
                </div>
            </div>
        </div>
    )
}




const WorkForm: React.FC<any> = ({ onClose, title, onChange }) => {
    const [endDateFlag, setEndDateFlag] = useState(true);
    const [validationFlag, setValidationFlag] = useState(false)
    const dispatch: any = useDispatch()
    const work: any = useSelector((state: RootState) => state.expertWorkProfile?.workExperiences)
    const workId: any = useSelector((state: RootState) => state.expertWorkProfile?.id)
    const institution: any = useSelector((state: RootState) => state.LearnerSetting?.companies)
    const positions: any = useSelector((state: RootState) => state.LearnerSetting?.positions)
    const [workData, setWorkData] = useState<any>({
        title: '',
        company: '',
        description: '',
        employmentType: '',
        startDate: '',
        endDate: '',
    });


    const hanldeSelectCompanies = (data: any) => {
        handleChange("company", data.name)
    }

    const handleSelectTitle = (data: any) => {
        handleChange("title", data.title)
    }

    useEffect(() => {
        dispatch(fetchPositions())
        dispatch(fetchCompanies())
    }, [])

    useEffect(() => {
        validation()
    }, [workData, endDateFlag])


    useEffect(() => {
        if (title.toLowerCase() === "edit experience") {
            work.map((data: any) => {
                if (data.id === workId) {
                    if (data.endDate === null) {
                        setWorkData({
                            title: data.position,
                            company: data.company,
                            description: data.description,
                            employmentType: data.employmentType,
                            startDate: data.startDate,
                        })
                    } else {
                        setWorkData({
                            title: data.position,
                            company: data.company,
                            description: data.description,
                            employmentType: data.employmentType,
                            startDate: data.startDate,
                            endDate: data.endDate,
                        })
                    }
                    return;
                }
            })
        }
    }, [])

    const validation = (): void => {
        let isValid: boolean = true;
        for (let key in workData) {
            if (workData[key] === "") {
                if ((key === "endDate" && !endDateFlag) || key === 'description') {
                    continue;
                }
                isValid = false;
                break;
            }
        }
        setValidationFlag(isValid);
    }

    useEffect(() => {
        if (endDateFlag) {
            setWorkData((prevData: any) => {
                const updatedData = { ...prevData, ["endDate"]: null };
                return updatedData;
            });
        } else {
            setWorkData((prevData: any) => {
                const updatedData = { ...prevData, ["endDate"]: "" };
                return updatedData;
            });
        }
    }, [endDateFlag])

    const handleChange = (field: any, e: any) => {
        setWorkData((prevData: any) => {
            const updatedData = { ...prevData, [field]: e };
            return updatedData;
        });
        console.log("work data updated", workData);
    };

    return (
        <div className='h-screen w-screen fixed top-0 left-0 z-40 bg-black/30 flex items-center justify-center'>
            <div className='w-[860px] h-[720px] rounded-md bg-white'>
                <div className='h-[71px] flex items-center justify-between rounded-md px-12 bg-graymod-background'>
                    <span className='text-graymod-textfive text-[26px] font-medium'>{title}</span>
                    <X onClick={onClose} className='text-graymod-textfive rounded-[50%] hover:bg-gray-300 cursor-pointer ' />
                </div>
                <div className='px-16 mt-10 grid gap-5'>
                    <div className='flex flex-col gap-2'>
                        <p>Title</p>
                        <ComboBox
                            onValueChange={(e:any) => {
                                setWorkData({...workData, title: e.target.value})
                            }}
                            suggestions={positions}
                            onSelect={handleSelectTitle}
                            selectedItem={workData.title}
                            placeholder='Title'
                            className='h-10'
                        />
                    </div>
                    <div className='flex flex-col gap-2'>
                        <p>Company</p>
                        <ComboBox
                            suggestions={institution}
                            onSelect={hanldeSelectCompanies}
                            selectedItem={workData.company}
                            placeholder='company'
                            className='h-10'
                        />
                    </div>
                    <DescriptionBox
                        label={"Description"}
                        id="description"
                        className={"h-[77px]"}
                        value={workData.description}
                        onChange={(e: any) =>
                            handleChange("description", e.target.value)
                        }
                    />
                    <div className='grid grid-cols-4'>
                        <SelectComponent
                            title={"Employment "}
                            id="employmentType"
                            value={workData.employmentType}
                            onChange={(e: any) => {
                                handleChange("employmentType", e)
                            }
                            }
                        />
                    </div>
                    <div className='grid grid-cols-2 gap-20 justify-between'>
                        <DateComponent
                            title="Start Date"
                            id="startDate"
                            value={workData.startDate}
                            onChange={(e: any) =>
                                handleChange("startDate", e.target.value)
                            }
                        />
                        {endDateFlag && <DateComponent
                            title="End Date"
                            id="endDate"
                            value={workData.endDate}
                            onChange={(e: any) =>
                                handleChange("endDate", e.target.value)
                            }
                            DisabledDate={workData.startDate}
                        />}
                    </div>
                    <div className='flex items-center gap-2 mt-3'>
                        <input checked={!endDateFlag} onChange={() => {
                            setEndDateFlag(prev => !prev)
                        }} id='currWorking' type="checkbox" />
                        <label htmlFor="currWorking">I currently work here</label>
                    </div>
                    <div className='flex gap-3 items-end justify-end'>
                        <Button onClick={onClose} variant={"outline"}>Cancel</Button>
                        {validationFlag
                            ? title.toLowerCase() === "edit experience"
                                ? ""
                                : <Button onClick={() => {
                                    dispatch(addWorkExperience(workData)).then(() => {
                                        dispatch(fetchWork());
                                        onClose();
                                        onChange();
                                    })
                                }}>Save</Button>
                            : title.toLowerCase() !== "edit experience" && <Button variant={'disabled'}>Save</Button>
                        }

                        {title.toLowerCase() === "edit experience" ?
                            <Button onClick={() => {
                                dispatch(updateWorkExperience({ workId, workData })).then(() => {
                                    dispatch(fetchWork())
                                })
                                onClose()
                            }}>Save</Button> : ""
                        }
                    </div>
                </div>
            </div>
        </div>
    );
};

interface WorkProfileProps {
    onChange: () => void;
}

const ExpertCreateWorkProfilePage = ({ onChange }: WorkProfileProps) => {
    const [addEducation, setAddEducation] = useState(false)
    const [addExperience, setAddExperience] = useState(false)
    const [editEducation, setEditEducation] = useState(false)
    const [editExperience, setEditExperience] = useState(false)
    const dispatch: AppDispatch = useDispatch()

    useEffect(() => {
        dispatch(fetchEducation())
        dispatch(fetchWork())
    }, [])


    const work: any = useSelector((state: RootState) => state.expertWorkProfile?.workExperiences)
    const education: any = useSelector((state: RootState) => state.expertWorkProfile?.education)
    return (
        <div className='mt-6'>
            <Tab
                onPlus={() => setAddExperience(true)}
                title="Work Experience"
                work={work}
                onEdit={() => setEditExperience(true)}
            />
            <Tab
                onPlus={() => setAddEducation(true)}
                title="Education"
                education={education}
                onEdit={() => setEditEducation(true)}
            />
            {addEducation && <EducationForm title="Add Education" onClose={() => setAddEducation(false)} onChange={onChange} />}
            {addExperience && <WorkForm title="Add Experience" onClose={() => setAddExperience(false)} onChange={onChange} />}
            {editEducation && <EducationForm title="Edit Education" onClose={() => setEditEducation(false)} onChange={onChange} />}
            {editExperience && <WorkForm title="Edit Experience" onClose={() => setEditExperience(false)} onChange={onChange} />}
        </div>
    )
}

export default ExpertCreateWorkProfilePage