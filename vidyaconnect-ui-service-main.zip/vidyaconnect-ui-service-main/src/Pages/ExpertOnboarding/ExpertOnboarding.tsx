import { useState, useEffect } from "react";
import "react-phone-input-2/lib/style.css";
import "./ExpertOnboarding.css";
import ProgressBar from "../../Components/ProgressBar/ProgressBar";
import Step1 from "./Step1";
import Step2 from "./Step2";
import Step3 from "./Step3";
import { useDispatch, useSelector } from "react-redux";
import {
  createExpertExpertise,
  createExpertPersonalInfo,
  fetchExpertExpertise,
  fetchExpertPersonalInfo,
  updateExpertExpertise,
  updateExpertPersonalInfo,
} from "@/Redux/slices/ExpertSlice";
import { AppDispatch, RootState } from "@/Redux/store/store";
import { getProfileDetails } from "@/Redux/slices/userSlice";
import { fetchEducation, fetchWork } from "@/Redux/slices/ExpertWorkProfile";

interface props {
  onboardStatus: any;
}

interface Skill {
  skillName: string;
  level: number;
  skillId?: number;
  expertSkillId?: number;
}

export interface Step2Data {
  linkedInProfileLink: string;
  skills: Skill[];
}

interface PersonalInformation {
  firstName: string;
  lastName: string;
  dob: string;
  gender: string;
  phoneNumber: string;
  timezone: string;
  countryCode: number;
  id?: number;
  picUrl: string | null;
}

const ExpertPersonalInformation = ({ onboardStatus }: props) => {
  const dispatch: AppDispatch = useDispatch();
  const { expertSkills }: { expertSkills: Skill[] } = useSelector(
    (state: RootState) => state.expert
  );
  const personalInformation = useSelector(
    (state: RootState) => state.user.userDetails
  );
  const [progress, setProgress] = useState(0);
  const [updateSkills, setUpdateSkills] = useState(false);
  const [formData, setFormData] = useState<PersonalInformation>({
    firstName: "",
    lastName: "",
    dob: "",
    gender: "",
    phoneNumber: "",
    timezone: "",
    countryCode: 91,
    picUrl: ""
  });

  const [step2Data, setStep2Data] = useState<Step2Data>({
    linkedInProfileLink: "",
    skills: []
  });

  useEffect(() => {
    const browserTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    setFormData((prevData) => ({
      ...prevData,
      timezone: personalInformation?.timezone || browserTimezone,
    }));
    if (!onboardStatus?.personalInfoCompleted) {
      setProgress(0);
    } else if (!onboardStatus?.expertSkillsAdded || !onboardStatus?.expertWorkProfileCompleted) {
      dispatch(fetchExpertPersonalInfo());
      setProgress(1);
    } else if (!onboardStatus?.expertAvailabilityAdded) {
      setUpdateSkills(true);
      dispatch(fetchExpertPersonalInfo());
      dispatch(fetchExpertExpertise());
      dispatch(fetchWork())
      dispatch(fetchEducation());
      setProgress(2);
    }
  }, [onboardStatus]);

  useEffect(() => {
    console.log(personalInformation)
    if (personalInformation) {
      setFormData((prevData) => ({
        ...prevData,
        ...personalInformation,
        timezone:
          personalInformation.timezone ||
          Intl.DateTimeFormat().resolvedOptions().timeZone,
          phoneNumber: personalInformation.phoneNumber,
          countryCode: personalInformation.countryCode
      }));
      setStep2Data((prevData) => ({
        ...prevData,
        linkedInProfileLink: personalInformation.linkedInProfileLink,
      }));
    }
    if (expertSkills) {
      setStep2Data((prevData) => ({
        ...prevData,
        skills: expertSkills,
      }));
    }
  }, [personalInformation, expertSkills]);

  const handleStep1Submit = (data: PersonalInformation) => {
    setFormData((prevData) => ({
      ...prevData,
      ...data,
    }));
    
    dispatch(createExpertPersonalInfo({
      firstName: data.firstName,
      lastName: data.lastName,
      dob: data.dob,
      gender: data.gender,
      timezone: data.timezone
    }));
    
    setProgress(progress + 1);
  };

  const handleStep2Submit = (data: {
    linkedInProfileLink: string;
    skills: Skill[];
  }) => {
    setStep2Data((prevData) => ({
      ...prevData,
      ...data,
    }));
    if (data.linkedInProfileLink != "") {
      let updateData = {
        linkedInProfileLink: data.linkedInProfileLink,
      };
      dispatch(updateExpertPersonalInfo(updateData));
    }
    if (updateSkills) {
      let updateData = {
        expertSkills: data.skills,
      };
      dispatch(updateExpertExpertise(updateData));
    } else {
      let createData = {
        skills: data.skills,
      };
      dispatch(createExpertExpertise(createData));
    }
    setProgress(progress + 1);
  };

  const step2Prev = () => {
    dispatch(getProfileDetails());
    setProgress(progress - 1);
  };

  const step3Prev = () => {
    setUpdateSkills(true);
    dispatch(getProfileDetails());
    dispatch(fetchExpertExpertise());
    dispatch(fetchWork())
    dispatch(fetchEducation());
    setProgress(progress - 1);
  };

  return (
    <div className="my-12 mx-10">
      <ProgressBar progress={progress} />
      <h2 className="font-medium text-[25px] lg:text-[30px] mb-10 progress-steps-title">
        {progress + 1 == 1 && "Personal Information"}
        {progress + 1 == 2 && "Areas of Expertise"}
        {progress + 1 == 3 && "Availability"}
      </h2>
      <div className="h-[1px] bg-[#C7C7C7]"></div>
      <div className="flex flex-col md:flex-row space-x-3 md:space-x-8 justify-center gap-[20px] md-12 sm: items-center md:items-start">
        {progress + 1 == 1 && (
          <Step1 nextStep={(data) => handleStep1Submit(data)} data={formData} />
        )}
        {progress + 1 == 2 && (
          <Step2
            nextStep={(data) => handleStep2Submit(data)}
            prevStep={() => step2Prev()}
            data={step2Data}
          />
        )}
        {progress + 1 == 3 && <Step3 prevStep={() => step3Prev()} />}
      </div>
    </div>
  );
};

export default ExpertPersonalInformation;
