const ConfirmationPage = () => {
  return (
    <div className="my-12 mx-20 mb-1">
      <div className="border border-graymod-one pt-44 pb-32">
        <h1 className="font-medium text-[32px] text-center text-graymode-textfive">
          Thank You for registering with us!
        </h1>
        <h1 className="font-medium text-[32px] text-center text-graymod-textfive">
          Someone from our team will be contacting you shortly to verify your details.
        </h1>
      </div>
    </div>
  );
};

export default ConfirmationPage;
