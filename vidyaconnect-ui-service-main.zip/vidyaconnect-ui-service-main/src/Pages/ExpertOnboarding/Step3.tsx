;import { useEffect, useState } from "react";
import { timePicker } from "analogue-time-picker";
import { useDispatch, useSelector } from "react-redux";
import { createExpertAvailability, deleteExpertAvailability, getExpertAvailability, TimeSlot, updateExpertKyc } from "@/Redux/slices/ExpertSlice";
import { Button } from "@/shadcn/ui/button";
import SlotWithWeek from "@/Components/Slots/SlotWithWeek/SlotWithWeek";
import { AppDispatch, RootState } from "@/Redux/store/store";
import { MIN_SLOT_AVAILABILITY_DURATION_MINUTES } from "@/constants";
import { timeToMinutes } from "@/utils/utility";

interface Step3Props {
    prevStep: () => void;
}

const Step3 = ({ prevStep }: Step3Props) => {
    const dispatch: AppDispatch = useDispatch();
    const [availability, setAvailability] = useState<{ [key: string]: TimeSlot[] }>({});
    const [selectedDay, setSelectedDay] = useState<string | null>(null);
    const [showDialog, setShowDialog] = useState<boolean>(false);
    const [showStartTime, setShowStartTime] = useState<boolean>(true);
    const [tempSlot, setTempSlot] = useState<Partial<TimeSlot>>({});
    const availabilitySlotsSelector = useSelector((state: RootState) => state.expert.availableSlots);

    const handleAddSlot = (day: string) => {
        setSelectedDay(day);
        setShowDialog(true);
    };

    const handleRemoveSlot = (day: string, startTime: string, endTime: string) => {
        dispatch(deleteExpertAvailability({day, startTime, endTime}))
        .then(() => dispatch(getExpertAvailability()));
    };

    const syncAvailability = () => {
        const newAvailability: { [key: string]: TimeSlot[] } = {};

        availabilitySlotsSelector.forEach(slot => {
            newAvailability[slot.day] = [...(newAvailability[slot.day] || []), ...slot.slots];
        });
        setAvailability(newAvailability);
    }

    useEffect(() => {
        dispatch(getExpertAvailability());
    }, [])

    useEffect(() => {
        syncAvailability();
    }, [availabilitySlotsSelector])


    useEffect(() => {
        if (showDialog && selectedDay) {
            const element = document.getElementById("clock");
            if (element) {
                const timePick = timePicker({
                    element: element,
                    mode: 12,
                    time: { hour: 10, minute: 0 },
                });

                timePick.onCancel(() => {
                    setTempSlot({});
                    setShowStartTime(true);
                    setShowDialog(false);
                    // timePick.dispose();
                });

                timePick.onOk((hour, minute) => {
                    const formattedHours = hour == 0 ? '12' : hour == 12 ? '00' : String(hour).padStart(2, '0');
                    const formattedMinute = String(minute).padStart(2, '0');
                    const time = `${formattedHours}:${formattedMinute}`;
                    if (showStartTime) {
                        setTempSlot({ ...tempSlot, startTime: time });
                        setShowStartTime(false);
                    } else {
                        const startTimeMinutes = timeToMinutes(tempSlot.startTime || '00:00');
                        const endTimeMinutes = timeToMinutes(time);
                        const duration = endTimeMinutes - startTimeMinutes;

                        if (endTimeMinutes <= startTimeMinutes || duration < MIN_SLOT_AVAILABILITY_DURATION_MINUTES) {
                            alert(`End time must be at least ${MIN_SLOT_AVAILABILITY_DURATION_MINUTES} minutes greater than start time.`);
                            setShowStartTime(true); 
                            return; 
                        }
                        const newSlot = {
                            startTime: tempSlot.startTime || '',
                            endTime: time,
                        };
                        setAvailability(prev => {
                            return {
                                ...prev,
                                [selectedDay!]: [...(prev[selectedDay!] || []), newSlot]
                            };
                        });

                        let slotData = {
                            day: selectedDay,
                            startTime: newSlot.startTime,
                            endTime: newSlot.endTime
                        };
                        dispatch(createExpertAvailability(slotData));
                        setShowStartTime(true);
                        setShowDialog(false);
                        timePick.dispose();
                    }
                });
            }
        }
    }, [showDialog, selectedDay, showStartTime]);

    function onSubmit() {
        let apiData = {
            kycStatus: "SUBMITTED"
        };
        dispatch(updateExpertKyc(apiData));
    }

    return (
        <div className="mt-12">
            <div className="grid grid-cols-6 gap-4">
                <div className="col-start-2 col-span-4">
                    <div>
                        Click on + to add your availability slots. You can change your availability after onboarding.
                    </div>
                    <SlotWithWeek
                        availability={availability}
                        handleAddSlot={handleAddSlot}
                        handleRemoveSlot={handleRemoveSlot}
                    />

                    <div className="flex justify-center md:justify-end lg:justify-end mt-[60px]">
                        <Button
                            variant={'outline'}
                            onClick={() => onSubmit()}
                            className="mr-2"
                        >
                            Skip
                        </Button>
                        <Button
                            variant={'outline'}
                            onClick={prevStep}
                            className="mr-2"
                        >
                            Back
                        </Button>
                        <Button
                            onClick={() => onSubmit()}
                        >
                            Submit
                        </Button>
                    </div>
                </div>
            </div>
            {showDialog && (
                <div className="fixed inset-0 bg-gray-800 bg-opacity-75 flex justify-center items-center">
                    <div className="bg-white">
                        <span className="bg-[#007f73] w-full block text-white p-3 py-2 text-left text-[12px]">{showStartTime ? 'SELECT START TIME' : 'SELECT END TIME'}</span>
                        <div id="clock"></div>
                    </div>
                </div>
            )}
        </div>
    );
}

export default Step3;
