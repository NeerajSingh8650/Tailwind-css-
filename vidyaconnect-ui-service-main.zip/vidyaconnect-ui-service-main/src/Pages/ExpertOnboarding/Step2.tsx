import React, { useEffect, useRef, useState } from "react";
import add from "../../assets/add.svg";
import filledStar from "../../assets/star_filled.svg";
import star from "../../assets/star.svg";
import trash from "../../assets/trash.svg";
import { useDispatch, useSelector } from "react-redux";
import { AppDispatch, RootState } from "@/Redux/store/store";
import { fetchSkills } from "@/Redux/slices/ExpertSlice";
import { Button } from "../../shadcn/ui/button";
import { LINKED_IN_URL_REGEX_PATTERN } from "@/constants";
import ExpertCreateWorkProfilePage from "./ExpertCreateWorkProfilePage";
import { Step2Data } from "./ExpertOnboarding";
import { Education, WorkExperience } from "@/Redux/slices/ExpertsDataSlice";

interface Step2Props {
  data: Step2Data;
  nextStep: (data: Step2Data) => void;
  prevStep: () => void;
}

interface SkillApi {
  id: number;
  name: string;
}

interface Skill {
  skillName: string;
  level: number;
  skillId?: number;
}

const Step2 = ({ nextStep, prevStep, data }: Step2Props) => {
  const dispatch: AppDispatch = useDispatch();
  const { skills }: { skills: SkillApi[] } = useSelector(
    (state: RootState) => state.expert
  );
  const [selectedSkills, setSelectedSkills] = useState<Skill[]>(data.skills);
  const [skillSuggestions, setSkillSuggestions] = useState<SkillApi[]>(skills);
  const [linkedInProfileLink, setLinkedInProfileLink] = useState<string>(
    data.linkedInProfileLink
  );
  const [showError, setShowError] = useState<string>("");
  const [activeSkillIndex, setActiveSkillIndex] = useState<number | null>(null);
  const [showWorkProfile, setShowWorkProfile] = useState(false);
  const [workProfileAdded, setWorkProfileAdded] = useState(false);
  const skillRef = useRef<HTMLDivElement | null>(null);
  const work: WorkExperience[] = useSelector((state: RootState) => state.expertWorkProfile?.workExperiences)
  const education: Education[] = useSelector((state: RootState) => state.expertWorkProfile?.education)


  useEffect(() => {
    console.log("work data");
    console.log(work);
    console.log(education);
    if(work.length > 0 || education.length > 0) {
      setShowWorkProfile(true);
      setWorkProfileAdded(true);
    }

    function handleClickOutside(event: MouseEvent) {
        if (skillRef.current && !skillRef.current.contains(event.target as Node)) {
            setActiveSkillIndex(null); 
        }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
        document.removeEventListener('mousedown', handleClickOutside);
    };
}, []);

  useEffect(() => {
    dispatch(fetchSkills(""));
  }, [dispatch]);

  const handleStarClick = (index: number, skillIndex: number) => {
    if (selectedSkills[skillIndex].skillName.trim()) {
      const newSkills = selectedSkills.map((skill, idx) =>
        idx === skillIndex ? { ...skill, level: index + 1 } : skill
      );
      setSelectedSkills(newSkills);
    } else {
      setShowError(
        "Please enter a skill before selecting a proficiency level."
      );
    }
  };

  const handleSkillChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    skillIndex: number
  ) => {
    setShowError("");
    const value = e.target.value;
    const newSkills = [...selectedSkills];
    newSkills[skillIndex] = {
      ...newSkills[skillIndex],
      skillName: value,
    };
    setSelectedSkills(newSkills);
    setActiveSkillIndex(skillIndex);
    setSkillSuggestions(
      skills.filter(skill => skill.name.toLowerCase().includes(value.toLowerCase()))
    );
    
  };

  const handleSkillSelect = (skill: SkillApi, skillIndex: number) => {
    const newSkills = [...selectedSkills];
    newSkills[skillIndex].skillName = skill.name;
    newSkills[skillIndex].skillId = skill.id;
    setSelectedSkills(newSkills);
    setSkillSuggestions([]);
    setActiveSkillIndex(null);
    //skills.remove(skill)
  };

  const handlePlusClick = () => {
    setShowError("");
    const isReadyToAddNewSkill = selectedSkills.every(
      (skill) => skill.skillName && skill.level
    );

    if (isReadyToAddNewSkill) {
      setSelectedSkills([...selectedSkills, { skillName: "", level: 0 }]);
    } else {
      setShowError("Please fill skill details before adding a new skill.");
    }
  };

  const handleDeleteSkill = (skillIndex: number) => {
    const newSkills = selectedSkills.filter((_, index) => index !== skillIndex);
    setSelectedSkills(newSkills);
  };

  const handleNextStep = () => {
    if (linkedInProfileLink?.trim() === "" && !workProfileAdded) {
      setShowError(
        "Please enter a Linkedin profile URL or Create your work profile here."
      );
    } else if (selectedSkills.length === 0) {
      setShowError("Please enter atleast one skill");
    } else if (
      !selectedSkills.every((skill) => skill.skillName && skill.level)
    ) {
      setShowError("Please fill skill details completely");
    } else {
      nextStep({
        linkedInProfileLink: linkedInProfileLink,
        skills: selectedSkills,
      });
    }
  };

  return (
    <div className="mt-12 w-full">
      <div className="grid grid-cols-6 gap-4">
        <div className="col-start-2 col-span-4">
          <div className="w-full lg:w-[25rem] mb-[25px]">
            <label
              htmlFor=""
              className="font-medium text-[20px] lg:text-[18px]"
            >
              Work Profile
            </label>
            <span className="text-red-500 text-lg ms-1">*</span>
          </div>
          <label className="font-normal text-[16px] lg:text-[18px]">
            LinkedIn Profile
          </label>
          <div className="flex w-full flex-row linkedin-sec mt-2">
            <div>
              <input
                type="url"
                pattern={LINKED_IN_URL_REGEX_PATTERN}
                placeholder="Enter a valid LinkedIn profile URL"
                className="border border-graymod w-full font-extralight text-[16px] rounded-lg py-2 ps-3 outline-none lg:w-[25rem]"
                value={linkedInProfileLink}
                onChange={(e) => {
                  setShowError("");
                  setLinkedInProfileLink(e.target.value);
                }}
              />
            </div>
            <div className="linkedin-rgt ms-[30px]">
              <h3 className="font-normal text-[16px] lg:text-[18px]">
                or{" "}
                <Button
                  onClick={() => {
                    setShowWorkProfile(true);
                  }}
                  variant={"link"}
                  className="px-0 mx-6"
                  style={{ color: "#09A5D6", textDecoration: "underline" }}
                >
                  Create Work Profile
                </Button>
              </h3>
            </div>
          </div>
          {showWorkProfile && (
            <>
              <ExpertCreateWorkProfilePage
                onChange={() => setWorkProfileAdded(true)}
              />
              <hr className="my-[50px]" />
            </>
          )}
          <div className="flex justify-between mt-10 flex-col lg:flex-row">
            <div className="w-full lg:w-[25rem]">
              <label
                htmlFor=""
                className="font-medium text-[20px] lg:text-[18px]"
              >
                Skills
              </label>
            </div>
            <div className="mt-10 lg:mt-0 ">
              <label
                htmlFor=""
                className="font-medium text-[20px] lg:text-[18px]"
              >
                Proficiency Level
              </label>
            </div>
            <div className="flex justify-end items-center mr-6">
              &nbsp; &nbsp; &nbsp;
            </div>
          </div>
          {selectedSkills.length > 0 && (
            <>
              {selectedSkills.map((selectedSkill, skillIndex) => (
                <div
                  className="flex justify-between mt-4 flex-col lg:flex-row"
                  key={skillIndex}
                >
                  <div ref={skillRef}>
                    <div className="w-full lg:w-[25rem]" onClick={() => {
                      skillSuggestions.length > 0 ? setSkillSuggestions([]) : setSkillSuggestions(skills);
                      setActiveSkillIndex(skillIndex)
                    }}>
                      <input
                        type="text"
                        className="border border-graymod font-normal text-[16px] rounded-lg p-2 outline-none mt-2 block h-11 w-full"
                        value={selectedSkill.skillName}
                        onChange={(e) => handleSkillChange(e, skillIndex)}
                        onKeyDown={(e) => {
                          if (e.keyCode === 13) {
                            setActiveSkillIndex(null);
                          }
                        }}
                      />
                        {activeSkillIndex == skillIndex && skillSuggestions.length > 0 
                        && (
                          <ul className="border border-graymod w-full font-normal text-[16px] rounded-lg p-2 outline-none bg-white max-h-60 overflow-y-auto z-10">
                            {skillSuggestions.map(
                              (suggestion, suggestionIndex) => (
                                <li
                                  key={suggestionIndex}
                                  className="p-2 cursor-pointer hover:bg-gray-200 text-[14px]"
                                  onClick={() =>{
                                    handleSkillSelect(suggestion, skillIndex)
                                  }
                                  }
                                >
                                  {suggestion.name}
                                </li>
                              )
                            )}
                          </ul>
                        )}
                    </div>
                  </div>
                  <div className="mt-10 lg:mt-0">
                    <div className="mt-3">
                      <div className="flex flex-row items-center gap-4 justify-start lg:justify-center">
                        {[...Array(5)].map((_, index) =>
                          index < selectedSkill.level ? (
                            <img
                              src={filledStar}
                              alt="add"
                              key={index}
                              className="w-[25px] h-[auto] cursor-pointer"
                              onClick={() => handleStarClick(index, skillIndex)}
                            />
                          ) : (
                            <img
                              src={star}
                              alt="add"
                              key={index}
                              className="w-[25px] h-[auto] cursor-pointer"
                              onClick={() => handleStarClick(index, skillIndex)}
                            />
                          )
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-end items-center">
                    <img
                      src={trash}
                      alt="delete"
                      className="w-[25px] h-[auto] cursor-pointer"
                      onClick={() => handleDeleteSkill(skillIndex)}
                    />
                  </div>
                </div>
              ))}
            </>
          )}
          <div className="mt-6 flex items-center justify-between">
            <h2 className="font-normal text-[16px]">Add Skill</h2>
            <button onClick={handlePlusClick}>
              <img src={add} alt="add" className="w-[25px] h-[auto]" />
            </button>
          </div>
          <div className="flex justify-center md:justify-end lg:justify-end mt-[60px]">
            <Button variant={"outline"} onClick={prevStep} className="mr-2">
              Back
            </Button>
            <Button
              onClick={handleNextStep}
              disabled={
                (linkedInProfileLink === "" && !workProfileAdded) ||
                selectedSkills.length === 0
              }
            >
              Next
            </Button>
          </div>
          {showError && (
            <div className="mt-4">
              <p className="text-red-600 text-center text-[12px] lg:text-[14px] mt-2">
                {showError}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Step2;
