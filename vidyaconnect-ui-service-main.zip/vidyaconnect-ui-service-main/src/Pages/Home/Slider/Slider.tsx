import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore from "swiper";
import { FiChevronLeft, FiChevronRight } from "react-icons/fi";
import slider1 from "../../../assets/slider1.png";
import slider2 from "../../../assets/slider2.png";
import slider3 from "../../../assets/slider3.png";
import "./Slider.css";
import { Navigation } from "swiper/modules";
import { Pagination } from "swiper/modules";
import { Autoplay } from "swiper/modules";
// Import Swiper styles
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";

// Install Swiper modules
SwiperCore.use([Navigation, Pagination, Autoplay]);

interface SliderProps {
  onGetStarted: () => void;
}

const Slider: React.FC<SliderProps> = ({ onGetStarted }) => {
  return (
    <div className="my-12 mx-2 sm:mx-8 lg:mx-20 relative">
      <Swiper
        spaceBetween={30}
        autoplay={{
          delay: 10000,
          disableOnInteraction: false,
        }}
        navigation={{
          prevEl: ".swiper-button-prev",
          nextEl: ".swiper-button-next",
        }}
        pagination={{ clickable: true }}
        className="mySwiper rounded-3xl h-[665.9px]"
      >
        <SwiperSlide>
          <div className="relative">
            <img
              src={slider1}
              alt="person learning via online classes"
              className="w-full h-[665.9px] rounded-3xl"
            />
            <div className="absolute inset-0 flex flex-col justify-center items-center text-center pb-20 pt-28">
              <h1 className="text-2xl md:text-[44px] font-medium text-white mb-4 md:mb-6">
                Feature 1
              </h1>
              <p className="text-[16px] font-normal md:text-[22px] mb-16 text-white md:w-[653px] text-justify px-4 lg:px-0">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris
                nisi ut aliquip ex ea commodo consequat.
              </p>
              <h4 className="text-lg md:text-[47px] mb-4 md:mb-10 text-white">
                Find. Connect. Learn
              </h4>
              <button
                onClick={onGetStarted}
                className="login-btn text-white text-[20px] font-normal px-8 py-2 rounded-lg"
              >
                Get Started Today!
              </button>
            </div>
          </div>
        </SwiperSlide>
        <SwiperSlide>
          <div className="relative">
            <img
              src={slider2}
              alt="Image of happy graduates"
              className="w-full h-[665.9px]"
            />
            <div className="absolute inset-0 flex flex-col justify-center items-center text-center pb-20 pt-28">
              <h1 className="text-2xl md:text-[44px] font-medium text-white mb-4 md:mb-6">
                Feature 2
              </h1>
              <p className="text-[16px] font-normal md:text-[22px] mb-16 text-white md:w-[653px] text-justify px-4 lg:px-0">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris
                nisi ut aliquip ex ea commodo consequat.
              </p>
              <h4 className="text-lg md:text-[47px] mb-4 md:mb-10 text-white">
                Find. Connect. Learn
              </h4>
              <button
                onClick={onGetStarted}
                className="login-btn text-white text-[20px] font-normal px-8 py-2 rounded-lg"
              >
                Get Started Today!
              </button>
            </div>
          </div>
        </SwiperSlide>
        <SwiperSlide>
          <div className="relative">
            <img
              src={slider3}
              alt="Image of a person in a library"
              className="w-full h-[665.9px]"
            />
            <div className="absolute inset-0 flex flex-col justify-center items-center text-center pb-20 pt-28">
              <h1 className="text-2xl md:text-[44px] font-medium text-white mb-4 md:mb-6">
                Feature 3
              </h1>
              <p className="text-[16px] font-normal md:text-[22px] mb-16 text-white md:w-[653px] text-justify px-4 lg:px-0">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris
                nisi ut aliquip ex ea commodo consequat.
              </p>
              <h4 className="text-lg md:text-[47px] mb-4 md:mb-10 text-white">
                Find. Connect. Learn
              </h4>
              <button
                onClick={onGetStarted}
                className="login-btn text-white text-[20px] font-normal px-8 py-2 rounded-lg"
              >
                Get Started Today!
              </button>
            </div>
          </div>
        </SwiperSlide>
      </Swiper>
      {/* Navigation Arrows */}
      <div className="swiper-button-prev -ms-8 p-6 shadow-xl">
        <FiChevronLeft color="black" size={20} />
      </div>
      <div className="swiper-button-next p-6 -mr-8 shadow-xl">
        <FiChevronRight color="black" size={20} />
      </div>
    </div>
  );
};

export default Slider;
