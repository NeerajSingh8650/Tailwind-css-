import React, { useEffect } from "react";
import PasswordModal from "../../../Components/PasswordModal/PasswordModal";
import ResetPasswordModal from "../../../Components/ForgotPasswordModal/ResetPasswordModal";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "@/Redux/store/store";
import { PROFILE } from "@/constants";
import SuccessfullyResetPasswordModal from "@/Components/SuccessfullyResetPasswordModal/SuccessfullyResetPasswordModal";
import { setisSuccessPasswordModal } from "@/Redux/slices/authSlice";
import { useNavigate } from "react-router-dom";

interface HomeProps {
  showPasswordModal: boolean;
}

const Home: React.FC<HomeProps> = ({ showPasswordModal }) => {
  const isFogotPasswordModal = useSelector(
    (state: RootState) => state.auth.isResetPasswordModal
  );
  const isSuccessPasswordModal = useSelector(
    (state: RootState) => state.auth.isSuccessPasswordModal
  );
  const dispatch: any = useDispatch();
  const navigate = useNavigate();

  const { userDetails } = useSelector((state: RootState) => state.user);
  const isLoggedIn = JSON.parse(sessionStorage?.isLoggedIn || false);
  useEffect(() => {
    if (isLoggedIn && userDetails?.onboardingCompleted) {
      navigate(
        `/dashboard/${
          userDetails?.profile?.toLowerCase() === PROFILE.LEARNER
            ? "learner-portal"
            : "expert"
        }-home`
      );
    }
  }, [userDetails]);

  useEffect(() => {
    const handlePopState = (_event: PopStateEvent) => {
      history.pushState(null, document.title, window.location.href);
    };
    history.pushState(null, document.title, window.location.href);
    window.addEventListener("popstate", handlePopState);
    return () => {
      window.removeEventListener("popstate", handlePopState);
    };
  }, []);

  return (
    <div>
      {isSuccessPasswordModal && (
        <SuccessfullyResetPasswordModal
          onClose={() => dispatch(setisSuccessPasswordModal(false))}
        />
      )}
      {isFogotPasswordModal && (
        <ResetPasswordModal
          onSignIn={() => {}}
          onClose={() => {}}
          showResetPasswordModal={() => true}
        />
      )}
      {showPasswordModal && (
        <PasswordModal onSignIn={() => {}} onClose={() => {}} />
      )}
    </div>
  );
};

export default Home;
