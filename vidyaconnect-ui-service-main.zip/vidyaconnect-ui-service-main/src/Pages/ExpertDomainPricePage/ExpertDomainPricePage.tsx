import { fetchAllDomains } from '@/Redux/slices/DomainSlice';
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '@/Redux/store/store';


interface RateCardProps {
    data: Array<any>; // Define a more specific type if possible
    heading: string;
    className: string;
    rateClass: string;
    property: any;
    rate: boolean
    symbol: boolean
}

const RateCard: React.FC<RateCardProps> = ({ data, heading, className, rateClass, property, rate = false, symbol = true }) => {
    return (
        <div className="w-[294px]">
            <div className="bg-cyanmod-dark rounded-t-xl h-[16px]"></div>
            <div className="bg-white">
                <h1 className={`${className} h-28 text-[24px] font-semibold flex items-center justify-center flex-col`}>
                    <p>{heading}</p>
                    {rate && <p className='font-medium text-[14px] text-graymod'>Rate per hour</p>}
                </h1>
                {data.map((item) => (
                    <div key={item.id} className={`h-10 ${rateClass} text-[14px]  text-graymod-textfive border-t flex items-center justify-center`}>
                        {symbol && "₹"} {item[property]}
                    </div>
                ))}
                <hr />  
            </div>
            <div className="bg-cyanmod-dark rounded-b-xl h-[16px]"></div>
        </div>
    );
};

const ExpertDomainPricePage: React.FC = () => {
    const dispatch: any = useDispatch()
    const domainData = useSelector((state: RootState) => state.domainData.domains)
    useEffect(() => {
        dispatch(fetchAllDomains())
    }, [])

    return (
        <div className="xl:px-[10vw] lg:px-[7vw] bg-graymod-background min-h-[100vh] px-[4vw] pt-20">
            <h1 className="font-medium text-graymod-textfour text-[24px]">Expert pricing</h1>
            <hr className="h-[4px] bg-graymod-hr border-none mb-20 mt-2" />
            <div className="flex gap-2">
                <RateCard data={domainData} heading='Domain' className='' rateClass='font-semibold' property={"name"} rate={false} symbol={false}/>
                <RateCard data={domainData} heading='Silver' className="text-silverText" rateClass='font-medium' property={'goldBucket'} rate={true} symbol={true}/>
                <RateCard data={domainData} heading='Gold' className='text-goldText' rateClass='font-medium' property='silverBucket' rate={true} symbol={true}/> 
                <RateCard data={domainData} heading='Platinum' className='text-platinumText' rateClass='font-medium' property='platinumBucket' rate={true} symbol={true}/>
            </div>
        </div>
    );
};

export default ExpertDomainPricePage;
