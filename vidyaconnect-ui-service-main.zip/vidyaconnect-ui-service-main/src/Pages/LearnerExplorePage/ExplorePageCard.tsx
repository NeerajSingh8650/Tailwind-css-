import { FaStar } from "react-icons/fa";
import { useDispatch } from "react-redux";
import { idUpdate } from "../../Redux/slices/ExpertsDataSlice";
import { useNavigate } from "react-router-dom";
import { ExploreBookSessionModalUpdate } from "../../Redux/slices/FlagsSLice";
import { Button } from "@/shadcn/ui/button";

import { bucketUpdate } from "../../Redux/slices/GetLiveHelpSlice";
import { getExpetLabelImage, getExpertLabelText, getExpertDefaultUserIcon } from "@/utils/ExpertMembershipUtilities";
import ExpertBookSessionModalManager from "@/Components/ExpertBookSessionModalManager";

interface ExplorePageCardProps {
  experts: any[];
  search: string;
  domainId: number
}

const ExplorePageCard = ({ experts, search, domainId }: ExplorePageCardProps) => {
  const dispatch = useDispatch()
  const navigate = useNavigate()


  const renderStars = (rating: number) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <FaStar
          key={i}
          className={
            i <= rating ? "text-yellow-star w-6 h-6" : "text-graymod-star w-6 h-6"
          }
        />
      );
    }
    return stars;
  };



  const bookSessionClick = (data: any) => {
    dispatch(idUpdate(data.expertId))
    dispatch(bucketUpdate(data.expertPriceBucket))
    dispatch(ExploreBookSessionModalUpdate(true))
  }

  const viewProfileClick = (data: any) => {
    dispatch(idUpdate(data.expertId))
    dispatch(bucketUpdate(data.expertPriceBucket));
    navigate(`/expert/profile/${data.expertId}`, { state: { domainId } })
  }

  return (
    <>
      <ExpertBookSessionModalManager domainId={domainId} />
      <div className="mt-12 mb-20 mx-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {experts?.filter((data) => {
            return search.toString().toLowerCase() === "" ? data : data.expertName.toLowerCase().includes(search)
          }).map((data) => (

            <div
              onClick={() => {
                dispatch(idUpdate(data.expertId))
              }}
              key={data.expertId}
              className="border relative border-graymod p-5 rounded-lg"
            >
              <div className="absolute top-0 right-0 flex justify-center items-center">
                <span className="absolute text-white text-xs">{getExpertLabelText(data.expertPriceBucket)}</span>
                <img src={getExpetLabelImage(data.expertPriceBucket)} alt="" />
              </div>
              <div className="flex  items-center gap-4 justify-center">
                <img src={data.picUrl !== null ? data.picUrl : getExpertDefaultUserIcon(data.expertPriceBucket)} className=" object-cover rounded-[50%] w-[60px] h-[60px]" />
                <div className="">
                  <h2 className="text-[20px] font-normal mb-1">
                    {data.expertName}
                  </h2>
                  <div className="flex justify-between items-center ">
                    <div className="flex justify-between space-x-1 w-20">
                      {renderStars(data.ratings)}
                    </div>
                    <p className="text-[12px] text-graymod-texttwo ml-3 mt-1 text-nowrap">
                      {data.sessions} Sessions
                    </p>
                  </div>
                </div>
              </div>
              <div className="flex gap-2 justify-center mt-3">
                <Button onClick={() => viewProfileClick(data)} size={"vsm"} variant="outline">
                  View Profile
                </Button>

                <Button onClick={() => bookSessionClick(data)} size={"vsm"}>
                  Book Session
                </Button>
              </div>
            </div>

          ))}
        </div>
      </div>
    </>
  );
};

export default ExplorePageCard;
