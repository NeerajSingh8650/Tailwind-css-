import { useEffect, useState } from "react";
import ExplorePageCard from "./ExplorePageCard";
import "./ExplorePageFilters.css";
import { Link } from "react-router-dom";
import LinkOpener from "../../assets/linkOpener.svg";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";
import { RootState } from "../../Redux/store/store";
import {
  fetchExperts,
  fetchLabels,
} from "../../Redux/slices/ExpertExporeApiSlice";

const ExplorePageFilters = () => {
  const [searchFilter, setSearchFilter] = useState<string>("");
  const dispatch = useDispatch();
  const [selectedLabelId, setSelectedLabelId] = useState(1);
  const labelSelector = useSelector(
    (state: RootState) => state.expertExploreApi.labels
  );
  const userSelector = useSelector(
    (state: RootState) => state.expertExploreApi.experts
  );

  const handleClick = (labelId: number) => {
    setSelectedLabelId(labelId);
  };

  useEffect(() => {
    dispatch(fetchExperts(selectedLabelId));
    dispatch(fetchLabels());
  }, [selectedLabelId]);

  return (
    <>
      <h2 className="font-medium text-[25px] lg:text-[30px] mb-10 ml-9">
        Explore
      </h2>
      <Link
        className="text-cyanmod font-medium absolute right-20 flex gap-2"
        rel="noopener noreferrer"
        target="_blank"
        to={"/expert-pricing"}
      >
        Expert Pricing <img src={LinkOpener} alt="" />
      </Link>
      <div className="flex flex-row w-auto  gap-3">
        <div className="border border-1 border-[#C7C7C7] w-[70%] md:w-[40%] lg:w-[20%] flex flex-row justify-evenly rounded-full p-1 pr-3 ml-9">
          <input
            onChange={(e) => setSearchFilter(e.target.value.toString())}
            placeholder="Search"
            type="text"
            className="w-[85%] outline-none ml-3"
          />
        </div>
      </div>
      <div className="flex gap-2 mt-5 ml-9 flex-wrap">
        {labelSelector.map((data) => (
          <div
            key={data.labelId}
            onClick={() => handleClick(data.labelId)}
            className={`py-1 px-4 rounded-3xl border cursor-pointer border-[#e7e7e7] text-[16px] ${
              selectedLabelId === data.labelId ? "bg-[#002834] text-white" : ""
            }`}
          >
            {data.labelName}
          </div>
        ))}
      </div>
      <ExplorePageCard search={searchFilter} experts={userSelector} domainId={selectedLabelId} />
    </>
  );
};

export default ExplorePageFilters;
