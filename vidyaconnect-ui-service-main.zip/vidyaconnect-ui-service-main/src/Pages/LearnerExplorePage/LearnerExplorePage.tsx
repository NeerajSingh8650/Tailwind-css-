import ExplorePageFilters from "./ExplorePageFilters";

const LearnerExplorePage = () => {
  return (
    <div className="my-12 mx-0 sm:my-12 sm:mx-10">
      <ExplorePageFilters />
    </div>
  );
};

export default LearnerExplorePage;
