import * as React from "react";
import expertProfileBg from "../../assets/expert-profile-bg.png";
import userIcon from "../../assets/userIcon.svg";
import { FaStar } from "react-icons/fa";
import CircularProgressBar from "../../Components/CircularProgressBar/CircularProgressBar";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { AppDispatch, RootState } from "../../Redux/store/store";
import { Education, getExpertProfile, WorkExperience } from "../../Redux/slices/ExpertsDataSlice";
import { Button } from "@/Components/ui/button";
import { Params, useLocation, useParams } from "react-router-dom";
import { ExploreBookSessionModalUpdate } from "@/Redux/slices/FlagsSLice";
import ExpertBookSessionModalManager from "@/Components/ExpertBookSessionModalManager";
import { Feedback, getExpertReviews } from "@/Redux/slices/FeedbackSlice";
import CustomSpinner from "@/Components/CustomSpinner/CustomSpinner";


const HeadingButton: React.FC<any> = ({ value, heading, onClick }) => {
    return (
        <div
            onClick={onClick}
            className={`w-[248px] flex items-center justify-center cursor-pointer text-graymod-textfour border-graymod"} font-medium text-[22px] pb-2 transition-all duration-100 ${heading === value && "border-cyanmod text-cyanmod"} border-b-4`}>
            {heading}
        </div>
    );
};

const ExpertViewProfilePage = () => {
    const { expertIdParam } = useParams<Params>();
    const location = useLocation();
    let expertId: number = 0;
    if (expertIdParam) {
        expertId = +expertIdParam
    } else {
        console.error("no expert id found in url path");
    }
    const [tab, setTab] = React.useState("Work Experience");
    const expertData = useSelector((state: RootState) => state.expertData.expertProfileData);
    const bucket = useSelector((state: RootState) => state.getHelp.bucket);
    const { domainId } = location.state || {}
    const reviewData = useSelector((state: RootState) => state.feedback);
    const dispatch: AppDispatch = useDispatch();

    useEffect(() => {
        dispatch(getExpertProfile({
            expertId,
            domainId,
            priceBucket: bucket
        }));
        dispatch(getExpertReviews({
            expertId,
            domainId
        }));
    }, []);

    const renderStars = (rating: number) => {
        const stars = [];
        for (let i = 1; i <= 5; i++) {
            stars.push(
                <FaStar
                    key={i}
                    className={`h-[24.47px] ${i <= rating ? "text-[#FFC700]" : "text-[#919EAB]"}`}
                />
            );
        }
        return stars;
    };

    const renderTabContent = () => {
        switch (tab) {
            case "Work Experience":
                return (
                    <div className="flex flex-col gap-12 mt-16 overflow-y-auto h-[40vh]">
                        {expertData.workExperiences.map((data: WorkExperience) => (
                            <div className="border-l border-graymod-light pl-4" key={data.position}>
                                <h3 className="font-medium text-[24px] text-graymod-textone mb-1">
                                    {data.position}
                                </h3>
                                <p className="font-medium text-[20px] text-graymod-textone mb-1">
                                    {data.company}
                                </p>
                                <p className="font-normal text-[16px] text-graymod-texttwo mb-4">
                                    {data.startDate === null || "" ? "" : data.startDate.slice(0, 4)} - {data.endDate === null || "" ? "Present" : data.endDate.slice(0, 4)}
                                </p>
                                <p className="font-normal text-[16px] w-[55vw] text-graymod-textthree mb-1">
                                    {data.description === null || '' ? " " : data.description}
                                </p>
                            </div>
                        ))}
                    </div>
                );
            case "Education":
                return (
                    <div className="flex flex-col gap-12 mt-16 overflow-y-auto h-[40vh]">
                        {expertData.education.map((data: Education) => (
                            <div className="border-l border-graymod-light pl-4" key={data.company}>
                                <h3 className="font-medium text-[24px] text-graymod-textone mb-1">
                                    {data.company}
                                </h3>
                                <p className="font-medium text-[16px] text-graymod-textone mb-1">
                                    {data.degree}, {data.course}
                                </p>
                                <p className="font-normal text-[14px] text-graymod-one mb-4">
                                    {data.startDate === null || "" ? "" : data.startDate}-{data.endDate === null || "" ? "Pursuing" : data.endDate}
                                </p>
                                <p className="font-normal text-[16px] w-[55vw] text-graymod-textthree mb-1">
                                    {data.description === null || '' ? " " : data.description}
                                </p>
                            </div>
                        ))}
                    </div>
                );

            case "Reviews":
                return (
                    <div className="flex gap-3 mt-16 h-[40vh]">
                        {reviewData.loading ? (
          <CustomSpinner />
        ) : (
          <div className="grid xl:grid-cols-3 overflow-y-auto gap-6 mb-5">
            {reviewData.data.filter((data: Feedback) => data.review !== null && data.review.trim() !== '')
            .map((data: Feedback) => (
              <div key={data.id} className="p-3 text-[16px] border flex flex-col gap-2 bg-white rounded-2xl ">
                <div className="flex items-center mb-1 justify-start">
                  <div className="ml-4">
                    <h2 className="font-medium text-[16px] text-[#515151]">{data.learnerName}</h2>
                    <div className="flex gap-1">{renderStars(+data.rating)}</div>
                  </div>
                </div>
                <div className="text-[14px] h-[6rem] overflow-y-auto text-[#616161] ml-4">
                  {data.review}
                </div>
              </div>
            ))}
          </div>
        )}
        </div>
        );
            default:
                return null;
        }
    };

    return (
        <div className="flex flex-col mx-10 mt-12">
            <img
                src={expertProfileBg}
                alt=""
                className="w-full h-[8rem] md:h-[12rem] rounded-t-[10px] md:rounded-t-[16px]"
            />
            <div className="flex ">
                <div className="w-[25%] relative p-4">
                    <div className="flex flex-col items-center">
                        <div className=" top-[40%] flex items-center justify-center flex-col md:top-[55%] left-8">
                            <label htmlFor="">
                                <div className="-top-20 left-1/2 transform -translate-x-1/2 absolute rounded-[50%] bg-white">
                                    {expertData?.picUrl === null && <div className="w-40 h-40 flex items-center justify-center">
                                        <img src={userIcon} className="rounded-[50%] h-[190px] w-[190px]" alt="" />
                                    </div>}
                                    {expertData?.picUrl !== null && <img src={expertData?.picUrl} className="w-40 h-40 object-cover rounded-[50%] object-center" alt="" />}
                                </div>
                            </label>
                            <div className="flex flex-col justify-center items-center mt-20 gap-2">
                                <h4 className="font-semibold text-[24px] capitalize">
                                    {expertData.name}
                                </h4>
                                {expertData.priceBucket != null && (<h5 className="text-[20px] text-[#5B5B5B] text-center">
                                    {expertData.priceBucket}
                                </h5>)}
                                <div className="flex items-center gap-2">
                                    <div className="gap-5">
                                        <div className="flex items-center space-x-1">
                                            {renderStars(expertData.ratings)}
                                        </div>
                                        <span className="text-[20.56px] text-[#5B5B5B]">
                                            {expertData.numSessions} sessions
                                        </span>
                                    </div>
                                </div>
                                <div className="mt-4">
                                    <Button size={"vlg"} className="scale-75" onClick={() => dispatch(ExploreBookSessionModalUpdate(true))}>
                                        Book Session
                                    </Button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="w-[75%] p-4">
                    <div className="flex mb-4">
                        <HeadingButton
                            onClick={() => setTab("Work Experience")}
                            heading="Work Experience"
                            value={tab}
                        />
                        <HeadingButton
                            onClick={() => setTab("Education")}
                            heading="Education"
                            value={tab}
                        />
                        <HeadingButton
                            onClick={() => setTab("Reviews")}
                            heading="Reviews"
                            value={tab}
                        />

                    </div>
                    <div className="tab-content">
                        {renderTabContent()}
                    </div>
                    <div className="align-baseline">
                        <hr className="mt-0" />
                        <p className="text-[22px] mt-3 mb-5 ml-2 text-[#515151]">Skills</p>
                        <div className="flex bottom-0 max-w-[656vw] gap-8 overflow-auto end-4">
                            {expertData.skills.map((data: any) => (
                                <CircularProgressBar key={data.expertSkillId} skillName={data.name} percentage={data.score} />
                            ))}
                        </div>
                    </div>
                </div>
            </div>
            <ExpertBookSessionModalManager domainId={domainId} />
        </div>
    );
};

export default ExpertViewProfilePage;
