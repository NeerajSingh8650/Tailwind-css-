import { useEffect } from "react";
import SessionHistoryCard from "../../Components/SessionCard/SessionCard";
import { useDispatch, useSelector } from "react-redux";
import { AppDispatch, RootState } from "@/Redux/store/store";
import {
  fetchSessionHistory
} from "@/Redux/slices/SessionRequestSlice";
import {
  BOOKING_STATUS_REJECTED,
  BOOKING_STATUS_CANCELLED,
  BOOKING_STATUS_COMPLETED,
  BOOKING_STATUS_EXPIRED,
} from "@/constants";
import SessionHistoryFilter from "@/Components/HistoryFilter/SessionHistoryFilter";
import SadFace from "../../assets/sad_face.svg";
import { Button } from "@/shadcn/ui/button";
import { useNavigate } from "react-router-dom";
import { learnerGetLiveHelpModalUpdate } from "@/Redux/slices/FlagsSLice";
import GetLiveHelpModalManager from "@/Components/GetLiveHelpModalManager";

export default function SessionHistoryPageLeaner() {
  const historyData = useSelector(
    (state: RootState) => state.session.completedData
  );
  const filter = useSelector((state: RootState) => state.session.filters);
  const dispatch: AppDispatch = useDispatch();
  const navigate = useNavigate();

  // Fetching sessions data
  useEffect(() => {
    dispatch(fetchSessionHistory(filter));
  }, [filter]);

  const options = [
    { label: "Completed", value: BOOKING_STATUS_COMPLETED },
    { label: "Rejected", value: BOOKING_STATUS_REJECTED },
    { label: "Cancelled", value: BOOKING_STATUS_CANCELLED },
    { label: "Expired", value: BOOKING_STATUS_EXPIRED},
  ];


  return (
    <div className="bg-[#E2E2E2] px-20 py-8">
      <h1 className="text-[24px] font-medium text-[#515151] mb-1">
        Session History
      </h1>
      <hr className="h-[4px] bg-[#BEBEBE]" />
      <div className="relative w-[180px] mt-5 mb-6">
        <SessionHistoryFilter options={options} />
      </div>
      {historyData?.length === 0 ? (
        <>
          <div className="flex flex-cols items-center justify-center h-[50vh]">
            <div className="text-[16px] font-normal text-gray max-w-[500px] text-center mb-4">
              <div className="empty-img mb-5 flex justify-center">
                <img src={SadFace} />
              </div>
              <p>
                Hi! Looks like you have not taken any sessions. You can Explore
                the Experts or Book a Session directly.
              </p>
              <div className="mt-4">
                <Button
                  className="mr-4"
                  onClick={() => navigate("/explore-experts")}
                >
                  Explore
                </Button>
                <Button onClick={() => dispatch(learnerGetLiveHelpModalUpdate(true))}>
                  Book Now
                </Button>
              </div>
            </div>
          </div>
        </>
      ) : (
        <div
          id="pendingreq"
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5"
        >
          {historyData.map((session: any) => (
            <SessionHistoryCard
              key={session.id}
              session={session}
              buttonText="Book Again"
              profile="LEARNER"
            />
          ))}
        </div>
      )}
      <GetLiveHelpModalManager/>
        </div>
  );
}
