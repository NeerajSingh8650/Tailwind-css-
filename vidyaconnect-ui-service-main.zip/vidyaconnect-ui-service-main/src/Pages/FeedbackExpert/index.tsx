import React, { useState } from 'react'
import { Button } from '@/shadcn/ui/button'
import { useDispatch } from 'react-redux'
import { submitFeedback, argsType } from '@/Redux/slices/FeedbackSlice'
import { MAX_RATING } from '@/constants'
import StarBorderIcon from '@mui/icons-material/StarBorder';
import StarIcon from '@mui/icons-material/Star';

import { Link, useNavigate, useParams } from 'react-router-dom';

type Params = {
    sessionToken: string;
};

const FeedbackExpert: React.FC = () => {
    const dispatch: any = useDispatch()
    const navigate = useNavigate()
    const { sessionToken } = useParams<Params>();


    const sessionDetails = atob(sessionToken || '');

    const [bookingId, expertId, expertName] = sessionDetails.split(':');

    const [review, setReview] = useState("")
    const [rating, setRating] = useState(0)

    const handleRating = (rating: number) => {
        setRating(rating)
    }

    const handleSubmitFeedback = (): void => {
        const data: argsType = {
            expertId: + expertId,
            bookingId: + bookingId,
            rating: String(rating),
            review: review
        }

        console.log(data)
        dispatch(submitFeedback(data))
        navigate("/")
        
    }


    return (
        <div className='h-[100vh] w-[100vw] bg-[#e2e2e2] flex justify-center items-center'>

            <div className='min-h-[32rem] min-w-[500px] bg-[#fff] border border-1 rounded-md p-4 relative flex flex-col justify-around'>
                <div className="text-white text-[1.3rem] flex items-center justify-center left-[0] p-[1rem] w-[100%] rounded-lg rounded-b-none bg-cyanmod-dark px-6 absolute top-[-3rem]">
                    Session Feedback
                </div>
                <div>
                    <p className='font-semibold text-[20px] text-center'>How was the session with {expertName}</p>

                    <div className='text-center mt-10'>
                        {Array.from({ length: MAX_RATING }, (_, index) => {
                            const starRating = index + 1;
                            return (
                                <button className='cursor-pointer mr-4' onClick={() => { handleRating(starRating) }}>
                                    {rating && rating >= starRating ? (
                                        <StarIcon fontSize='large' className='text-[#09A5D6]' />
                                    ) : (
                                        <StarBorderIcon fontSize='large' className='text-[#09A5D6]' />
                                    )}
                                </button>
                            )
                        })}
                    </div>
                </div>

                <div>
                    <p className='text-center mt-3 mb-3 text-[16px] font-semibold'>Additional Feedback</p>
                    <div className='text-center my-6 w-[100%]'>
                        <textarea
                            className='border border-solid border-[#09a5d6] w-[80%] h-[100px] rounded focus:outline-none p-2 bg-[#f6f6f6] resize-none'
                            onChange={(e) => { setReview(e.target.value) }} />
                    </div>
                </div>

                <div className='text-center'>
                    <Link to="/" >
                        <Button variant="outline" className='mr-4 py-2 px-6 border'>
                            Back to home
                        </Button>
                    </Link>
                    <Button onClick={handleSubmitFeedback}>Submit</Button>
                </div>
            </div>
        </div>
    )

}


export default FeedbackExpert;
