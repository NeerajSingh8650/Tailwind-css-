import { getLatestLegalContacts } from "@/Redux/slices/LegalContractsSlice"
import { RootState } from "@/Redux/store/store"
import { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"

import { PRIVACY_POLICY_DOCUMENT_TYPE } from "@/constants"
import PageHeading from "@/Components/PageHeadings"
import LegalComponent from "@/Components/LegalComponent/LegalComponent"


const Privacy = () => {
    const contracts = useSelector((state: RootState) => state.legalContracts)
    const dispatch = useDispatch();

    useEffect(() => {
        dispatch(getLatestLegalContacts(PRIVACY_POLICY_DOCUMENT_TYPE));
    }, [])

    
    return (
        <div className="flex-1 py-8 px-28 ">
        <PageHeading title="Privacy Policy"/>
        <LegalComponent htmlContent={contracts.privacy}/>
        </div>
    )
}

export default Privacy;
