import { getLatestLegalContactsByProfile } from "@/Redux/slices/LegalContractsSlice"
import { RootState } from "@/Redux/store/store"
import { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import LearnerExpertToggle from "../Help/LearnerExpertToogle"
import { PROFILE, TERMS_CONDITIONS_DOCUMENT_TYPE } from "@/constants"
import PageHeading from "@/Components/PageHeadings"
import './legal.css'
import LegalComponent from "@/Components/LegalComponent/LegalComponent"

const Terms = () => {
    const contracts = useSelector((state: RootState) => state.legalContracts)
    const dispatch = useDispatch();
    const profileExpert = PROFILE.EXPERT.toUpperCase();
    const profileLearner = PROFILE.LEARNER.toUpperCase();

    useEffect(() => {

        dispatch(getLatestLegalContactsByProfile({type: TERMS_CONDITIONS_DOCUMENT_TYPE, profile: profileExpert}));
        dispatch(getLatestLegalContactsByProfile({type: TERMS_CONDITIONS_DOCUMENT_TYPE, profile: profileLearner}));
    }, [])

    return (
        <div className="flex-1 py-8 px-28 ">
        <PageHeading title="Terms and Conditions"/>
        <LearnerExpertToggle
            learnerContent={() => <LegalComponent htmlContent={contracts.learnerTermsAndConditions}/>}
            expertContent={() => <LegalComponent htmlContent={contracts.expertTermsAndConditions}/>}
            heading=""
        />
        </div>
    )
}

export default Terms;
