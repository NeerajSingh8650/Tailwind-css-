import { getLatestLegalContacts } from "@/Redux/slices/LegalContractsSlice"
import { RootState } from "@/Redux/store/store"
import { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"

import { COOKIES_POLICY_DOCUMENT_TYPE } from "@/constants"
import PageHeading from "@/Components/PageHeadings"
import LegalComponent from "@/Components/LegalComponent/LegalComponent"



const Cookies = () => {
    const contracts = useSelector((state: RootState) => state.legalContracts)
    const dispatch = useDispatch();

    useEffect(() => {
        dispatch(getLatestLegalContacts(COOKIES_POLICY_DOCUMENT_TYPE));
    }, [])

    
    return (
        <div className="flex-1 py-8 px-28 ">
        <PageHeading title="Cookie Policy"/>
        <LegalComponent htmlContent={contracts.cookies}/>
        </div>
    )
}

export default Cookies;
