import ResetPassword from '@/Components/ForgotPasswordModal/ResetPasswordVerify';
import { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

function ForgotPasswordPage() {
    const navigate = useNavigate()
    useEffect(() => {
        navigate("/")
    }, [])
    const location = useLocation().pathname;
    const passwordResetModal = () => {
        return (
            <>
                {location.toString().toLowerCase().includes("/forgot-password") && <ResetPassword showResetPasswordModal={() => true} />}
            </>
        )
    }

    return (
        <div className=''>
            {passwordResetModal()}
        </div>
    )
}

export default ForgotPasswordPage