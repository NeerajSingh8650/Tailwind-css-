import { Link, useLocation } from "react-router-dom";
import '../Help/Help.css'
import { useEffect } from "react";

const ExpertSettingsMenu = () => {
  const { hash } = useLocation();
  const isActive = (iHash: string) => hash === iHash;

  useEffect(() => {
    if (!hash) {
      window.location.hash = 'personal';
    }
  }, [hash]);

  return (
    <div className="w-[380px] min-h-[100vh] h-[auto] flex flex-col items-center gap-8 pt-28 bg-[#FBFBFB] border-r border-[#dddddd]">
      <h1 className="text-[24px] font-semibold w-[293px] px-4 text-[#515151]">Settings</h1>
      <div className="flex flex-col gap-2">
        <ul>
          <li>
            <Link
              to="/expert-settings#personal"
              className={isActive("#personal") ? "active menu-item" : "menu-item"}
            >
              Personal
            </Link>
          </li>
          <li>
            <Link
              to="/expert-settings#bank-account"
              className={isActive("#bank-account") ? "active menu-item" : "menu-item"}
            >
              Bank Account
            </Link>
          </li>
          <li>
            <Link
              to="/expert-settings#availability"
              className={isActive("#availability") ? "active menu-item" : "menu-item"}
            >
              Availability
            </Link>
          </li>
          <li>
            <Link
              to="/expert-settings#calendar"
              className={isActive("#calendar") ? "active menu-item" : "menu-item"}
            >
              Calendar
            </Link>
          </li>
        </ul>
      </div>
    </div>
  )
}

export default ExpertSettingsMenu;