import React, { useEffect, useRef, useState } from "react";
import editPencil from "../../assets/editButton.svg";
import user from "../../assets/userIcon.svg";
import { toast } from "react-toastify";
import "./SettingPersonalPage.css";
import { useDispatch, useSelector } from "react-redux";
import { fetchTimeZones } from "../../Redux/slices/TimeZoneSlices";
import { AppDispatch, RootState } from "../../Redux/store/store";
import PhoneInput, { CountryData } from "react-phone-input-2";
import OtpVerificationModal from "../../Components/OtpVerificationModal/OtpVerificationModal";
import { generateOtp } from "../../Redux/slices/OtpGenerationSlice";
import camera from "../../assets/camerawithbg.svg";
import {
  fetchProfilePicture,
  fetchUserData,
  postProfilePicture,
} from "../../Redux/slices/ProfilePicGetUploadSlice";
import googleCalender from "../../assets/googleCalender.svg";
import MoreHorizIcon from "@mui/icons-material/MoreHoriz";
import { Switch } from "@/Components/ui/switch";
import {
  calendarAuthorization,
  calendarAutoSaveStatusUpdate,
  calendarCallback,
  checkIntegration,
  deleteGoogleCalendarIntegration,
  googleCalendarConnectedStatus,
} from "@/Redux/slices/GoogleCalenderApiSlice";
import { Button } from "@/shadcn/ui/button";
import { Label } from "@/Components/ui/label";
import { fetchBankDetails } from "@/Redux/slices/BankDetailsSlice";
import AskaQuestionModal from "@/Components/AskaQuestionmodal/AskaQuestionModal";
import SlotWithWeek from "@/Components/Slots/SlotWithWeek/SlotWithWeek";
import { timePicker } from "analogue-time-picker";
import ExpertRejectSessionPopUp from "@/Components/RejectPopUp/RejectPopUp";
import { AvailableSlot, createExpertAvailability, deleteExpertAvailability, getExpertAvailability, TimeSlot, updateExpertPersonalInfo } from "@/Redux/slices/ExpertSlice";
import dropDownIcon from "../../assets/down_arrow.svg"
import { useLocation } from "react-router-dom";
import ExpertSettingsMenu from "./ExpertSettingsMenu";
import PageHeading from "@/Components/PageHeadings";
import { getProfileDetails } from "@/Redux/slices/userSlice";
import { timeToMinutes } from "@/utils/utility";
import { MIN_SLOT_AVAILABILITY_DURATION_MINUTES } from "@/constants";


interface googleCalender {
  className: string;
  onchange: any;
  email: string;
  status: boolean;
  toogleValue: boolean;
}


interface DetailFieldProps {
  data: any;
  fieldName: string;
  field: string;
  editable?: boolean;
  onEdit?: () => void;
}

const DetailField: React.FC<DetailFieldProps> = ({ data, fieldName, field, editable = false, onEdit }) => (
  <div className="flex flex-col xl:gap-3 lg:gap-1 ">
    <h3 className="text-[20px]">{fieldName}</h3>
    <div className="flex gap-10 justify-between">
      <p className="text-[16px] text-[#515151]">
        {data === null ? "" : data[field]}
      </p>
      {editable && (<span className="cursor-pointer">
        <img onClick={onEdit} className="ml-4" src={editPencil} alt="Edit" />
      </span>)}
    </div>
  </div>
);

const GoogleCalendarStatus: React.FC<googleCalender> = ({
  email,
  toogleValue,
  status,
  className,
  onchange,
}) => {
  const dispatch: AppDispatch = useDispatch();
  const [viewOption, setViewOption] = useState(false);
  return (
    <span>
      <div
        className={`${className} flex justify-between items-center border-b text-[14px] text-[#515151] border-[#dddddd] py-3`}
      >
        {status && (
          <>
            <p className="italic">{email}</p>
            <div className="flex gap-3 items-center relative">
              <span>Connected</span>
              <MoreHorizIcon
                onClick={() => setViewOption(!viewOption)}
                className="rotate-90 cursor-pointer hover:bg-gray-100 rounded-[50%]"
              />
              {viewOption && (
                <div className="absolute top-8 left-[-2rem] bg-white border border-gray-300 rounded-lg shadow-md z-10 py-2 w-[138px]">
                  <p
                    onClick={async () => {
                      await dispatch(deleteGoogleCalendarIntegration());
                      await dispatch(checkIntegration());
                    }}
                    className="cursor-pointer text-[12px] ms-3"
                  >
                    Disconnect
                  </p>
                </div>
              )}
            </div>
          </>
        )}
      </div>
      <div className="flex items-center justify-between py-3 pt-10">
        <p className="text-[14px] text-[#515151]">
          Automatically add my sessions to Google Calendar
        </p>
        <Switch onCheckedChange={onchange} checked={toogleValue} />
      </div>
    </span>
  );
};

const BankDetails: React.FC<any> = ({ bankDetailsSelector, onClick }) => {
  const { name, account, ifsc } = bankDetailsSelector || {};
  return bankDetailsSelector ? (
    <div className="flex flex-col gap-6">
      <div className="grid grid-cols-2 w-[635px] items-center">
        <Label className="text-[18px]">Name</Label>
        <p className="text-graymod-textfour">{name}</p>
      </div>
      <div className="grid grid-cols-2 w-[635px] items-center">
        <Label className="text-[18px]">Account Number</Label>
        <p className="text-graymod-textfour">{account}</p>
      </div>
      <div className="grid grid-cols-2 w-[635px] items-center">
        <Label className="text-[18px]">IFSC Code</Label>
        <p className="text-graymod-textfour">{ifsc}</p>
      </div>
    </div>
  ) : (
    <div className="flex flex-col gap-[15rem]">
      <h1 className="mt-[15%] ml-[35%]">No bank details found</h1>
      <p>
        <span
          onClick={onClick}
          className="cursor-pointer text-cyanmod border-b border-cyanmod italic"
        >
          Raise a Ticket
        </span>
        &nbsp; to add or modify your bank details.
      </p>
    </div>
  );
};

const ExpertSlots: React.FC<any> = ({ }) => {
  const [availability, setAvailability] = useState<{ [key: string]: TimeSlot[] }>({});
  const [selectedDay, setSelectedDay] = useState<string | null>(null);
  const [showDialog, setShowDialog] = useState(false);
  const [editFlag, setEditFlag] = useState(true);
  const [slotDelConfirmation, setSlotDelConfirmation] = useState(false);
  const [showStartTime, setShowStartTime] = useState(true);
  const [tempSlot, setTempSlot] = useState<Partial<any>>({});
  const dispatch: AppDispatch = useDispatch();
  const timeSlots = useSelector((state: RootState) => state.expert.availableSlots);
  const delSlotData = useSelector(
    (state: RootState) => state.TimeSlots.deleteData
  );

  useEffect(() => {
    setAvailability({});
    timeSlots.map((data: AvailableSlot) => {
      let day = data.day;
      data.slots.map((slot: TimeSlot) => {
        const newSlot = {
          startTime: slot.startTime,
          endTime: slot.endTime,
        };
        setAvailability((prev) => {
          return {
            ...prev,
            [day!]: [...(prev[day!] || []), newSlot],
          };
        });
      });
    });
  }, [timeSlots]);

  const handleAddSlot = (day: string) => {
    setSelectedDay(day);
    setShowDialog(true);
  };

  const syncAvailability = () => {
    const newAvailability: { [key: string]: TimeSlot[] } = {};

    timeSlots.forEach(slot => {
      newAvailability[slot.day] = [...(newAvailability[slot.day] || []), ...slot.slots];
    });
    setAvailability(newAvailability);
  }

  useEffect(() => {
    dispatch(getExpertAvailability());
  }, []);

  useEffect(() => {
    syncAvailability();
  }, [timeSlots])

  useEffect(() => {
    if (showDialog && selectedDay) {
      const element = document.getElementById("clock");
      if (element) {
        const timePick = timePicker({
          element: element,
          mode: 12,
          time: { hour: 10, minute: 0 },
        });

        timePick.onCancel(() => {
          setTempSlot({});
          setShowStartTime(true);
          setShowDialog(false);
          //timePick.dispose();
        });

        timePick.onOk((hour, minute) => {
          const formattedHours =
            hour == 0
              ? "12"
              : hour == 12
                ? "00"
                : String(hour).padStart(2, "0");
          const formattedMinute = String(minute).padStart(2, "0");
          const time = `${formattedHours}:${formattedMinute}`;
          if (showStartTime) {
            setTempSlot({
              ...tempSlot,
              startTime: time,
            });
            setShowStartTime(false);
          } else {
            const startTimeMinutes = timeToMinutes(tempSlot.startTime || '00:00');
            const endTimeMinutes = timeToMinutes(time);
            const duration = endTimeMinutes - startTimeMinutes;

            if (endTimeMinutes <= startTimeMinutes || duration < MIN_SLOT_AVAILABILITY_DURATION_MINUTES) {
              alert(`End time must be at least ${MIN_SLOT_AVAILABILITY_DURATION_MINUTES} minutes greater than start time.`);
              setShowStartTime(true);
              return;
            }
            const newSlot = {
              startTime: tempSlot.startTime || "",
              endTime: `${formattedHours}:${formattedMinute}`,
            };
            setAvailability((prev) => {
              return {
                ...prev,
                [selectedDay!]: [...(prev[selectedDay!] || []), newSlot],
              };
            });

            let slotData = {
              day: selectedDay,
              startTime: newSlot.startTime,
              endTime: newSlot.endTime,
            };
            dispatch(createExpertAvailability(slotData));
            setShowStartTime(true);
            setShowDialog(false);
            timePick.dispose();
          }
        });

        return () => {
          timePick.dispose();
        };
      }
    }
  }, [showDialog, selectedDay, showStartTime]);

  return (
    <div className="">
      {slotDelConfirmation && (
        <ExpertRejectSessionPopUp
          heading="Are you sure you want to delete this slot?"
          onCancel={() => {
            setSlotDelConfirmation(false);
          }}
          onConfirm={() => {
            dispatch(deleteExpertAvailability(delSlotData)).then(() => {
              setSlotDelConfirmation(false);
              dispatch(getExpertAvailability());
            });
          }}
        />
      )}
      <SlotWithWeek
        data={timeSlots}
        availability={availability}
        handleAddSlot={handleAddSlot}
        delSlot={() => setSlotDelConfirmation(true)}
        Name="ExpertEditSlot"
        EditFlag={editFlag}
        flagChanger={() => setEditFlag(false)}
      />
      {showDialog && (
        <div className="fixed inset-0 bg-gray-800 bg-opacity-75 flex justify-center items-center">
          <div className="bg-white">
            <span className="bg-[#007f73] w-full block text-white p-3 py-2 text-left text-[12px]">{showStartTime ? 'SELECT START TIME' : 'SELECT END TIME'}</span>
            <div id="clock"></div>
          </div>
        </div>
      )}
      {!editFlag && (
        <div className="flex gap-4 justify-end my-20">
          <Button
            onClick={() => {
              setShowDialog(false);
              setEditFlag(true);
            }}
            variant={"outline"}
          >
            Cancel
          </Button>
          <Button
            onClick={() => {
              setShowDialog(false);
              setEditFlag(true);
            }}
          >
            Save
          </Button>
        </div>
      )}
    </div>
  );
};



function ExpertSettingsPage() {
  const [phoneEdit, setPhoneEdit] = useState<boolean>(false);
  const [timeZoneEdit, setTimeZoneEdit] = useState<boolean>(false);
  const [raiseATicketFlag, setRaiseATicketFlag] = useState<boolean>(false);
  const [toogleChange, SetToogleChange] = useState<boolean>(false);
  const [otpVerificationModalIsOpen, setOtpVerificationModalIsOpen] =
    useState(false);
  const [phoneNumber, setPhoneNumber] = useState<string>("");
  const [countryCode, setCountryCode] = useState<string>("");
  const dispatch: any = useDispatch();
  const timezonesSelector = useSelector(
    (state: RootState) => state.timezone.timezones
  );
  const personalDetails = useSelector(
    (state: RootState) => state.user.userDetails
  );
  const profilePicSelector: any = useSelector(
    (state: RootState) => state.profilePic.profilePicture
  );
  const isCalenderConnected: boolean = useSelector(
    (state: RootState) => state.googleCalender.isConnected
  );
  const toogleSelector: boolean = useSelector(
    (state: RootState) => state.googleCalender.toogle
  );
  const bankDetailsSelector: any = useSelector(
    (state: RootState) => state.bankDetails.bankDetails
  );

  const location = useLocation();


  const PersonalSettings = () => {
    const [timezone, setTimezone] = useState<string | undefined>(undefined);
    const timezoneRef = useRef<HTMLDivElement | null>(null);
    const [selectedTimezoneIndex, setSelectedTimezoneIndex] = useState(0);
    const [searchTerm, setSearchTerm] = useState<string>('');
    const [filteredItems, setFilteredItems] = useState<any[]>(timezonesSelector);

    
  useEffect(() => {
    setTimezone(personalDetails?.timezone);
  }, [personalDetails]);

    useEffect(() => {
      function handleClickOutside(event: MouseEvent) {
        if (timezoneRef.current && !timezoneRef.current.contains(event.target as Node)) {
          setFilteredItems([]);
        }
      };
      document.addEventListener('mousedown', handleClickOutside);
      return () => {
        document.removeEventListener('mousedown', handleClickOutside);
      }
    }, [])
  
  
    const handleSearch = (event: React.ChangeEvent<HTMLInputElement>) => {
      const value = event.target.value.toLowerCase();
      setSearchTerm(value);
      setFilteredItems(
        timezonesSelector.filter((timezonesSelector: any) => timezonesSelector.toLowerCase().includes(value))
      );
    };
  
    const handleTimezoneDropdownKeyDown = (event: React.KeyboardEvent) => {
      if (event.key === "ArrowDown" && selectedTimezoneIndex < filteredItems.length - 1) {
        setSelectedTimezoneIndex(selectedTimezoneIndex + 1);
      } else if (event.key === "ArrowUp" && selectedTimezoneIndex > 0) {
        setSelectedTimezoneIndex(selectedTimezoneIndex - 1);
      } else if (event.key === "Enter" && filteredItems.length > 0) {
        setTimezone(filteredItems[selectedTimezoneIndex]);
        setFilteredItems([]);
        setSearchTerm(filteredItems[selectedTimezoneIndex]);
      }
    };
    return (<div className="flex-1 p-8">
      {otpVerificationModalIsOpen && (
        <OtpVerificationModal
          phoneNumber={phoneNumber}
          countryCode={countryCode}
          isOpen={otpVerificationModalIsOpen}
          onClose={closeOtpVerificationModal}
          onValidationSuccess={closeOtpVerificationModal}
        />
      )}
      <div className="bg-white px-20">
        <PageHeading title="Personal Information" />
        <div className="grid xl:grid-cols-3 lg:grid-cols-2 justify-start  gap-10">
          <div className="h-[190px] w-[190px] rounded-[50%]  relative">
            <div className="absolute cursor-pointer w-[28px] -bottom-4 right-6 image-upload">
              <label htmlFor="file-input">
                <img
                  className="cursor-pointer"
                  src={camera}
                  alt="Upload"
                />
              </label>
              <input
                id="file-input"
                type="file"
                style={{ display: "none" }}
                onChange={handlePostProfilePic}
              />
            </div>
            <img
              className="profilepic rounded-[50%] object-cover object-center h-[190px] w-[190px] mt-8 "
              src={
                profilePicSelector === null ? user : profilePicSelector
              }
              alt=""
            />
          </div>
          <div className="flex flex-col gap-6 text-nowrap">
            <div className="grid xl:w-[40vw] lg:w-auto lg:grid-cols-1 lg:gap-4 xl:grid-cols-2 ">
              <DetailField
                fieldName="First Name"
                data={personalDetails}
                field={"firstName"}
              />
              <DetailField
                fieldName="Last Name"
                data={personalDetails}
                field={"lastName"}
              />
              <DetailField
                fieldName="Date of Birth"
                data={personalDetails}
                field={"dob"}
              />
              <DetailField
                fieldName="Gender"
                data={personalDetails}
                field={"gender"}
              />
            </div>

            <div className="flex flex-col xl:gap-3 lg:gap-1">
              <h3 className="text-[20px]">Timezone</h3>
              {timeZoneEdit ? (
                <div className=" relative flex rounded-md  h-[32px] w-[260px]">
                  <div className="relative" ref={timezoneRef} onClick={() => {
                    filteredItems.length > 0 ? setFilteredItems([]) : setFilteredItems(timezonesSelector)
                  }}>
                    <input
                      type="text"
                      value={searchTerm}
                      onChange={handleSearch}
                      onKeyDown={handleTimezoneDropdownKeyDown}
                      placeholder="Select Timezone"
                      className={`h-[32px] border border-graymod w-[260px] rounded-md px-3 placeholder:text-graymod outline-none`}
                    />
                    <img
                      src={dropDownIcon}
                      className="absolute z-[999] top-1 right-2 cursor-pointer w-6 " alt="" />
                    {filteredItems.length > 0 && (
                      <div className="absolute top-full max-h-[40vh] overflow-y-auto left-0 z-[999] bg-white rounded-md shadow-md w-full">
                        {filteredItems.map((suggestion, index) => (
                          <div key={index} className="px-3 py-1 border-b cursor-pointer hover:bg-gray-100" onClick={() => {
                            setTimezone(suggestion)
                            setFilteredItems([])
                            setSearchTerm(suggestion)
                          }}>
                            {suggestion}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="flex gap-10 justify-between">
                  <p className="text-[16px] text-[#515151]">
                    {timezone || "Select Timezone"}
                  </p>
                  <span onClick={() => setTimeZoneEdit(true)}>
                    <img
                      className="cursor-pointer"
                      src={editPencil}
                      alt=""
                    />
                  </span>
                </div>
              )}
            </div>

            {/* <div className="flex flex-col xl:gap-3 lg:gap-1">
                          <div className="flex flex-col gap-3">
                            <h3 className="text-[20px]">Phone Number</h3>
                          </div> */}
            {phoneEdit ? (
              <div>
                <div className="relative grid grid-cols-2 w-[35vw]">
                  <h3 className="text-[20px]">Phone Number</h3>
                  <div className="flex flex-col justify-end w-[225px] gap-2">
                    <PhoneInput
                      country={"in"}
                      value={`${countryCode}${phoneNumber}`}
                      onChange={(e, phone) =>
                        handleChange(e, phone as CountryData, "phoneNumber")
                      }
                      inputStyle={{
                        border: "1px solid #DDDDDD",
                        fontSize: "16px",
                        width: "225px",
                        height: "25px",
                        borderRadius: "8px",
                        outline: "none",
                      }}
                      inputProps={{
                        required: true,
                      }}
                    />
                    <div className="flex gap-3 justify-end">
                      <Button
                        variant={"outline"}
                        className=" h-[34px]"
                        size={"vsm"}
                        onClick={() => {
                          setPhoneEdit(false);
                        }}
                        disabled={false}>Cancel
                      </Button>
                      <Button
                        className="h-[34px]"
                        onClick={() => {
                          handleOtpGeneration();
                        }}
                        disabled={false}
                      >
                        Get OTP
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              // <div className="flex gap-10">
              //   <p className="text-[16px] text-[#515151]">
              //     +91 1234567890
              //   </p>
              //   <span onClick={() => setPhoneEdit(true)}>
              //     <img
              //       className="cursor-pointer"
              //       src={editPencil}
              //       alt=""
              //     />
              //   </span>
              // </div>

              <DetailField
                data={personalDetails}
                field={"phoneNumber"}
                fieldName={"Phone Number"}
                editable={true}
                onEdit={() => setPhoneEdit(true)}
              />
            )}

            <div className="mt-7">
              {timeZoneEdit ? (
                <div className="flex gap-4 justify-end">
                  <Button
                    onClick={() => {
                      setTimeZoneEdit(false);
                      setPhoneEdit(false);
                    }}
                    variant="outline"
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={async () => {
                      dispatch(updateExpertPersonalInfo({ timezone }))
                        .then(() => {
                          toast.success("Profile updated successfully!");
                          setTimeZoneEdit(false);
                          setPhoneEdit(false);
                          dispatch(getProfileDetails())
                        })
                    }}
                  >
                    Save
                  </Button>
                </div>
              ) : (
                ""
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
    );
  }


  useEffect(() => {
    dispatch(checkIntegration());
    dispatch(fetchUserData());
    dispatch(fetchBankDetails());
  }, []);

  const handleOtpGeneration = () => {
    dispatch(
      generateOtp({ countryCode, phoneNumber }))
      .then(() => openOtpVerificationModal());
  };

  const autosaveUpdate = (status: boolean) => {
    dispatch(calendarAutoSaveStatusUpdate(status));
  };

  const handlePostProfilePic = (e: any) => {
    dispatch(postProfilePicture(e)).then(() => {
      window.location.reload();
    });
  };
  const handleFetchProfilePic = () => {
    dispatch(fetchProfilePicture());
  };

  useEffect(() => {
    handleFetchProfilePic();
    dispatch(fetchTimeZones());
  }, []);

  useEffect(() => {
    dispatch(googleCalendarConnectedStatus());
  }, [toogleChange]);

  const handleChange = (
    e: string | undefined,
    value: CountryData | undefined,
    name: string
  ) => {
    if (name === "phoneNumber" && e && value) {
      let splitMobile = e.split(value?.dialCode || "");
      setCountryCode(value?.dialCode || "");
      setPhoneNumber(splitMobile[1] || "");
    }
  };

  const openOtpVerificationModal = () => {
    setOtpVerificationModalIsOpen(true);
  };

  const closeOtpVerificationModal = () => {
    setOtpVerificationModalIsOpen(false);
    setPhoneEdit(false);
  };


  const [externalPopup, setExternalPopup] = useState<Window | null>(null);

  useEffect(() => {
    if (!externalPopup) {
      return;
    }

    const timer = setInterval(async () => {
      if (!externalPopup) {
        timer && clearInterval(timer);
        return;
      }
      const currentUrl = externalPopup.location.href;
      if (!currentUrl) {
        return;
      }
      const searchParams = new URL(currentUrl).searchParams;
      const code = searchParams.get("code");
      if (code) {
        externalPopup.close();
        await dispatch(calendarCallback({ code }));
        setExternalPopup(null);
        timer && clearInterval(timer);
      }
    }, 500);
  }, [externalPopup]);

  const connectClick = (iframeUrl: string) => {
    const width = 500;
    const height = 600;
    const left = window.screenX + (window.outerWidth - width) / 2;
    const top = window.screenY + (window.outerHeight - height) / 2.5;
    const title = `WINDOW TITLE`;
    const url = iframeUrl;
    const popup = window.open(
      url,
      title,
      `width=${width},height=${height},left=${left},top=${top}`
    );
    setExternalPopup(popup);
  };

  const renderContent = () => {
    switch (location.hash) {
      case "#personal":
        return <PersonalSettings />;
      case "#bank-account":
        return (
          <div className="bg-white flex flex-col px-20">
            <PageHeading title="Bank Account Details" />
            <BankDetails
              bankDetailsSelector={bankDetailsSelector}
              onClick={() => setRaiseATicketFlag(true)}
            />
          </div>
        );

      case "#calendar":
        return (
          <>
            <div className="px-8 pr-[10vw] py-8">
              <PageHeading title="Calendar" />
              {!isCalenderConnected && (
                <p className="text-[#515151] text-[16px] mt-20">
                  Get connected to see all your assigned sessions in Google
                  Calendar.
                </p>
              )}
              {!isCalenderConnected ? (
                <div
                  onClick={async () => {
                    const result = await dispatch(
                      calendarAuthorization()
                    ).unwrap();

                    connectClick(result);
                  }}
                  className="w-[298px] h-[53px] border border-[#E1E1E1] cursor-pointer hover:bg-gray-100 rounded-lg flex items-center justify-around mt-5"
                >
                  <img src={googleCalender} alt="" />
                  <span className="text-[16px] font-medium text-[#515151]">
                    Connect to Google Calendar
                  </span>
                </div>
              ) : (
                <div className="flex mt-[2rem]">
                  <img
                    src={googleCalender}
                    alt=""
                    className="w-[3rem] h-[3rem]"
                  />
                  <div className="ml-[14px]">
                    <span>Google Calendar</span>
                    <p className="text-[12px]">
                      All your assigned sessions are now added to your Google
                      Calendar
                    </p>
                  </div>
                </div>
              )}
              {
                <GoogleCalendarStatus
                  toogleValue={toogleSelector}
                  email={
                    personalDetails === null ? "" : personalDetails.email
                  }
                  status={isCalenderConnected}
                  onchange={(e: boolean) => {
                    autosaveUpdate(e);
                    SetToogleChange((prev) => !prev);
                  }}
                  className="mt-12"
                />
              }
            </div>
          </>
        );

      case "#availability":
        return (
          <div className="px-10 pr-[10vw]">
            <PageHeading title="Availability" />
            <ExpertSlots />
          </div>
        );

      default:
        return <PersonalSettings />;
    }
  };

  return (
    <div className="flex">
      {raiseATicketFlag && (
        <AskaQuestionModal
          onClose={() => setRaiseATicketFlag(false)}
          concern="Modify Bank Account Details"
        />
      )}
      <ExpertSettingsMenu />

      <div className="flex-1  p-8">{renderContent()}</div>
    </div>
  );
}

export default ExpertSettingsPage;