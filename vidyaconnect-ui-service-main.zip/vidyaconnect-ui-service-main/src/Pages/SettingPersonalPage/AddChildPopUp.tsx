import { childUpdater } from '@/Redux/slices/LearnerSettingSlice';
import { Button } from '@/shadcn/ui/button';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '@/Redux/store/store';
import { toast } from 'react-toastify';
import ComboBox from '@/Components/ui/comboBox';
import { DatePicker, DatePickerProps } from 'antd';
import dayjs from 'dayjs';
import { API_DATE_FORMAT, USER_DATE_FORMAT } from '@/constants';

const AddChildPopUp: React.FC<any> = ({ onClose, onSubmit }) => {
    const dispatch = useDispatch();
    const [childDetails, setChildDetails] = useState<any>({
        name: '',
        dob: '',
        gender: '',
        schoolId: '',
        school: '',
        grade: ''
    });


    const childData = useSelector((state: RootState) => state.LearnerSetting.child);
    const companies = useSelector((state: RootState) => state.LearnerSetting.companies);

    // Function to handle input change and log the state
    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setChildDetails((prevState: any) => ({
            ...prevState,
            [name]: value
        }));
        dispatch(childUpdater({ ...childDetails, [name]: value }));
    };



    const handleDateChange: DatePickerProps["onChange"] = (date, dateString) => {
        if (date) {
            dateString = date.format(API_DATE_FORMAT).toString();
        }
        setChildDetails((prevState: any) => ({
            ...prevState,
            dob: dateString
        }));
        dispatch(childUpdater({ ...childDetails, dob: dateString }));
    };


    const handleCompanySelection = (data: any) => {
        setChildDetails({ ...childDetails, schoolId: data.id, school: data.name })
    }


    useEffect(() => {
        dispatch(childUpdater(childDetails))
    }, [childData?.school])


    const validations = (): boolean => {
        for (let key in childDetails) {
            if (childDetails[key] === "") {
                return false;
            }
        }
        return true;
    };


    const handleSubmit = () => {
        const isValid = validations();
        console.log(isValid);
        if (isValid) {
            onSubmit();
        } else {
            toast.error("Please fill in all the details.");
        }
    };



    return (
        <div className="social-modal learner-child-popup open w-[50rem] h-[auto]">
            <div className="my-12 mx-10">
                <h2 className="font-medium text-[20px] lg:text-[24px] text-graymod-textfive mb-7 justify-center flex ">
                    Child Information
                </h2>
                <div className="flex flex-col mt-12 md:flex-column md:ml-[0px] ml-[0px] space-x-3 md:space-x-8 justify-center gap-[20px] lg:gap-[50px] sm: items-center md:items-start">
                    <div className="child-info-card mb-10">
                        <table className="full-width">
                            <tr>
                                <td>
                                    <label className="font-normal text-[16px] lg:text-[20px]">Name</label>
                                </td>
                                <td>
                                    <input
                                        type="text"
                                        className="border border-graymod w-full font-extralight text-[16px] rounded-lg py-2 mt-3 ps-3 outline-none"
                                        placeholder="Name"
                                        name="name"
                                        value={childDetails.name}
                                        onChange={handleChange}
                                    />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label className="font-normal text-[16px] lg:text-[20px]">Date of Birth</label>
                                </td>
                                <td>
                                    <DatePicker
                                        value={childDetails?.dob ? dayjs(childDetails.dob) : null}
                                        onChange={handleDateChange}
                                        placeholder="Add date of birth"
                                        format = {USER_DATE_FORMAT}
                                        className="h-[44px] border border-graymod font-extralight text-[16px] rounded-lg py-2 ps-3 outline-none mt-3 lg:w-full w-full"
                                        id="dateSel"
                                    />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label className="font-normal text-[16px] lg:text-[20px]">Gender</label>
                                </td>
                                <td>
                                    <select
                                        name="gender"
                                        className="h-[44px] bg-white border border-graymod w-full font-extralight text-[16px] rounded-lg py-2 ps-3 outline-none mt-3"
                                        value={childDetails.gender}
                                        onChange={handleChange}
                                    >
                                        <option value="">Select Gender</option>
                                        <option value="MALE">Male</option>
                                        <option value="FEMALE">Female</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label htmlFor="" className="font-normal text-[16px] lg:text-[20px] mb-4">School</label>
                                </td>
                                <td>
                                    <ComboBox
                                        placeholder='Add School'
                                        suggestions={companies}
                                        onSelect={handleCompanySelection}
                                        className="h-[40px] mt-3"
                                        onChange={(data: any) => {
                                            dispatch(childUpdater({ ...childDetails, school: data, schoolId: null }))
                                        }}
                                    />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label htmlFor="" className="font-normal text-[16px] lg:text-[20px] mb-4">Grade</label>
                                </td>
                                <td>
                                    <input
                                        type="text"
                                        className="border border-graymod w-full font-extralight text-[16px] rounded-lg py-2 ps-3 outline-none mt-3 mb-3"
                                        placeholder="Eg: V"
                                        name="grade"
                                        value={childDetails.grade}
                                        onChange={handleChange}
                                    />
                                </td>
                            </tr>
                            <tr>
                                <td colSpan={2} className="w-full pt-20 btn-w-width text-right">
                                    <Button variant="outline" onClick={onClose} className="mx-5">
                                        Cancel
                                    </Button>
                                    <Button onClick={handleSubmit}>
                                        Save
                                    </Button>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AddChildPopUp;
