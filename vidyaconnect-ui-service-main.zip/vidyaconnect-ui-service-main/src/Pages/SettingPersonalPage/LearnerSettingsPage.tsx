import React, { useEffect, useState } from "react";
import editPencil from '../../assets/editButton.svg';
import user from "../../assets/userIcon.svg";
import "./SettingPersonalPage.css";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../Redux/store/store";
import camera from "../../assets/camerawithbg.svg";
import { fetchProfilePicture, postProfilePicture } from "../../Redux/slices/ProfilePicGetUploadSlice";
import googleCalender from "../../assets/googleCalender.svg";
import MoreHorizIcon from "@mui/icons-material/MoreHoriz";
import { Switch } from "@/Components/ui/switch";
import { calendarAuthorization, calendarAutoSaveStatusUpdate, calendarCallback, checkIntegration, googleCalendarConnectedStatus } from "@/Redux/slices/GoogleCalenderApiSlice";
import AskaQuestionModal from "@/Components/AskaQuestionmodal/AskaQuestionModal";
import { addChildren, childUpdater, deleteChildById, fetchChildren, fetchCompanies, fetchLearnerSettings, gradeUpdater, learnerUpdater, schoolUpdater, updateChildren, updateLearnerSettings } from "@/Redux/slices/LearnerSettingSlice";
import childBoy from "../../assets/childBoy.svg"
import childGirl from "../../assets/childGirl.svg"
import { Button } from "@/shadcn/ui/button";
import { Select } from "@/shadcn/ui/select";
import { Trash2 } from "lucide-react";
import add from '../../assets/add.svg';
import {
    SelectContent,
    SelectGroup,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/Components/ui/select"
import { Input } from "@/Components/ui/input";
import moment from "moment";
import AddChildPopUp from "./AddChildPopUp";
import ExpertRejectSessionPopUp from "@/Components/RejectPopUp/RejectPopUp";
import { LearnerProfileType } from "@/constants";
import ComboBox from "@/Components/ui/comboBox";
import LearnerSettingsMenu from "./LearnerSettingsMenu";
import { useLocation } from "react-router-dom";
import PageHeading from "@/Components/PageHeadings";


interface GoogleCalendarProps {
    className: string;
    onchange: any;
    email: string;
    status: boolean;
    toggleValue: boolean;
}


function convertUTCtoLocalDateTime(utcDateTime: string): moment.Moment {
    let localTime = moment.utc(utcDateTime).toDate();
    const local = moment(localTime);
    return local;
}

interface DetailFieldProps {
    data: any;
    fieldName: string;
    field: string;
    field2?: string;
}

const DetailField: React.FC<DetailFieldProps> = ({ data, fieldName, field, field2 }) => {
    const renderFieldValue = (field: string) => {
        if (!data || data[field] === null) return "";

        if (field === "dob") {
            return convertUTCtoLocalDateTime(data[field]).format('MMMM D, YYYY');
        }

        return data[field];
    };

    const renderAdditionalField = (field2?: string) => {
        if (field2 && data && data[field2] !== null) {
            return data[field2];
        }
        return "";
    };

    return (
        <div className="grid grid-cols-2 w-[35vw]">
            <h3 className="text-[16px] text-platinumText">{fieldName}</h3>
            <p className={`text-[16px]`}>
                {renderFieldValue(field)} {renderAdditionalField(field2)}
            </p>
        </div>
    );
};



interface DetailFieldEditProps {
    data: any;
    fieldName: string;
    field: string;
    onEdit: () => void;
}

export const DetailFieldEdit: React.FC<DetailFieldEditProps> = ({ data, fieldName, field, onEdit }) => (
    <div>
        <div className="relative grid grid-cols-2 w-[35vw]">
            <h3 className="text-[16px] text-platinumText">{fieldName}</h3>
            <p className={`text-[16px]`}>
                {data && data[field] ? data[field] : ""}
            </p>
            {data && data[field] && data[field].toUpperCase() !== LearnerProfileType.PARENT && (
                <img onClick={onEdit} className="cursor-pointer absolute right-8" src={editPencil} alt="Edit" />
            )}
        </div>
    </div>
);



const ProfileEdit: React.FC<any> = ({ fieldName }) => {
    const dispatch = useDispatch()
    const learnerSelector = useSelector((state: RootState) => state.LearnerSetting.learnerDetails)
    return (
        <div className="">
            <div className="relative grid grid-cols-2 w-[35vw]">
                <h3 className="text-[16px] text-platinumText">{fieldName}</h3>
                <Select onValueChange={(e) => dispatch(learnerUpdater({ ...learnerSelector, learnerProfile: e }))}>
                    <SelectTrigger className="w-[225px] text-[12px] h-[25px]">
                        <SelectValue placeholder="Select Your Learning Role" />
                    </SelectTrigger>
                    <SelectContent className="w-[225px]">
                        <SelectGroup>
                            <SelectItem value={LearnerProfileType.PROFESSIONAL}>{LearnerProfileType.PROFESSIONAL}</SelectItem>
                            <SelectItem value={LearnerProfileType.SEEKING_OPPORTUNITIES}>{LearnerProfileType.SEEKING_OPPORTUNITIES}</SelectItem>
                            <SelectItem value={LearnerProfileType.STUDENT}>{LearnerProfileType.STUDENT}</SelectItem>
                        </SelectGroup>
                    </SelectContent>
                </Select>
            </div>
        </div>

    )
}




const ChildCard: React.FC<any> = ({ onClick, gender, school, grade, dob, name }) => {
    const [isEdit, setIsEdit] = useState<boolean>(false)
    const dispatch: any = useDispatch()
    const childData = useSelector((state: RootState) => state.LearnerSetting.child);
    const companies = useSelector((state: RootState) => state.LearnerSetting.companies);
    const filteredCompanies = useSelector((state: RootState) => state.LearnerSetting.filteredCompanies);
    const [deleteConfirmationModal, setDeleteConfirmationModal] = useState<boolean>(false);

    const handleCompanySelection = (data: any) => {
        dispatch(childUpdater({ ...childData, school: data.target.value }));
    }

    useEffect(() => {
        if (filteredCompanies.length === 0) {
            dispatch(childUpdater({ ...childData, schoolId: null }));
        }
    }, [childData?.school])



    function truncateString(str: string): string {
        if (str.length > 20) {
            return str.substring(0, 20) + '...'; // Truncate to 20 characters, then add '...'
        }
        return str; // Return the original string if it's 20 characters or less
    }


    return (
        <div className="grid px-5 pt-4 relative grid-cols-4 w-[528px] min-h-[313px] rounded-md border">
            {deleteConfirmationModal && <ExpertRejectSessionPopUp
                heading="Are you sure you want to delete this child"
                onConfirm={() => {
                    dispatch(deleteChildById(childData.id)).then(() => {
                        dispatch(fetchChildren())
                    })
                    setDeleteConfirmationModal(false)
                }}
                onCancel={() => setDeleteConfirmationModal(false)}
            />}
            {gender.toLowerCase() === "female" && <img src={childGirl} alt="" className="mt-5"/>}
            {gender.toLowerCase() === "male" && <img src={childBoy} alt="" className="mt-4" />}
            <div className="flex flex-col gap-5">
                <h1 className="mt-4 text-nowrap text-[24px] font-medium text-platinumText">{name}</h1>
                <div className="grid grid-cols-2 gap-4  w-[227px]">
                    <p className="text-[16px] text-graymod-texttwo">Date of Birth</p>
                    <h3 className="text-[16px] text-nowrap">{convertUTCtoLocalDateTime(dob).format('MMMM D, YYYY')}</h3>
                </div>
                <div className="grid grid-cols-2 gap-4 w-[227px]">
                    <p className="text-[16px] text-graymod-texttwo">Gender</p>
                    <h3 className="text-[16px]">{gender}</h3>
                </div>
                <div className="grid grid-cols-2 gap-4 w-[227px]">
                    <p className="text-[16px] text-graymod-texttwo">School</p>
                    {isEdit ? <div>
                        <div className="relative w-[225px] max-h-[25px]">
                            <ComboBox
                                selectedItem={childData?.school}
                                suggestions={companies}
                                onSelect={handleCompanySelection}
                                className="h-[23px]"
                                onChange={(data: any) => dispatch(childUpdater({ ...childData, school: data }))}
                            />
                        </div>
                    </div>

                        :
                        <h3 className="text-nowrap text-[16px] ">{truncateString(school)}</h3>}
                </div>
                <div className="grid grid-cols-2 gap-4 w-[227px]">
                    <p className="text-[16px] text-graymod-texttwo">Grade</p>
                    {isEdit ? <Input onChange={(e) => {
                        dispatch(gradeUpdater(e.target.value))
                    }}
                        value={childData?.grade}
                        className="h-[22px] w-[225px]" />
                        :
                        <h3 className="text-[16px] ">{grade}</h3>}
                </div>
            </div>
            {isEdit && <div className="flex gap-3 scale-75 text-[20px] absolute bottom-4 right-3">
                <Button
                    onClick={() => setIsEdit(false)}
                    variant={"outline"}>Cancel</Button>
                <Button onClick={() => {
                    dispatch(updateChildren(childData)).then(() => {
                        dispatch(fetchChildren())
                    })
                    setIsEdit(false)
                }}
                    className="">Save</Button>
            </div>

            }
            {isEdit ? <Trash2 className="cursor-pointer text-graymod-texttwo absolute h-10 right-4 top-4 " onClick={() => {
                setDeleteConfirmationModal(true)
                dispatch(gradeUpdater(""))
                dispatch(schoolUpdater(""))
            }} /> : <img onClick={() => {
                setIsEdit(true)
                onClick()
            }}
                className="absolute right-4 top-4 cursor-pointer" src={editPencil} alt=""
            />}
        </div>
    )
}



const GoogleCalendarStatus: React.FC<GoogleCalendarProps> = ({ email, toggleValue, status, className, onchange }) => {
    return (
        <span>
            <div className={`${className} flex justify-between items-center border-b text-[14px] text-[#515151] border-[#dddddd] py-3`}>
                {status && <>
                    <p className="italic">{email}</p>
                    <div className="flex gap-3 items-center">
                        <span>Connected</span>
                        <MoreHorizIcon className="rotate-90 cursor-pointer hover:bg-gray-100 rounded-[50%]" />
                    </div>
                </>}
            </div>
            <div className="flex items-center justify-between py-3 pt-10">
                <p className="text-[14px] text-[#515151]">Automatically add my sessions to Google Calendar</p>
                <Switch onCheckedChange={onchange} checked={toggleValue} />
            </div>
        </span>
    );
};



const RenderSection: React.FC<any> = ({ section }) => {
    const dispatch: any = useDispatch()
    const profilePicSelector = useSelector((state: RootState) => state.profilePic.profilePicture);
    const learnerDataSelector = useSelector((state: RootState) => state.LearnerSetting.learnerDetails);
    const childrenSelector = useSelector((state: RootState) => state.LearnerSetting.children);
    const childData = useSelector((state: RootState) => state.LearnerSetting.child);
    // const [otpVerificationModalIsOpen, setOtpVerificationModalIsOpen] = useState(false);
    // const [phoneNumber, setPhoneNumber] = useState<string>("");
    // const [countryCode, setCountryCode] = useState<string>("");
    // const [isPhoneEdit, setIsPhoneEdit] = useState<boolean>(false);
    const [isProfileEdit, setIsProfileEdit] = useState<boolean>(false);
    const [isLinkedinEdit, setIsLinkedinEdit] = useState<boolean>(false);
    const [isAddChildPopUp, setIsAddChildPopUp] = useState<boolean>(false)


    useEffect(() => {
        dispatch(fetchChildren())
        dispatch(fetchCompanies())
    }, [])

    const handlePostProfilePic = (e: any) => {
        dispatch(postProfilePicture(e)).then(() => {
            window.location.reload();
        });
    };


    // const handleOtpGeneration = () => {
    //     dispatch(generateOtp({ countryCode, phoneNumber}))
    //     .then(() => openOtpVerificationModal());
    // };

    // const openOtpVerificationModal = () => {
    //     setOtpVerificationModalIsOpen(true);
    // };

    // const closeOtpVerificationModal = () => {
    //     setOtpVerificationModalIsOpen(false);
    //     setIsPhoneEdit(false);
    // };


    // const handleChange = (
    //     e: string | undefined,
    //     value: CountryData | undefined,
    //     name: string
    // ) => {
    //     if (name === "phoneNumber" && e && value) {
    //         let splitMobile = e.split(value?.dialCode || "");
    //         setCountryCode(value?.dialCode || "");
    //         setPhoneNumber(splitMobile[1] || "");
    //     }
    // };

    const showCtas = () => {
        return isProfileEdit || isLinkedinEdit;
    }

    switch (section) {
        case "Personal_Information":
            return (
                <div className="bg-white p-10 w-[886px] grid grid-cols-3 border rounded-lg mt-12">
                    {/* {otpVerificationModalIsOpen && (
                        <OtpVerificationModal
                            phoneNumber={phoneNumber}
                            countryCode={countryCode}
                            isOpen={otpVerificationModalIsOpen}
                            onClose={closeOtpVerificationModal}
                            onValidationSuccess={closeOtpVerificationModal}
                        />
                    )} */}
                    <div className="h-[190px] w-[190px] rounded-[50%]  relative">
                        <div className="absolute cursor-pointer w-[28px] bottom-0 right-6 image-upload">
                            <label htmlFor="file-input">
                                <img className="cursor-pointer" src={camera} alt="Upload" />
                            </label>
                            <input
                                id="file-input"
                                type="file"
                                style={{ display: 'none' }}
                                onChange={handlePostProfilePic}
                            />
                        </div>
                        <img className="profilepic rounded-[50%] object-cover object-center h-[190px] w-[190px]" src={profilePicSelector === null ? user : profilePicSelector} alt="" />
                    </div>
                    <div className="col-span-2">
                        <div className="flex flex-col gap-7">
                            <DetailField
                                field2={"lastName"}
                                data={learnerDataSelector}
                                field={"firstName"}
                                fieldName={"Full Name"}
                            />
                            <DetailField
                                data={learnerDataSelector}
                                field={"email"}
                                fieldName={"Email"}
                            />
                            <DetailField
                                data={learnerDataSelector}
                                field={"dob"}
                                fieldName={"Date of Birth"}
                            />
                            <DetailField
                                data={learnerDataSelector}
                                field={"gender"}
                                fieldName={"Gender"}
                            />
                            {isProfileEdit ? <ProfileEdit
                                fieldName={"Learner Profile"}
                            /> :
                                <DetailFieldEdit
                                    data={learnerDataSelector}
                                    field={"learnerProfile"}
                                    fieldName={"Learner Profile"}
                                    onEdit={() => setIsProfileEdit(true)}
                                />
                            }


                            {/* {isPhoneEdit ?
                                <div>
                                    <div className="relative grid grid-cols-2 w-[35vw]">
                                        <h3 className="text-[16px] text-platinumText">Phone Number</h3>
                                        <div className="flex flex-col justify-end w-[225px] gap-2">
                                            <PhoneInput
                                                country={"in"}
                                                value={`${countryCode}${phoneNumber}`}
                                                onChange={(e, phone) =>
                                                    handleChange(e, phone as CountryData, "phoneNumber")
                                                }
                                                inputStyle={{
                                                    border: "1px solid #DDDDDD",
                                                    fontSize: "16px",
                                                    width: "225px",
                                                    height: "25px",
                                                    borderRadius: "8px",
                                                    outline: "none",
                                                }}
                                                inputProps={{
                                                    required: true,
                                                }}
                                            />
                                            <div className="flex gap-3 justify-end">
                                            <Button
                                                variant={"outline"}
                                                className=" text-[14px] w-[80px]"
                                                size={"vsm"}
                                                onClick={() => {
                                                    setIsPhoneEdit(false);
                                                }}
                                                disabled={false}
                                            >
                                                Cancel
                                            </Button>
                                            <Button
                                                className=" text-[14px] w-[80px]"
                                                size={"vsm"}
                                                onClick={() => {
                                                    handleOtpGeneration()
                                                }}
                                                disabled={false}
                                            >
                                                Get OTP
                                            </Button>
                                            </div>
                                        </div>
                                    </div>
                                </div> :
                                <DetailFieldEdit
                                    data={learnerDataSelector}
                                    field={"phoneNumber"}
                                    fieldName={"Phone Number"}
                                    onEdit={() => setIsPhoneEdit(true)}
                                />
                            } */}

                            {learnerDataSelector.linkedInProfileLink && <div>
                                {isLinkedinEdit ?
                                    <div className="">
                                        <div className="relative grid grid-cols-2 w-[35vw]">
                                            <h3 className="text-[16px] text-platinumText">Linkedin</h3>
                                            <Input onChange={(e) => {
                                                dispatch(learnerUpdater({ ...learnerDataSelector, linkedInProfileLink: e.target.value }))
                                            }} className="h-[23px] w-[202px] rounded-sm" />
                                        </div>
                                    </div>
                                    :
                                    <DetailFieldEdit
                                        data={learnerDataSelector}
                                        field={"linkedInProfileLink"}
                                        fieldName={"Linkedin"}
                                        onEdit={() => { setIsLinkedinEdit(true) }}
                                    />
                                }
                            </div>}
                        </div>
                        {showCtas() ? <div className="flex gap-3 justify-end mt-7">
                            <Button
                                variant={"outline"}
                                onClick={() => {
                                    setIsProfileEdit(false)
                                    setIsLinkedinEdit(false)
                                }}>Cancel</Button>
                            <Button onClick={() => {
                                setIsProfileEdit(false)
                                setIsLinkedinEdit(false)
                                dispatch(updateLearnerSettings(learnerDataSelector)).then(() => {
                                    dispatch(fetchLearnerSettings())
                                })
                            }}>Save</Button>
                        </div> : ""}
                    </div>
                </div>
            );

        case "Children_Information":
            return (
                <div className="h-full overflow-y-auto flex flex-col gap-5">
                    {isAddChildPopUp &&
                        <div className="h-screen w-screen fixed top-0 left-0 bg-black/30 z-50">
                            <AddChildPopUp onSubmit={() => {
                                dispatch(addChildren(childData)).then(() => {
                                    dispatch(fetchChildren())
                                })
                                setIsAddChildPopUp(false)
                            }} onClose={() => setIsAddChildPopUp(false)} />
                        </div>
                    }
                    {childrenSelector?.map((data: any) => (
                        <ChildCard
                            name={data.name}
                            key={data.id}
                            gender={data.gender}
                            grade={data.grade}
                            school={data.school}
                            dob={data.dob}
                            onClick={() => dispatch(childUpdater(data))}
                        />
                    ))}
                    <div className="flex justify-between w-[500px] ml-3 mt-5">
                        <h2 className="font-normal text-[16px]">
                        Add Child Information
                        </h2>
                        <Button
                                    variant={'ghost'}
                                    onClick={() => setIsAddChildPopUp(true)}
                        >
                        <img
                            src={add}
                            alt="Add info"
                            className="w-[25px] h-[auto]"
                        />
                        </Button>
                    </div>
                </div>
            );

        default:
            return null;
    }
};




const PersonalContent: React.FC<{ section: string, handleSectionChange: (section: string) => void }> = ({ section, handleSectionChange }) => {
    const dispatch: any = useDispatch();
    const learnerDataSelector = useSelector((state: RootState) => state.LearnerSetting.learnerDetails);

    useEffect(() => {
        dispatch(fetchProfilePicture());
        handleSectionChange("Personal_Information")
    }, []);

    return (
        <div className="flex-1 p-8">
            <div className="flex mb-4 w-full">
                <HeadingButton
                    value={section}
                    heading={"Personal Information"}
                    onClick={() => handleSectionChange("Personal_Information")}
                /> 
                {learnerDataSelector?.learnerProfile === LearnerProfileType.PARENT && <HeadingButton
                    value={section}
                    heading={"Children Information"}
                    onClick={() => handleSectionChange("Children_Information")}
                />}
                <div className="border-b-4 w-96 border-graymod"></div>
                {learnerDataSelector.learnerProfile !== LearnerProfileType.PARENT && <div className="border-b-4 w-64 border-graymod"></div>}
            </div>
            <RenderSection section={section} />

        </div>
    );
};



const HeadingButton: React.FC<any> = ({ value, heading, onClick }) => {
    const normalize = (str: string) => str.replace(/_/g, ' ').toLowerCase();
    const isActive = normalize(value) === normalize(heading);
    const learnerData = useSelector((state: RootState) => state.LearnerSetting.learnerDetails)
    return (
        <div
            onClick={onClick}
            className={`w-[248px] flex items-center justify-center cursor-pointer ${learnerData?.learnerProfile !== LearnerProfileType.PARENT && "text-[#515151] border-graymod"} font-medium text-[20px] pb-2 transition-all duration-100 ${isActive ? learnerData?.learnerProfile === LearnerProfileType.PARENT && "border-cyanmod text-cyanmod" : "text-graymod-textfour border-graymod"} border-b-4`}
        >
            {heading}
        </div>
    );
};



function LearnerSettingsPage() {
    const [personalSection, setPersonalSection] = useState("details");
    const [raiseATicketFlag, setRaiseATicketFlag] = useState<boolean>(false);
    const [toggleChange, setToggleChange] = useState<boolean>(false);
    const dispatch: any = useDispatch();
    const personalDetails = useSelector((state: RootState) => state.profilePic.userData);
    const isCalendarConnected = useSelector((state: RootState) => state.googleCalender.isConnected);
    const toggleSelector = useSelector((state: RootState) => state.googleCalender.toogle);
    const location = useLocation();
    const [externalPopup, setExternalPopup] = useState<Window | null>(null);

    useEffect(() => {
        dispatch(checkIntegration());
        dispatch(fetchLearnerSettings());
    }, [dispatch]);

    useEffect(() => {
        dispatch(googleCalendarConnectedStatus());
    }, [dispatch, toggleChange]);

    
    const autosaveUpdate = (status: boolean) => {
        dispatch(calendarAutoSaveStatusUpdate(status));
    };

    useEffect(() => {
        if (!externalPopup) {
          return;
        }
    
        const timer = setInterval(async () => {
          if (!externalPopup) {
            timer && clearInterval(timer);
            return;
          }
          const currentUrl = externalPopup.location.href;
          if (!currentUrl) {
            return;
          }
          const searchParams = new URL(currentUrl).searchParams;
          const code = searchParams.get("code");
          if (code) {
            externalPopup.close();
            await dispatch(calendarCallback({ code }));
            setExternalPopup(null);
            timer && clearInterval(timer);
          }
        }, 500);
      }, [externalPopup]);

    const connectClick = (iframeUrl: string) => {
        const width = 500;
        const height = 600;
        const left = window.screenX + (window.outerWidth - width) / 2;
        const top = window.screenY + (window.outerHeight - height) / 2.5;
        const title = `WINDOW TITLE`;
        const url = iframeUrl;
        const popup = window.open(
          url,
          title,
          `width=${width},height=${height},left=${left},top=${top}`
        );
        setExternalPopup(popup);
      };


    const getMenuItemContent = () => {
        switch (location.hash) {
            case "#personal":
                return <PersonalContent section={personalSection} handleSectionChange={setPersonalSection} />;

            case "#calendar":
                return (
                    <div className="px-8 pr-[10vw] py-8">
                        <PageHeading title="Calendar"/>
                        {!isCalendarConnected && (
                  <p className="text-[#515151] text-[16px] mt-20">
                    Get connected to see all your assigned sessions in Google
                    Calendar.
                  </p>
                )}
                {!isCalendarConnected ? (
                  <div
                    onClick={async () => {
                      const result = await dispatch(
                        calendarAuthorization()
                      ).unwrap();

                      connectClick(result);
                    }}
                    className="w-[298px] h-[53px] border border-[#E1E1E1] cursor-pointer hover:bg-gray-100 rounded-lg flex items-center justify-around mt-5"
                  >
                    <img src={googleCalender} alt="" />
                    <span className="text-[16px] font-medium text-[#515151]">
                      Connect to Google Calendar
                    </span>
                  </div>
                ) : (
                  <div className="flex mt-[2rem]">
                    <img
                      src={googleCalender}
                      alt=""
                      className="w-[3rem] h-[3rem]"
                    />
                    <div className="ml-[14px]">
                      <span>Google Calendar</span>
                      <p className="text-[12px]">
                        All your assigned sessions are now added to your Google
                        Calendar
                      </p>
                    </div>
                  </div>
                )}
                {
                  <GoogleCalendarStatus
                    toggleValue={toggleSelector}
                    email={
                      personalDetails === null ? "" : personalDetails.email
                    }
                    status={isCalendarConnected}
                    onchange={(e: boolean) => {
                      autosaveUpdate(e);
                      setToggleChange((prev) => !prev);
                    }}
                    className="mt-12"
                  />
                }
                    </div>
                );

            default:
                return <PersonalContent section={personalSection} handleSectionChange={setPersonalSection} />;
        }
    };

    return (
        <div className="flex">
            {raiseATicketFlag && <AskaQuestionModal onClose={() => setRaiseATicketFlag(false)} concern="Modify Bank Account Details" />}

            <LearnerSettingsMenu/>
            <div className="flex-1 p-8">
                {getMenuItemContent()}
            </div>
        </div>
    );
}

export default LearnerSettingsPage;