import { useEffect } from 'react';
import userIconSvg from '../../assets/user-icon.svg';
import './PendingPaymentPage.css'
import calender from "../../assets/calender.svg"
import clock from "../../assets/clocksvg.svg"
import { Button } from '@/shadcn/ui/button';
import moment from 'moment';
import { AppDispatch, RootState } from '@/Redux/store/store';
import { useDispatch, useSelector } from 'react-redux';
import { fetchPaymentDetails, SessionPendingPaymentDetails } from '@/Redux/slices/PaymentDetails';
import PageHeading from '@/Components/PageHeadings';


function PendingPaymentPage() {
    const dispatch: AppDispatch = useDispatch();
    const pendingPaymentsData = useSelector((state: RootState) => state.paymentDetails.pendingPaymentDetails);

    function convertUTCtoLocalDateTime(utcDateTime: string): any {
        let localTime = moment.utc(utcDateTime).toDate();
        const local = moment(localTime)
        return local
    }

    useEffect(() => { 
        dispatch(fetchPaymentDetails());
    }, [])

    return (
        <div className="flex-1 p-8 mx-10 my-6">
            <PageHeading title = "Pending Payments" />
          {pendingPaymentsData.totalPayment ? (
            <div>
                <div className="total-dues-info rounded-md flex justify-between py-3 px-5 items-center mb-8">
                    <p className="text-[18px]">Total Dues: <b>₹{pendingPaymentsData.totalPayment}</b></p>
                    <Button>Clear Dues</Button>
                </div>

                <div className="grid grid-cols-3 gap-10"> 
                    {pendingPaymentsData.pendingPayments.map((data: SessionPendingPaymentDetails, index: number) => (
                        <div key={index} className="p-5 border rounded-sm bg-white flex flex-col gap-8 border-2">
                            <h2 className="mb-3 text-[24px] font-bold text-lg text-[#656565]">{data.title}</h2>
                            <div className="flex gap-4 items-center">
                                <span><img src={userIconSvg} alt="User" /></span>
                                <span className='text-[18px] text-[#949494]'>{data.expertName}</span>
                            </div>
                            <div className="flex items-center gap-4">
                                <span><img src={calender} alt="Calendar" /></span>
                                <span className='text-[18px] text-[#949494]'>{(convertUTCtoLocalDateTime(data.sessionDate).format('D MMM,  YYYY'))}</span>
                            </div>
                            <div className="flex items-center gap-4">
                                <span><img src={clock} alt="Clock" /></span>
                                <span className='text-[18px] text-[#949494]'>{(convertUTCtoLocalDateTime(data.sessionDate).format('hh:mm a'))}</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <div className='text-[18px] text-[#656565]'>Amount due: </div>
                                <div className='text-[20px] text-[#656565]'>₹{data.amountDue}</div>
                            </div>
                        </div>
                    ))}

                </div>  
                </div> ) : <div className="border border-graymod-one py-44 bg-white">
        <h1 className="font-medium text-[36px] text-center text-[#515151]">
          No Dues Pending!
        </h1>
        </div>}       
        </div>

    );
}

export default PendingPaymentPage;
