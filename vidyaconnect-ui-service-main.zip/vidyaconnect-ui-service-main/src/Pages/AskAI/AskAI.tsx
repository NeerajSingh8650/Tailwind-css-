import comingSoonImg from "../../assets/coming_soon.jpg"

const AskAI = () => {

    return (<div className="flex justify-center">
        <img src={comingSoonImg} alt="Coming Soon!" className="max-h-[550px]"/>
    </div>)

}

export default AskAI;