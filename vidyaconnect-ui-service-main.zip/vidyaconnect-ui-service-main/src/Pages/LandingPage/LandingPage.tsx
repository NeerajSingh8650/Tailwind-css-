import SwitchTabs from "./SwitchTabs";
import WhySagenest from "./WhySagenest";
import ExpertSection from "./ExpertSection";
import LearnerSection from "./LearnerSection";
import SliderSection from "./SliderSection";
import { useDispatch, useSelector } from "react-redux";
import { AppDispatch, RootState } from "@/Redux/store/store";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { PROFILE } from "@/constants";
import SuccessfullyResetPasswordModal from "@/Components/SuccessfullyResetPasswordModal/SuccessfullyResetPasswordModal";
import { setisSuccessPasswordModal } from "@/Redux/slices/authSlice";
import ResetPasswordModal from "@/Components/ForgotPasswordModal/ResetPasswordModal";
import PasswordModal from "@/Components/PasswordModal/PasswordModal";

interface Props {
  showPasswordModal: boolean;
}

const LandingPage: React.FC<Props> = ({showPasswordModal}) => {

  const isFogotPasswordModal = useSelector(
    (state: RootState) => state.auth.isResetPasswordModal
  );
  const isSuccessPasswordModal = useSelector(
    (state: RootState) => state.auth.isSuccessPasswordModal
  );
  const dispatch: AppDispatch = useDispatch();
  const navigate = useNavigate();

  const { userDetails } = useSelector((state: RootState) => state.user);
  const isLoggedIn = JSON.parse(sessionStorage?.isLoggedIn || false);

  useEffect(() => {
    if (isLoggedIn && userDetails?.onboardingCompleted) {
      navigate(
        `/dashboard/${
          userDetails?.profile?.toLowerCase() === PROFILE.LEARNER
            ? "learner-portal"
            : "expert"
        }-home`
      );
    }
  }, [userDetails]);

  useEffect(() => {
    const handlePopState = (_event: PopStateEvent) => {
      history.pushState(null, document.title, window.location.href);
    };
    history.pushState(null, document.title, window.location.href);
    window.addEventListener("popstate", handlePopState);
    return () => {
      window.removeEventListener("popstate", handlePopState);
    };
  }, []);

  
  return (
    <div className="relative">
      {isSuccessPasswordModal && (
        <SuccessfullyResetPasswordModal
          onClose={() => dispatch(setisSuccessPasswordModal(false))}
        />
      )}
      {isFogotPasswordModal && (
        <ResetPasswordModal
          onSignIn={() => {}}
          onClose={() => {}}
          showResetPasswordModal={() => true}
        />
      )}
      {showPasswordModal && (
        <PasswordModal onSignIn={() => {}} onClose={() => {}} />
      )}

      <div className="flex-1 tabs-section">
        <div className="max-w-[100%] m-[auto]">
          <SwitchTabs />
        </div></div>

      <div className="flex-1 whysagenest-section relative">
        <div className="max-w-[1170px] m-[auto] md:pt-20 pt-10 pb-16 z-20 relative mx-auto">
          <WhySagenest />
        </div>
      </div>

      <>
        <div className="flex-1 bg-[#F2FBFE] expert-section">
          <div className=" pt-20 pb-16 max-w-[1170px] m-[auto] mx-auto">
            <ExpertSection />
          </div>
        </div>

        <div className="flex-1 bg-[#FFFFFF] learner-section">
          <div className="pt-20 pb-[120px] max-w-[1170px] m-[auto] mx-auto">
            <LearnerSection />
          </div>
        </div>
      </>


      <div className="flex-1 bg-[#F2FBFE] slider-section mb-10">
        <div className="max-w-[1170px] m-[auto]">
          <SliderSection />
        </div>
      </div>

    </div>
  );
};

export default LandingPage;
