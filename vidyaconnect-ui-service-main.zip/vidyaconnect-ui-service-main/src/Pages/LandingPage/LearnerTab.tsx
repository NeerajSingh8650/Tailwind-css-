
import Card from "./TabsCard";
import { Button } from "@/shadcn/ui/button"; 
import { useRef, useEffect } from 'react'
import expertthumb from "../../assets/verified-expert.jpg";
import expertthumb2 from "../../assets/personalize-learning.jpg";
import expertthumb3 from "../../assets/diverse-learning.jpg";
import expertthumb4 from "../../assets/explore-sessions.jpg";
import SwitchTabs from "./SwitchTabs";
import SliderSection from "./SliderSection";
import WhySagenest from "./WhySagenest";
import { useDispatch } from "react-redux";
import { AppDispatch } from "@/Redux/store/store";
import { setIsSignUpModal } from "@/Redux/slices/authSlice";
 

const LearnerTab = () => {

    const headerRef = useRef<HTMLDivElement>(null);
    const dispatch: AppDispatch = useDispatch();

    useEffect(() => {
        if (headerRef.current) {
            headerRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, []);

    const cards = [
        {
            image: expertthumb,
            title: "Verified Expertise",
            description: "Learn from the best with our carefully vetted experts."
        },
        {
            image: expertthumb2,
            title: "Personalized Learning",
            description: "Get one-on-one sessions tailored to your needs and goals."
        },
        {
            image: expertthumb3,
            title: "Diverse Learning Opportunities",
            description: `<ul className="list-[upper-roman]">
            <li className="list-[upper-roman]"><strong>Professional Skills:</strong> Leadership, Project Management, GenAI, Astrology, Stock Market.</li>
            <li><strong>Consultation:</strong> Business Strategy, Legal, Financial, Marketing, Sales and more</li>
            <li><strong>Academics:</strong> Math, science, literature, languages and more.</li>
            <li><strong>Personal Development:</strong>  Yoga, Meditation, Public Speaking & Communication.</li>
            <li><strong>Hobbies:</strong> Embroidery, Music Lessons.</li></ul>`
        },
        {
            image: expertthumb4,
            title: "Explore and Schedule Sessions",
            description: "Connect with experts worldwide at flexible times that suit your schedule."
        } 
    ];

    return (
        <div className="relative">
            <SwitchTabs/>
            <div className="text-center pt-16" ref={headerRef}>
                <h1 className="text-2xl md:text-[36px] font-medium leading-10 text-[#022834] mb-2">
                    Achieve your goals with trusted experts
                </h1>
                <p className="tracking-wide text-[#030303] font-normal md:text-[20px] px-4 lg:px-0">
                    Access personalized guidance and quality learning experiences.
                </p> </div>

             <div className="relative">

                {cards.map((card, index) => (
                    <Card
                        key={index}
                        cardImage={card.image}
                        title={card.title}
                        description={card.description}
                        imageRight={index % 2 === 0 ? true : false}
                    />
                ))}

            </div>

            <div className="text-center pt-10 pb-5">
            <Button size="lg" variant="default" onClick={() => dispatch(setIsSignUpModal(true))}>Talk To An Expert Today</Button>
            </div>

            <div className="flex-1 whysagenest-section relative">
                <div className="max-w-[1170px] m-[auto] md:pt-20 pt-10 pb-16 z-20 relative mx-auto">
                    <WhySagenest />
                </div>
            </div>

            <div className="flex-1 bg-[#F2FBFE] slider-section mb-10">
                <div className="max-w-[1170px] m-[auto]">
                    <SliderSection />
                </div>
            </div>
   
       
        </div>

    );
};

export default LearnerTab;
