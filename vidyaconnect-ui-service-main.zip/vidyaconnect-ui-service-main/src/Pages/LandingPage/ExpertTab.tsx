
import Card from "./TabsCard";
import expertthumb1 from "../../assets/monetize-knowledge.jpg";
import expertthumb2 from "../../assets/quick-onboarding.jpg";
import expertthumb3 from "../../assets/build-reputation.jpg";
import expertthumb4 from "../../assets/deliver-sessions.jpg";
import expertthumb5 from "../../assets/supportive-community.jpg";
import { Button } from "@/shadcn/ui/button";

import SliderSection from "./SliderSection";
import WhySagenest from "./WhySagenest";
import SwitchTabs from "./SwitchTabs";
import { useEffect, useRef } from "react";
import { useDispatch } from "react-redux";
import { AppDispatch } from "@/Redux/store/store";
import { setIsSignUpModal } from "@/Redux/slices/authSlice";


const ExpertTab = () => {

    const headerRef = useRef<HTMLDivElement>(null);
    const dispatch: AppDispatch = useDispatch();

    useEffect(() => {
        if (headerRef.current) {
            headerRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, []);

    const cards = [
        {
            image: expertthumb1,
            title: "Monetize Your Knowledge",
            description: "Monetize your knowledge through consultations, courses, and more."
        },
        {
            image: expertthumb2,
            title: "Quick and Easy Onboarding ",
            description: "Begin sharing your expertise with an easy and streamlined onboarding process."
        },
        {
            image: expertthumb3,
            title: "Build Your Reputation",
            description: "Showcase your expertise and gain recognition in your field."
        },
        {
            image: expertthumb4,
            title: "Deliver Sessions; Anytime, Anywhere",
            description: "Provide guidance globally at your convenience."
        },
        {
            image: expertthumb5,
            title: "Supportive Community",
            description: "Connect with other experts and expand your professional network."
        }
    ];

    return (

        <div className="relative">
            <SwitchTabs />
            <div className="text-center pt-16" ref={headerRef}>
                <h1 className="text-2xl md:text-[36px] font-medium leading-10 text-[#022834] mb-2">
                    Elevate Your Impact and Grow Your Influence
                </h1>
                <p className="tracking-wide text-[#030303] font-normal md:text-[20px] px-4 lg:px-0">
                    Join a global community of professionals dedicated to excellence.
                </p> </div>


            <div className="relative">

                {cards.map((card, index) => (
                    <Card
                        key={index}
                        cardImage={card.image}
                        title={card.title}
                        description={card.description}
                        imageRight={index % 2 === 0 ? true : false}
                    />
                ))}


            </div>

            <div className="text-center pt-10 pb-5">
                <Button size="lg" variant="default" onClick={() => dispatch(setIsSignUpModal(true))}>Register Now For Free</Button></div>

            <div className="flex-1 whysagenest-section relative">
                <div className="max-w-[1170px] m-[auto] md:pt-20 pt-10 pb-16 z-20 relative mx-auto">
                    <WhySagenest />
                </div>
            </div>

            <div className="flex-1 bg-[#F2FBFE] slider-section mb-10">
                <div className="max-w-[1170px] m-[auto]">
                    <SliderSection />
                </div>
            </div>

        </div>

    );
};

export default ExpertTab;
