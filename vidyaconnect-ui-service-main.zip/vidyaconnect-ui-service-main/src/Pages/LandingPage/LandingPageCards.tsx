interface Props {
    variant: string;
    cardImage: string;
    cardCountIcon: string | null;
    title: string;
    description: string;
}

const Card: React.FC<Props> = ({ variant, cardImage, cardCountIcon, title, description }) => {

    if (!title) {
        return <div />
    }
    // Conditionally render based on the variant prop
    if (variant === 'dark') {
        return (
            <div className="why-bg-image min-h-[316px] md:min-h-[395px] width-[100%] min-w-[none] md:min-w-[380px]  bg-[#022834] rounded-lg overflow-hidden py-8 px-5 border-[#1CA6D4] border-b-[5px]">
                <div className="flex justify-between">
                    <img className="" src={cardImage} alt={title} />
                    {cardCountIcon && <img className="" src={cardCountIcon} alt={title} />}
                </div>

                <div className="mt-4">
                    <div className="font-bold text-xl mb-5 md:text-[22px] text-[#ffffff]">
                        {title}
                    </div>
                    <p className="text-base md:text-[16px] text-[#CAD2D5]">
                        {description}
                    </p>
                </div>
            </div>
        );
    }

    // Default to light variant if no match
    return (
        <div className="text-center min-h-[275px] width-[100%] max-w-[80%] md:max-w-[285px] rounded-lg overflow-hidden bg-[#EEF5F8] mb-2 md:mb-0">
            <div className="rounded-lg">
                <img className="w-[380px] h-[180px] object-cover" src={cardImage} alt={title} />
            </div>

            <div className="mt-4 flex flex-col items-center px-2">
                <div className="font-bold text-xl md:text-[22px] text-[#022834] flex items-center min-h-[70px]">
                    {title}
                </div>
                <p className="text-base md:text-[16px] text-[#022834] pb-4">
                    {description}
                </p>
            </div>
        </div>
    );
};

export default Card;
