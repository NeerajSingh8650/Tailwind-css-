interface Props {
    title: string;
    description: string;
    cardImage: string;
    imageRight: boolean;
}

const Card: React.FC<Props> = ({ title, description, cardImage, imageRight }) => {
    // Conditionally render based on the variant prop

    return (
        <div className="flex md:flex-row flex-col bg-[#F2FBFE] rounded-lg max-w-[1010px] m-[auto] my-12 md:text-left text-center special-item-outer">

        {/* For screens where imageRight is false */}
        { !imageRight &&
        <>
            <div className="md:basis-[40%] sm:basis-[100%] basis-[50%] max-w-[100%] special-item md:order-1 order-2">
                <img className="w-[442px] h-[295px] object-cover mx-auto" src={cardImage} alt={title} />
            </div>
            <div className="md:basis-[60%] sm:basis-[100%] basis-[50%] flex flex-col justify-center px-10 py-4 md:order-2 order-1">
                <h4 className="font-medium text-xl mb-3 md:text-[24px] text-[#2A2A2A]">
                    {title}
                </h4>
                <p className="text-base md:text-[18px] text-[#2A2A2A]">
                   <div dangerouslySetInnerHTML={{__html:  description }} />
                </p>
            </div>
        </>
        }
    
        {/* For screens where imageRight is true */}
        { imageRight &&
        <>
            <div className="md:basis-[60%] sm:basis-[100%] basis-[50%] flex flex-col justify-center px-10 py-4 md:order-1 order-1">
                <h4 className="font-medium text-xl mb-3 md:text-[24px] text-[#2A2A2A]">
                    {title}
                </h4>
                <p className="text-base md:text-[18px] text-[#2A2A2A]">
                   <div dangerouslySetInnerHTML={{__html:  description }} />
                </p>
            </div>
            <div className="md:basis-[40%] sm:basis-[100%] basis-[50%] max-w-[100%] special-item md:order-2 order-2">
                <img className="w-[442px] h-[295px] object-cover mx-auto" src={cardImage} alt={title} />
            </div>
        </>
        }
    
    </div>
    
    );


};

export default Card;
