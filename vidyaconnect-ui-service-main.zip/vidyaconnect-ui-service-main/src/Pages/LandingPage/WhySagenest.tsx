
import cardimage1 from "../../assets/personalized-icon.svg";
import cardimage2 from "../../assets/empowering-icon.svg";
import cardimage3 from "../../assets/flexible-icon.svg";

import cardnumbericon1 from "../../assets/cardcount-icon1.svg";
import cardnumbericon2 from "../../assets/cardcount-icon2.svg";
import cardnumbericon3 from "../../assets/cardcount-icon3.svg";

// import Card from "./WhySageCards";
import Card from "./LandingPageCards";


const WhySagenest = () => {

    const cards = [
        {
          image: cardimage1,
          cardnumber: cardnumbericon1,
          title: "Personalized Learning Journeys",
          description: "SageNest matches learners with experts based on their specific needs, goals, and learning styles, ensuring a truly customized educational experience."
        },
        {
          image: cardimage2,
          cardnumber: cardnumbericon2,
          title: "Empowering Experts",
          description: "Experts can reach a global audience, share their knowledge, and grow their influence, all while earning income on their terms."
        },
        {
          image: cardimage3,
          cardnumber: cardnumbericon3,
          title: "Flexible and Accessible",
          description: "With SageNest, learning and teaching are made accessible and flexible, allowing users to manage their schedules, set goals, and engage in meaningful learning sessions from anywhere in the world."
        }
      ];

    return (
        <div className="relative flex flex-col">
            <div className="text-center">
            <h3 className="text-2xl md:text-[28px] text-[#205C6F] font-bold leading-10 mb-3">
            Why SageNest?
            </h3>
            <h1 className="text-2xl md:text-[45px] font-bold leading-10 text-[#022834] mb-5">
            Revolutionizing Personalized Learning for Everyone
            </h1>
            <p className="max-w-[none] md:max-w-[80%] m-[auto] tracking-wide text-[#5A696D] font-normal md:text-[20px] mb-12 px-4 lg:px-0">
            SageNest empowers individuals by providing personalized learning experiences tailored to their unique needs, goals, and schedules. Whether you are an expert looking to share your knowledge or a learner seeking to acquire new skills, SageNest is your gateway to a world of limitless possibilities.
            </p> 
            <p className="max-w-[none] md:max-w-[60%] m-[auto] tracking-wide text-[#022834] md:text-[16px] font-normal  mb-5 px-4 lg:px-0">
            In a world where one-size-fits-all solutions are no longer effective, SageNest offers a platform designed to cater to the individual. We understand that everyone’s learning journey is different, which is why our platform is built on the principles of personalization, flexibility, and connection.</p> 
           
            <h3 className="text-2xl md:text-[36px] text-[#022834] font-bold leading-10 mt-20 mb-10 h3-before relative">
            How SageNest Improves Lives
            </h3>

           </div> 
            
           <div className="flex justify-center items-center gap-3 md:flex-col flex-col  xl:flex-row px-10 md:px-0">
          
           {cards.map((card, index) => (
                <Card
                variant="dark"
                key={index}
                cardImage={card.image}
                cardCountIcon={card.cardnumber}
                title={card.title}
                description={card.description}
                />
            ))}
                
            </div>

            
        </div>

    );
};

export default WhySagenest;
