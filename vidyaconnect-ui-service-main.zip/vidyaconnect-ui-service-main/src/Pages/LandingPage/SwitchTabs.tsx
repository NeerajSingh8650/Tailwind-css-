import { useLocation, useNavigate } from "react-router-dom";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../Components/ui/tabs"
import { useEffect, useState } from "react";


const SwitchTabs: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [activeTab, setActiveTab] = useState<string>("");

  useEffect(() => {
    const path = location.pathname;
    console.log("path in switch tabs", path)
    if (path.includes('expert-opportunities')) {
      setActiveTab('expert-opp');
    } else if (path.includes('learner-opportunities')) {
      setActiveTab('learner-opp');
    } else {
      setActiveTab("");
    }
  }, [location.pathname]);

  const handleTabChange = (value: string) => {
    setActiveTab(value); 
    if (value === 'expert-opp') {
      navigate("/expert-opportunities");
    } else if (value === 'learner-opp') {
      navigate("/learner-opportunities");
    }
  };

  return (
    <div className="relative">

      <Tabs className="w-full" onValueChange={handleTabChange} value={activeTab}>
        <TabsList>
          <TabsTrigger value="expert-opp" className="border-gray-400"  >Expert Opportunities</TabsTrigger>
          <TabsTrigger value="learner-opp" >Learner Opportunities</TabsTrigger>
        </TabsList>
        {/* #00000063 */}
        <TabsContent value="expert-opp"/>
        <TabsContent value="learner-opp"/>  

      </Tabs>

    </div>

  );
};

export default SwitchTabs;
