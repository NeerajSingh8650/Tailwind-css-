import learnerthumb from "../../assets/verified-expert.jpg";
import learnerthumb2 from "../../assets/personalize-learning.jpg";
import learnerthumb3 from "../../assets/diverse-learning.jpg";
import learnerthumb4 from "../../assets/explore-sessions.jpg";
import { Button } from "@/shadcn/ui/button";
import Card from "./LandingPageCards";
import { useDispatch } from "react-redux";
import { AppDispatch } from "@/Redux/store/store";
import { setIsSignUpModal } from "@/Redux/slices/authSlice";
import { useNavigate } from "react-router-dom";



const LearnerSection = () => {

  const dispatch: AppDispatch = useDispatch();
  const navigate = useNavigate();

  const onClickViewMore = () => {
    navigate("/learner-opportunities");
  }

  const cards = [
    {
      image: learnerthumb,
      title: "Verified Expertise",
      description: ""
    },
    {
      image: learnerthumb2,
      title: "Personalized Learning",
      description: ""
    },
    {
      image: learnerthumb3,
      title: "Diverse Learning Opportunities",
      description: ""
    },
    {
      image: "",
      title: "",
      description: ""
    },
    {
      image: learnerthumb4,
      title: "Explore and Schedule Sessions",
      description: ""
    }

  ];

  return (
    <div className="relative flex flex-col px-5 md:px-0">
      <div className="xl:text-start md:text-center">
        <h3 className="text-2xl md:text-[28px] text-[#205C6F] font-bold leading-10 mb-3">
          For Learners
        </h3>
        <h1 className="text-2xl md:text-[45px] font-bold leading-10 text-[#022834] mb-4">
          Achieve Your Goals with Trusted Experts<br /> and Tailored learning Experience.
        </h1>
        <p className="tracking-wide text-[#5A696D] font-normal md:text-[20px] mb-12">
          Access personalized guidance and quality learning experiences.
        </p>
      </div>


      <div className="flex items-center gap-2 md:flex-wrap flex-nowrap md:flex-row flex-col md:justify-center xl:justify-start">

        {cards.map((card, index) => (
          <Card
            variant="light"
            key={index}
            cardImage={card.image}
            title={card.title}
            description={card.description}
            cardCountIcon={null}
          />
        ))}

        <div className="flex items-center gap-3 flex-wrap justify-center max-w-[100%] m-[auto] pt-10">
          <Button size="fxw" variant="outline" onClick={onClickViewMore}>View More</Button>
          <Button size="fxw" variant="default" onClick={() => dispatch(setIsSignUpModal(true))}>Register Now For Free</Button>
        </div>

      </div>




    </div>

  );
};

export default LearnerSection;
