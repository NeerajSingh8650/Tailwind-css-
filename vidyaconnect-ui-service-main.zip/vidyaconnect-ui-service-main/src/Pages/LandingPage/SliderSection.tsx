import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious, CarouselBullets } from "@/Components/ui/carousel"

 


const SliderSection = () => {

    return (
        <div className="relative px-12 md:px-0 pt-12 pb-12">

<Carousel autoScroll loop>
  <CarouselContent>
  <CarouselItem className="text-center font-normal md:text-[24px] text-[20px] text-[#2A2A2A]">Learning is not a one-size-fits-all process; it should be tailored to each individual's needs. <br/><span className="md:text-[20px] text-[16px]">— Sal Khan</span></CarouselItem>
    <CarouselItem className="text-center font-normal md:text-[24px] text-[20px] text-[#2A2A2A]">Anyone who stops learning is old, whether at twenty or eighty. Anyone who keeps learning stays young. The greatest thing in life is to keep your mind young.<br/><span className="md:text-[20px] text-[16px]">— Henry Ford</span></CarouselItem>
    <CarouselItem className="text-center font-normal md:text-[24px] text-[20px] text-[#2A2A2A]">From sage on the stage to guide on the side <br/><span className="md:text-[20px] text-[16px]">— Alison King</span></CarouselItem>
  </CarouselContent>
  <CarouselPrevious className="md:left-4 xl:-left-8" />
  <CarouselNext className="md:right-2 xl:-right-8" />
  <CarouselBullets />
</Carousel>
            
        </div>

    );
};

export default SliderSection;
