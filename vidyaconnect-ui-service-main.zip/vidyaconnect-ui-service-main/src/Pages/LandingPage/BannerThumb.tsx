import bannerthumbimage from "../../assets/banner-thumbnail-image.svg";


const BannerThumb = () => {

    return (
        <img
        src={bannerthumbimage}
        alt="Unleash your potential"
        className="w-full"
      />
    );
};

export default BannerThumb;
