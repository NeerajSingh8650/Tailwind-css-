import expertthumb1 from "../../assets/monetize-knowledge.jpg";
import expertthumb2 from "../../assets/quick-onboarding.jpg";
import expertthumb3 from "../../assets/build-reputation.jpg";
import expertthumb4 from "../../assets/deliver-sessions.jpg";
import expertthumb5 from "../../assets/supportive-community.jpg";
import { Button } from "@/shadcn/ui/button";

import Card from "./LandingPageCards";

import { useNavigate } from "react-router-dom";
import { setIsSignUpModal } from "@/Redux/slices/authSlice";
import { useDispatch } from "react-redux";
import { AppDispatch } from "@/Redux/store/store";


const ExpertSection = () => {

  const dispatch: AppDispatch = useDispatch();
  const navigate = useNavigate();

  const onClickViewMore = () => {
    navigate("/expert-opportunities");
  }

  const cards = [
    {
      image: expertthumb1,
      title: "Monetize Your Knowledge",
      description: ""
    },
    {
      image: expertthumb2,
      title: "Build Your Reputation",
      description: ""
    },
    {
      image: expertthumb3,
      title: "Quick and Easy Onboarding",
      description: ""
    },
    {
      image: expertthumb4,
      title: "Deliver Sessions; Anytime, Anywhere",
      description: ""
    },
    {
      image: expertthumb5,
      title: "Supportive Community",
      description: ""
    }
  ];

  return (
    <div className="relative flex flex-col px-5 md:px-0">
      <div className="xl:text-start md:text-center">
        <h3 className="text-2xl md:text-[28px] text-[#205C6F] font-bold leading-10 mb-3">
          For Experts
        </h3>
        <h1 className="text-2xl md:text-[45px] font-bold leading-10 text-[#022834] mb-4">
          Elevate Your Impact and Grow<br /> Your Influence
        </h1>
        <p className="tracking-wide text-[#5A696D] font-normal md:text-[20px] mb-12 lg:px-0">
          Share expertise across borders, offering guidance at a global scale.
        </p>


      </div>


      <div className="flex items-center gap-2 md:flex-wrap flex-nowrap md:flex-row flex-col md:justify-center xl:justify-start">

        {cards.map((card, index) => (
          <Card
            variant="light"
            key={index}
            cardImage={card.image}
            title={card.title}
            description={card.description}
            cardCountIcon={null}
          />
        ))}

        <div className="flex items-center gap-4 flex-wrap justify-center max-w-[100%] m-[auto]">
          <Button size="fxw" variant="outline" onClick={onClickViewMore}>View More</Button>
          <Button size="fxw" variant="default" onClick={() => dispatch(setIsSignUpModal(true))}>Register Now For Free</Button>
        </div>
      </div>
    </div>

  );
};

export default ExpertSection;
