import { Button } from "@/shadcn/ui/button";
import BannerThumb from "./BannerThumb";

interface BannerCardProps {
    onGetStarted: () => void;
  }

const BannerCard: React.FC<BannerCardProps> = ({ onGetStarted }) => {

    return (
        <div className="relative flex flex-col-reverse md:flex-row px-5 md:px-0">
            <div className="basis-full md:basis-1/2 text-center pt-8 pt-12">
            <h1 className="text-2xl md:text-[36px] font-bold leading-10 text-white mb-12 text-center">
                Unleash Your Potential:<br/> Discover, Learn, and Excel with<br/> SageNest
            </h1>
            <p className="tracking-wide text-center text-[18px] font-normal md:text-[18px] mb-12 text-white px-4 lg:px-0 uppercase">
                Connect . Learn . Grow
            </p> 
            <Button onClick={onGetStarted} size="lg" variant="default">Get Started Today</Button>
            </div>
            
            <div className="basis-full md:basis-1/2">
            <BannerThumb />
            </div>
            

            
        </div>

    );
};

export default BannerCard;
