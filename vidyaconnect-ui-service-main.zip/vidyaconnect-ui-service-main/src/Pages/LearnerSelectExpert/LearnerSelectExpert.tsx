import "./LearnerSelectExpert.css";
import { FaStar } from "react-icons/fa";
import { useState } from "react";
import LearnerBookSessionsModal from "../../Components/LearnerBookSessionsModal/LearnerBookSessionsModal";
import { IoIosSearch } from "react-icons/io";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../Redux/store/store"
import { bucketUpdate } from "../../Redux/slices/GetLiveHelpSlice";
import { idUpdate } from "../../Redux/slices/ExpertsDataSlice";
import { useNavigate } from "react-router-dom";
import { Button } from "@/shadcn/ui/button";
import RateCardDropdown from "../../Components/RateCardDropDown/RateCardDropDown";
import { getExpetLabelImage, getExpertLabelText, getExpertDefaultUserIcon } from "@/utils/ExpertMembershipUtilities";
import { bookingSessionModalFlagUpdate } from "@/Redux/slices/FlagsSLice";


const LearnerSelectExpert = () => { 
  const navigate = useNavigate()
  
  const expertsData = useSelector((state: RootState) => state.getHelp.expertsData)
  const domainDetails = useSelector((state: RootState) => state.domainData.domain)
  const bookSessionAvailableSlotsModalVisible = useSelector((state: RootState) => state.flags.bookingSessionModalFlag);
  const [bucket, setBucket] = useState<string>('')
  const [searchValue, setSearchValue] = useState<string>('')
  const dispatch = useDispatch()


  const openBookSessionsModal = () => {
    dispatch(bookingSessionModalFlagUpdate(true))
  };
 
  const viewProfileClick = (data: any) => {
    dispatch(idUpdate(data.id))
    dispatch(bucketUpdate(data.bucket))
    const domainId = domainDetails?.id;
    navigate(`/expert/profile/${data.id}`, {state:{domainId}})
  }

  const bookSessionClick = (data: any) => {
    dispatch(idUpdate(data.id))
    dispatch(bucketUpdate(data.bucket))
    openBookSessionsModal()
  }

  const renderStars = (rating: number) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <FaStar
          key={i}
          className={
            i <= rating ? "text-yellow-star w-6 h-6" : "text-graymod-star w-6 h-6"
          }
        />
      );
    }
    return stars;
  };
  return (
    <>
      <h2 className="font-medium text-[25px] lg:text-[30px] mb-10 mt-12 ml-16">
        Select An Expert
      </h2>
      <RateCardDropdown domainName={domainDetails.name} silverPrice={domainDetails.silverBucket} goldPrice={domainDetails.goldBucket} platinumPrice={domainDetails.platinumBucket} />
      {
        (
          <div className="my-12 mx-24">
            <div className="flex mb-8 flex-row items-center">
              <div className="border border-1 h-[35px] border-graymod-border w-[70%] md:w-[40%] lg:w-[20%] flex flex-row justify-evenly rounded-full p-1 pr-3">
                <span>
                  <IoIosSearch
                    className="h-full w-[auto] text-graymod-border"
                  />
                </span>
                <input type="text" onChange={(e) => {
                  setSearchValue(e.target.value)
                  dispatch(bucketUpdate(e.target.value))
                }} className="w-[85%] outline-none ml-3"></input>
              </div>

              <div className="ms-3">
              <select
                  onChange={e => {
                    setBucket(e.target.value.toLowerCase())
                    dispatch(bucketUpdate(e.target.value))
                  }
                  }
                  aria-placeholder="Select an expert"
                  className="border w-[236px] font-light border-graymod font-light text-[16px] py-2 pl-3 rounded-lg outline-none h-[39.06px]"
                  name="cars"
                  id="cars"
                >
                  <option value="" className="font-light absolute top-0 left-9">Select Expert Preference</option>
                  <option className="text-black" value="silver">Silver</option>
                  <option className="text-black" value="gold">Gold</option>
                  <option className="text-black" value="platinum">Platinum</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {expertsData.filter((data) => {
                return searchValue.toString().toLowerCase() === '' ? data : data.name.toLowerCase().includes(searchValue.toLowerCase())
              }).filter((data) => {
                return bucket === "" ? data : data.bucket.toLowerCase() === bucket.toLowerCase()
              }).map((data) =>
                <div
                  key={data.id}
                  className="border border-graymod p-5 rounded-lg"
                >
                  <div className="flex relative items-center gap-4 justify-center">
                    <div className="absolute -top-5 -right-5 flex justify-center items-center">
                      <span className="absolute text-white text-xs">{getExpertLabelText(data.bucket)}</span>
                      <img src={getExpetLabelImage(data.bucket)} alt="" />
                    </div>

                    <img src={data.picUrl ? data.picUrl : getExpertDefaultUserIcon(data.bucket)} className="w-[59px] h-[59px] object-cover rounded-[50%]" />
                    <div className="">
                      <h2 className="text-[20px] font-normal mb-1">
                        {data.name}
                      </h2>
                      <div className="flex justify-between items-center ">
                        <div className="flex justify-between space-x-1 w-20">
                          {renderStars(data.ratings ? data.ratings : 0)}
                        </div>
                        <p className="text-[12px] text-graymod-texttwo ml-3 mt-1 text-nowrap">
                          {data.sessions ? data.sessions : '0'} Sessions
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2 justify-center mt-3">
                    <Button onClick={() => {
                      viewProfileClick(data)
                    }}
                      size={"vsm"}
                      variant="outline"
                    >
                      View Profile
                    </Button>
                    <Button
                      onClick={() => {
                        bookSessionClick(data)
                      }}
                      size={"vsm"}
                    >
                      Book Session
                    </Button>
                  </div>
                </div>
              )}
            </div>

          </div>
        )}
      {bookSessionAvailableSlotsModalVisible && (
        <LearnerBookSessionsModal
          domainId={domainDetails.id}
          openFrom="selectexpert"
        />
      )}
    </>
  );
};

export default LearnerSelectExpert;
