import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { checkOnboardingStatus } from "../../Redux/slices/userSlice";
import { RootState } from "../../Redux/store/store";
import LearnerPersonalInformation from "../LearnerPersonalInformation/LearnerPersonalInformation";
import ExpertPersonalInformation from "../ExpertOnboarding/ExpertOnboarding.tsx";
import { COOKIES, loadCookie } from "../../config/sessionHelper.tsx";
import ConfirmationPage from "../ExpertOnboarding/ConfirmationPage.tsx";
import { updateExpertKyc } from "@/Redux/slices/ExpertSlice.ts";
import ExpertDashboardHomepage from "../Dashboard/ExpertDashboard/ExpertDashboardHomepage/ExpertDashboardHomepage.tsx";

const Onboarding = () => {
  const dispatch: any = useDispatch();
  const { onboardStatus } = useSelector((state: RootState) => state.user);
  const { kycUpdated } = useSelector((state: RootState) => state.expert);
  const userInfo = loadCookie(COOKIES.USER_INFO);

  useEffect(() => {
    dispatch(checkOnboardingStatus());
  }, []);

  if (kycUpdated) {
    return <ConfirmationPage />;
  }
  const profile =
    typeof userInfo?.profile === "string"
      ? userInfo?.profile.toLowerCase()
      : userInfo?.profile[0].toLowerCase();

  if (profile === "learner" && !onboardStatus?.personalInfoCompleted) {
    return <LearnerPersonalInformation />;
  }

  if (profile === "expert") {
    if (onboardStatus?.expertInterviews == "APPROVED" && onboardStatus?.kycStatus == "COMPLETED") {
      return <ExpertDashboardHomepage />
    }
    if (
      ["submitted", "in_progress", "completed"].includes(
        onboardStatus?.kycStatus?.toLowerCase()
      )
    ) {
      return <ConfirmationPage />;
    } else if (
      !onboardStatus.personalInfoCompleted ||
      !onboardStatus?.expertSkillsAdded ||
      !onboardStatus?.expertAvailabilityAdded ||
      !onboardStatus?.expertWorkProfileCompleted
    ) {
      return <ExpertPersonalInformation onboardStatus={onboardStatus} />;
    } else if (onboardStatus?.kycStatus?.toLowerCase() === "not_started") {
      let apiData = {
        kycStatus: "SUBMITTED",
      };
      dispatch(updateExpertKyc(apiData));
      return <ConfirmationPage />;
    }
  }

  return null;
};

export default Onboarding;
