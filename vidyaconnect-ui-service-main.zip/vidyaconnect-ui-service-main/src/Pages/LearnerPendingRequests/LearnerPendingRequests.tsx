import { MdOpenInNew } from "react-icons/md";

const LearnerPendingRequests = () => {
  return (
    <div className="mt-8 mx-16 mb-20">
      <h3 className="text-center text-[48px] font-medium mb-6">
        Pending Requests
      </h3>
      <div className="overflow-x-auto mt-14 mb-20">
        <table className="w-full border-collapse">
          <thead className="text-center">
            <tr>
              <th className="font-medium text-[27px] border-b-2 border-black pb-2">
                Title
              </th>
              <th className="font-medium text-[27px] border-b-2 border-black pb-2">
                Date
              </th>
              <th className="font-medium text-[27px] border-b-2 border-black pb-2">
                Duration
              </th>

              <th className="font-medium text-[27px] border-b-2 border-black pb-2">
                Created On
              </th>
              <th className="font-medium text-[27px] border-b-2 border-black pb-2">
                Status
              </th>
            </tr>
          </thead>
          <tbody className="text-center">
            <tr className="border-b-2 border-black">
              <td className="text-[18.42px] py-6">
                Dynamic programming code walkthrough
              </td>
              <td className="text-[18.42px] py-6 text-center">
                Mon, 29 April ‘24, 13:30
              </td>
              <td className="text-[18.42px] py-6 text-center">1.5 hour</td>
              <td className="text-[18.42px] py-6 text-center">
                Fri, 26 April ‘24, 13:00
              </td>
              <td className="text-[18.42px] py-6">
                <button className="text-[24.07px] bg-graymod-one text-white font-normal px-6 py-2 rounded-lg text-center">
                  Pending
                </button>
              </td>
            </tr>
            <tr className="border-b-2 border-black">
              <td className="text-[18.42px] py-6">French Article Partitif</td>
              <td className="text-[18.42px] py-6 text-center">
                Mon, 22 April ‘24, 15:30
              </td>
              <td className="text-[18.42px] py-6 text-center">2 hours</td>
              <td className="text-[18.42px] py-6 text-center">
                Thur, 18 April ‘24, 14:00
              </td>
              <td className="text-[18.42px] py-6">
                <button className="text-[24.07px] bg-graymod-one text-white font-normal px-6 py-2 rounded-lg text-center">
                  Expired
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div className="flex items-center">
        <h3 className="text-[24px] font-normal">View In Calendar</h3>
        <MdOpenInNew className="w-[25px] h-[25px] ms-2" />
      </div>
    </div>
  );
};

export default LearnerPendingRequests;
