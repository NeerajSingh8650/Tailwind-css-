import { useEffect, useState } from "react";
import "react-phone-input-2/lib/style.css";
import "../ExpertOnboarding/ExpertOnboarding.css";
import profileImage from "../../assets/userIcon.svg";
import cameraIcom from "../../assets/camera.svg";
import {
  API_DATE_FORMAT,
  GenderType,
  LearnerProfileType,
  LINKED_IN_URL_REGEX_PATTERN,
  USER_DATE_FORMAT,
} from "../../constants";
import { useNavigate } from "react-router-dom";
import type { DatePickerProps } from 'antd';
import { DatePicker } from "antd";
import dayjs from "dayjs";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "@/Redux/store/store";
import { learnerOnboard } from "@/Redux/slices/LearnerSlices";
import { Button } from "@/shadcn/ui/button";
import PageHeading from "@/Components/PageHeadings";

const LearnerPersonalInformation = () => {
  const navigate = useNavigate();
  const dispatch: any = useDispatch();
  const profileDetails = useSelector((state: RootState) => state.user.userDetails);

  const [learnerProfile, setLearnerProfile] = useState<string>("");
  const [error, setError] = useState<boolean>(false);
  const [firstName, setFirstName] = useState<string>("");
  const [lastName, setLastName] = useState<string>("");
  const [dob, setDob] = useState<string>('');
  const [gender, setGender] = useState<string>("");
  const [linkedInProfileLink, setLinkedInProfileLink] = useState<string>("");
  const [showLinkedInInput, setShowLinkedInInput] = useState<boolean>(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const { loggedOut } = useSelector((state: RootState) => state.auth);
  const { onboardingDone } = useSelector((state: RootState) => state.learner);


  useEffect(() => {
    if (loggedOut) {
      localStorage.clear();
      sessionStorage.clear();
      navigate('/');
    }
  }, [loggedOut])

  useEffect(() => {
    if (profileDetails) {
      setFirstName(profileDetails.firstName);
      setLastName(profileDetails.lastName);
      setSelectedImage(profileDetails.picUrl);
      setGender(profileDetails.gender);
      setLinkedInProfileLink(profileDetails.linkedInProfileLink);
      setDob(profileDetails.dob);
    }
  }, [])

  useEffect(() => {
    if (onboardingDone) {
      if (learnerProfile == LearnerProfileType.PARENT) {
        navigate('/learner-children-information')
      }
      else {
        navigate('/explore-experts');
      }
    }
  }, [onboardingDone])

  // const handleChange = (
  //   e: string | undefined,
  //   value: CountryData | undefined,
  //   name: string
  // ) => {
  //   if (name === "phoneNumber" && e && value) {
  //     let splitMobile = e.split(value?.dialCode || "");
  //     setCountryCode(value?.dialCode || "");
  //     setPhoneNumber(splitMobile[1] || "");
  //   }
  // };

  const handleImageClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault();
    const fileInput = document.getElementById("fileInput") as HTMLInputElement;
    if (fileInput) {
      fileInput.click();
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const imageUrl = URL.createObjectURL(e.target.files[0]);
      setSelectedImage(imageUrl);
    }
  };


  useEffect(() => {
    console.log("learner profile", learnerProfile, showLinkedInInput);
    if (learnerProfile == LearnerProfileType.PROFESSIONAL || learnerProfile == LearnerProfileType.SEEKING_OPPORTUNITIES) {
      setShowLinkedInInput(true);
    }
  }, [dob, learnerProfile]);


  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (
      !firstName ||
      !lastName ||
      !dob ||
      !gender ||
      !learnerProfile) {
      setError(true);
      return;
    } else {
      setError(false);
      const learnerData = {
        firstName,
        lastName,
        dob: dob,
        gender: gender.toUpperCase(),
        learnerProfile,
        linkedInProfileLink
      };
      try {
        dispatch(learnerOnboard(learnerData));
      } catch (error: any) {
        console.error("Error Response:", error.response?.data || error.message);
      }
    }
  };

  const onChange: DatePickerProps['onChange'] = (date, dateString) => {
    if (date) {
      dateString = date.format(API_DATE_FORMAT);
    } 
    setDob(dateString.toString());
  };


  return (
    <div className="my-12 mx-10">
      <PageHeading title="Personal Information"/>
      <div className="flex flex-col md:flex-row lg:ml-[50px] md:ml-[0px] ml-[0px] space-x-3 md:space-x-8 justify-center gap-[20px] lg:gap-[100px] sm: items-center md:items-start">
        <div  className="relative">
          <label htmlFor="fileInput">
            <img
              src={selectedImage || profileImage}
              alt="Upload Image"
              className="w-[300px] h-[auto] mt-12"
              style={{ borderRadius: '600px' }}
            />
            <div
              className="bg-[#dddddd] w-[40px] h-[40px] flex items-center justify-center absolute bottom-2 right-8"
              style={{ cursor: 'pointer', borderRadius: '500px' }}
            >
              <img
                src={cameraIcom}
                className="w-[2rem] h-[1rem]"
                onClick={handleImageClick}
              />
            </div>
          </label>
          <input
            id="fileInput"
            type="file"
            style={{ display: "none" }}
            accept="image/*"
            onChange={handleImageChange} />
        </div>

        <form className="mt-6 lg:mt-12" onSubmit={handleSubmit}>
          <div className="flex flex-col mb-8 md:flex-row justify-between md:space-x-3">
            <div>
              <label
                htmlFor=""
                className="font-normal text-[20px] lg:text-[25px]"
              >
                First Name
              </label>
              <span className="text-red-500 text-lg ms-1">*</span>
              <input
                type="text"
                className="border border-graymod w-full font-extralight text-[16px] rounded-lg py-2 ps-3 outline-none mt-5"
                placeholder="First Name"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
              />
              {error && !firstName && (
                <p className="text-red-500 font-bold">First Name is required</p>
              )}
            </div>
            <div className="mt-8 md:mt-0">
              <label
                htmlFor=""
                className="font-normal text-[20px] lg:text-[25px] mb-4"
              >
                Last Name
              </label>
              <span className="text-red-500 text-lg ms-1">*</span>
              <input
                type="text"
                className="border border-graymod w-full font-extralight text-[16px] rounded-lg py-2 ps-3 outline-none mt-5"
                placeholder="Last Name"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
              />
              {error && !lastName && (
                <p className="text-red-500 font-bold">Last Name is required</p>
              )}
            </div>
          </div>
          <div className="flex flex-col md:flex-row justify-between md:space-x-3 mb-8">
            <div className="w-full flex flex-col">
              <label
                htmlFor=""
                className="font-normal text-[20px] lg:text-[25px]"
              >
                Date of Birth
                <span className="text-red-500 text-lg ms-1">*</span>
              </label>
              <DatePicker
                value={dob ? dayjs(dob) : null}
                onChange={onChange}
                placeholder="Select Date of Birth"
                className="h-[44px] border border-graymod font-extralight text-[16px] rounded-lg py-2 ps-3 outline-none mt-5 lg:w-full w-full"
                id="dateSel"
                format={USER_DATE_FORMAT}
                maxDate={dayjs().subtract(13, 'year')}
              />
              {error && !dob && (
                <p className="text-red-500 font-bold">
                  Date of Birth is required
                </p>
              )}
            </div>
            <div className="w-full mt-8 md:mt-0">
              <label
                htmlFor=""
                className="font-normal text-[20px] lg:text-[25px] mb-4"
              >
                Gender
              </label>
              <span className="text-red-500 text-lg ms-1">*</span>
              <div className="relative">

                <select
                  name="gender"
                  id="gender"
                  className={`h-[44px] cursor-pointer appearance-none bg-white border border-graymod w-full 
                  ${gender ? 'font-light' : 'font-extralight'}
                  text-[16px] rounded-lg py-2 ps-3 outline-none mt-5`}
                  value={gender}
                  onChange={(e) => setGender(e.target.value)}
                >
                  <option value="">Select Gender</option>
                  <option value={GenderType.MALE}>{GenderType.MALE}</option>
                  <option value={GenderType.FEMALE}>{GenderType.FEMALE}</option>
                </select>
                <span className="absolute inset-y-0 mt-5 cursor-pointer right-0 flex items-center pr-3 pointer-events-none">
                  <svg className="w-4 cursor-pointer h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                  </svg>
                </span>
              </div>
              {error && !gender && (
                <p className="text-red-500 font-bold">Gender is required</p>
              )}
            </div>
          </div>
          <div className="flex flex-col md:flex-row justify-between md:space-x-3">
            <div className="flex flex-col lg:w-[49%] md:w-[49%] sm:mt-0 mt-0 md:mt-0 sm:w-full mb-8">
              <label className="font-normal text-[20px] lg:text-[25px] mb-4 md:mb-0 sm:mb-0">
                Learning Role
                <span className="text-red-500 text-lg ms-1">*</span>
              </label>
              <div className="relative">
              <select
                className={`h-[44px] bg-white border border-graymod w-full font-extralight cursor-pointer appearance-none
                ${learnerProfile ? 'font-light' : 'font-extralight'}
                text-[16px] rounded-lg py-2 ps-3 outline-none mt-5`}
                value={learnerProfile}
                onChange={(e) => setLearnerProfile(e.target.value)}
              >
                <option value="">Select Learner Profile</option>
                <option value={LearnerProfileType.PARENT}>{LearnerProfileType.PARENT}</option>
                <option value={LearnerProfileType.PROFESSIONAL}>
                  {LearnerProfileType.PROFESSIONAL}
                </option>
                <option value={LearnerProfileType.SEEKING_OPPORTUNITIES}>
                  {LearnerProfileType.SEEKING_OPPORTUNITIES}
                </option>
                <option value={LearnerProfileType.STUDENT}>
                  {LearnerProfileType.STUDENT}
                </option>
              </select>
              <span className="absolute inset-y-0 mt-5 cursor-pointer right-0 flex items-center pr-3 pointer-events-none">
                  <svg className="w-4 cursor-pointer h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                  </svg>
                </span>
                </div>
              {error && !learnerProfile && (
                <p className="text-red-500 font-bold">
                  Learning Role is required
                </p>
              )}
            </div>
            {showLinkedInInput && (
                <div className="flex flex-col lg:w-[50%] md:w-[50%] sm:mt-0 mt-0 md:mt-0 sm:w-full">
                    <label
                      htmlFor="linkedIn"
                      className="font-normal text-[20px] lg:text-[25px] mb-0 md:mb-0 sm:mb-0"
                    >
                      LinkedIn Profile
                    </label>
                    <input
                      type="url"
                      pattern={LINKED_IN_URL_REGEX_PATTERN}
                      className="h-[44px] border border-graymod w-full font-extralight text-[16px] rounded-lg py-2 ps-3 outline-none mt-5"
                      placeholder="LinkedIn Profile URL"
                      value={linkedInProfileLink}
                      onChange={(e) => setLinkedInProfileLink(e.target.value)}
                    />
                </div>
              )}

          </div>
              {/* <div className="mt-8 lg:mt-0 md:mt-0">
                <div className="flex flex-col space-y-2">
                  {showPhoneInput && (
                    <label
                      htmlFor="phoneNumber"
                      className="font-normal text-[20px] lg:text-[25px] mb-4 md:mb-0 sm:mb-0"
                    >
                      Phone Number
                      <span className="text-red-500 text-lg ms-1">*</span>
                    </label>
                  )}
                  {showPhoneInput && (
                    <>
                      <div className="flex flex-row">
                        <div className="w-[92%] sm:w-[92%] lg:w-[45%] md:w-[42%]">
                          <PhoneInput
                            country={"in"}
                            value={`${countryCode}${phoneNumber}`}
                            onChange={(e, phone) =>
                              handleChange(e, phone as CountryData, "phoneNumber")
                            }
                            inputStyle={{
                              height: "44px",
                              border: "1px solid #DDDDDD",
                              width: "100%",
                              fontSize: "16px",
                              borderRadius: "8px",
                              padding: "10px 15px",
                              outline: "none",
                              marginTop: "5px",
                              marginLeft: "30px",
                            }}
                            inputProps={{
                              required: true,
                            }}
                          />
                        </div>
                        <button
                          className="text-white bg-cyanmod  w-[30%] lg:w-[15%] md:w-[20%] text-[14px] font-normal py-2 px-4 rounded-lg disabled:opacity-50 ml-11"
                          type="button"
                          onClick={handleGetOTP}
                          disabled={error}
                        >
                          Get OTP
                        </button>
                      </div>
                      {error && !phoneNumber && (
                        <p className="text-red-500 font-bold">
                          Phone is required
                        </p>
                      )}
                    </>
                  )}
                </div>
              </div> */}
          <div className="flex justify-end mt-10">
            <Button>
              Submit
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LearnerPersonalInformation;
