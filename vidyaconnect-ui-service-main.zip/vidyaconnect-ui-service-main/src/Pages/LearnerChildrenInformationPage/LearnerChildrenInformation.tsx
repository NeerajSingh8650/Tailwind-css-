import { useEffect, useState } from "react";
import "react-phone-input-2/lib/style.css";
import "../ExpertOnboarding/ExpertOnboarding.css";
import add from '../../assets/add.svg';
import { useNavigate } from "react-router-dom";
import LearnerChildPopup from "./LearnerChildPopup";
import { Button } from "@/shadcn/ui/button";
import ChildCard from "@/Components/ChildCard/ChildCard";
import { useDispatch, useSelector } from "react-redux";
import { saveChildData, getChildren, deleteChild} from "@/Redux/slices/LearnerSlices";
import PageHeading from "@/Components/PageHeadings";

interface childData {
    name : string;
    dob : string;
    gender : string;
    school : string;
    grade : string;
    schoolId?: number,
    id?:number
}

const LearnerChildrenInformation = () => {
    const dispatch: any = useDispatch();

    const navigate = useNavigate();
    const [visible, setVisible] = useState(false);
    const [childDataList, setChildDataList] = useState<childData[]>([]);
    const [selectedChild, setSelectedChild] = useState<childData | null>(null);
    const children = useSelector((state: any) => state.learner.children);

    useEffect(() => {
        dispatch(getChildren());
    },[dispatch])

    useEffect(() => {
         setChildDataList(children.children? children.children : []);
    }, [children]);
    
    const handleSaveChild = async (data: childData) => {
        const { schoolId, ...rest } = data;
        const processedData = { ...rest, ...(schoolId !== 0 && { schoolId }) };
    
        await dispatch(saveChildData(processedData));
        await dispatch(getChildren()).unwrap();
        setVisible(false);
    };

    const handleEditChild = (child: childData) => {
        setSelectedChild(child);
        setVisible(true);
    };

    const handleAddChild = () => {
        setSelectedChild(null);
        setVisible(true);
    };

    const handleDeleteChild = async (child: childData) => {
        await dispatch(deleteChild(child));
        await dispatch(getChildren()).unwrap();         
    };

    return (
        <div className="my-12 mx-10">
            <PageHeading title = "Children Information"/>
            <div className="flex flex-col mt-5 md:flex-column md:ml-[0px] ml-[0px] space-x-3 md:space-x-8 justify-center gap-[20px] lg:gap-[50px] sm: items-left md:items-left">
                {childDataList.map((child, index) => (
                    <ChildCard
                        key={index}
                        data={child}
                        onEdit={() => handleEditChild(child)}
                        onDelete = {() => handleDeleteChild(child)}
                    />
                ))}
                <div className="child-info-card mb-10">
                    <table className="full-width">
                        <tr>
                            <td className="">
                                <h2 className="font-normal text-[16px]">
                                    Add Child Information
                                </h2>
                            </td>
                            <td className="flex justify-end">
                                <Button
                                    variant={'ghost'}
                                    onClick={handleAddChild}
                                >
                                    <img
                                        src={add}
                                        alt="Add info"
                                        className="w-[25px] h-[auto]"
                                    />
                                </Button>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <div className="flex justify-end mt-10">
                <Button variant="outline" className="mr-5" onClick={() => navigate('/explore-experts')}>
                    Skip
                </Button>
                <Button onClick={() => navigate('/explore-experts')}>
                    Submit
                </Button>
            </div>
            {visible && <LearnerChildPopup onClose={() => setVisible(false)} initialData={selectedChild} onSubmit={(data: childData) => handleSaveChild(data)} />}
        </div>
    );
};

export default LearnerChildrenInformation;
