import { useEffect, useState } from "react";
import "react-phone-input-2/lib/style.css";
import "../ExpertOnboarding/ExpertOnboarding.css";
import { DatePicker } from "antd";
import type { DatePickerProps } from 'antd';
import { Button } from "@/shadcn/ui/button";
import dayjs from "dayjs";
import { useSelector, useDispatch } from "react-redux";
import { RootState } from "@/Redux/store/store";
import ComboBox  from "@/Components/ui/comboBox";
import { fetchSchools, School } from "@/Redux/slices/LearnerSlices";
import { API_DATE_FORMAT, GenderType, USER_DATE_FORMAT } from "@/constants";


interface childData {
    name: string;
    dob: string;
    gender: string;
    school: string;
    schoolId?: number;
    grade: string;
    id?: number;
}

interface propsData {
    onSubmit: (data: childData) => void;
    onClose: () => void;
    initialData?: childData | null;
}
 
const LearnerChildPopup = ({ onSubmit, onClose,  initialData }: propsData) => {
    const dispatch: any = useDispatch();
    const { schools } = useSelector((state: RootState) => state.learner);
    const [name, setName] = useState<string>("");
    const [dob, setDob] = useState<string>('');
    const [gender, setGender] = useState<string>("");
    const [school, setSchool] = useState<School>({ name: initialData?.school || '', id: initialData?.schoolId || 0 });
    const [grade, setGrade] = useState<string>("");

    const [errors, setErrors] = useState<{
        name?: string;
        dob?: string;
        gender?: string;
        school?: string;
        grade?: string;
    }>({});

    useEffect(() => {
        if (initialData) {
            setName(initialData.name);
            setDob(initialData.dob);
            setGender(initialData.gender);
            setSchool({ name: initialData.school, id: initialData.schoolId || 0 });
            setGrade(initialData.grade);
        }
    }, [initialData]);


    useEffect(() => {
        dispatch(fetchSchools());
    },[dispatch])

    const validateFields = () => {
        const newErrors: typeof errors = {};
        if (!name) newErrors.name = "Name is required.";
        if (!dob) newErrors.dob = "Date of Birth is required.";
        if (!gender) newErrors.gender = "Gender is required.";
        if (!school.name) newErrors.school = "School is required.";
        if (!grade) newErrors.grade = "Grade is required.";
        setErrors(newErrors);
        console.log('newErrors',newErrors)
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = () => {
        if (validateFields()) {  
            onSubmit({ name, dob, gender, school: school.name, schoolId: school.id, grade, id: initialData?.id });
        }
    };

    const onChange: DatePickerProps['onChange'] = (date, dateString) => {
        if (date) {
            dateString = date.format(API_DATE_FORMAT);
        }
        setDob(dateString.toString())
        setErrors((prev) => ({ ...prev, dob: '' }));
    };

    const handleSchoolSelect = (selectedSchool: any) => {
        setSchool(selectedSchool);
        setErrors((prev) => ({ ...prev, school: '' }));
    };

    return (
        <div className="social-modal learner-child-popup open w-[50rem] h-[auto]">
            <div className="my-12 mx-10">
                <h2 className="font-medium text-[20px] lg:text-[24px] mb-7 justify-center flex text-graymod-textfive">
                    Child Information
                </h2>
                <div className="flex flex-col mt-12 md:flex-column md:ml-[0px] ml-[0px] space-x-3 md:space-x-8 justify-center gap-[20px] lg:gap-[50px] sm:items-center md:items-start">
                    <div className="child-info-card mb-10">
                        <table className="full-width">
                            <tr>
                                <td>
                                    <label className="font-normal text-[16px] lg:text-[20px]">Name</label>
                                </td>
                                <td>
                                    <input
                                        type="text"
                                        className="border border-graymod w-full font-extralight text-[16px] rounded-lg py-2 ps-3 mt-3 mb-3 outline-none"
                                        placeholder="Name"
                                        value={name}
                                        onChange={(e) => {
                                            setName(e.target.value);
                                            setErrors((prev) => ({ ...prev, name: '' }));
                                        }}
                                    />
                                    {errors.name && <p className="text-red-500 text-sm">{errors.name}</p>}
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label className="font-normal text-[16px] lg:text-[20px]">Date of Birth</label>
                                </td>
                                <td>
                                    <DatePicker
                                        value={dob ? dayjs(dob) : null}
                                        onChange={onChange}
                                        placeholder="Enter date of birth"
                                        format={USER_DATE_FORMAT}
                                        className="h-[44px] border border-graymod font-extralight text-[16px] rounded-lg py-2 ps-3 outline-none mt-3 mb-3 lg:w-full w-full"
                                        id="dateSel"
                                    />
                                    {errors.dob && <p className="text-red-500 text-sm">{errors.dob}</p>}
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label htmlFor="" className="font-normal text-[16px] lg:text-[20px] mb-4">Gender</label>
                                </td>
                                <td>
                                    <select
                                        name="gender"
                                        id="gender"
                                        className={`h-[44px] bg-white border border-graymod w-full font-extralight
                                            ${gender ? 'font-light' : 'font-extralight'}
                                             text-[16px] rounded-lg py-2 ps-3 outline-none mt-3 mb-3`}
                                        value={gender}
                                        onChange={(e) => {
                                            setGender(e.target.value);
                                            setErrors((prev) => ({ ...prev, gender: '' }));
                                        }}
                                    >
                                        <option value="">Select Gender </option>
                                        <option value={GenderType.MALE}>{GenderType.MALE}</option>
                                        <option value={GenderType.FEMALE}>{GenderType.FEMALE}</option>
                                    </select>
                                    {errors.gender && <p className="text-red-500 text-sm">{errors.gender}</p>}
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label htmlFor="" className="font-normal text-[16px] lg:text-[20px] mb-4">School</label>
                                </td>
                                <td>
                                <ComboBox 
                                placeholder="Add School"
                                    suggestions ={schools}
                                    onSelect={handleSchoolSelect}
                                    selectedItem={school.name}
                                    className="py-2"
                                />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label htmlFor="" className="font-normal text-[16px] lg:text-[20px] mb-4">Grade</label>
                                </td>
                                <td>
                                    <input
                                        type="text"
                                        className="border border-graymod w-full font-extralight text-[16px] rounded-lg py-2 ps-3 outline-none mt-3 mb-3"
                                        placeholder="Eg: V"
                                        value={grade}
                                        onChange={(e) => {
                                            setGrade(e.target.value);
                                            setErrors((prev) => ({ ...prev, grade: '' }));
                                        }}
                                    />                                    
                                </td>
                            </tr>
                            <tr> 
                                <td colSpan={2} className="w-full pt-20 btn-w-width text-right">
                                    <Button variant="outline" onClick={onClose} className="mx-5">
                                        Cancel
                                    </Button>
                                    <Button onClick={() => handleSubmit()}>
                                        Save
                                    </Button>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default LearnerChildPopup;
