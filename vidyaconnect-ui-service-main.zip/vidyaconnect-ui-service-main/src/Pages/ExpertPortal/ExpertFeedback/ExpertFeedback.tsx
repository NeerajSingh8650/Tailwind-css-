import { useEffect, useState } from "react";
import { FaStar } from "react-icons/fa";
import CustomSpinner from "../../../Components/CustomSpinner/CustomSpinner";
import { NUMBER_OF_PAGES, PAGE_SIZE} from "../../../constants";
import arrowdown from '../../../assets/arrowdown.svg';
import './ExpertFeedback.css';
import userIcon from "../../../assets/user-icon.svg";
import { useDispatch, useSelector } from "react-redux";
import { Feedback, getFeedback } from "@/Redux/slices/FeedbackSlice";
import { AppDispatch, RootState } from "@/Redux/store/store";


const ExpertFeedback = () => {
  const dispatch: AppDispatch = useDispatch();
  const feedbackData = useSelector((state: RootState) => state.feedback);
  const [hiddenflag, setHiddenflag] = useState(false);
  const [search, setSearch] = useState<string>('');
  const [filter, setFilter] = useState<string>('');
  // const seemore = useRef<HTMLDivElement>(null);
  // const seeless = useRef<HTMLDivElement>(null);


  // Function to toggle dropdown visibility
  const dropDownShow = () => {
    setHiddenflag(prev => !prev);
  };

  // // Function to toggle visibility of review text
  // const toggleVisibility = () => {
  //   if (seemore.current && seeless.current) {
  //     seemore.current.classList.toggle("hidden");
  //     seeless.current.classList.toggle("hidden");
  //   }
  // };

  // Function to handle sorting selection
  const filterSelect = (filterOption: string) => {
    setFilter(filterOption);
    dropDownShow(); // Close dropdown after selection
  };



  useEffect(() => {
    dispatch(getFeedback({
            queryFilter: null,
            sortFilter: filter,
            page: NUMBER_OF_PAGES,
            size: PAGE_SIZE
          }));
  }, [filter]);



  // Function to render star ratings
  const renderStars = (rating: number) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <FaStar
          key={i}
          className={i <= rating ? "text-[#FFC700] w-[18px] h-[18px]" : "text-[#919EAB] w-[18px] h-[18px]"}

        />
      );
    }
    return stars;
  };


  // Filter reviews based on search input
  const finalReview = feedbackData.data.filter((data: Feedback) => {
    return search === '' ? true : data.review.toLowerCase().includes(search.toLowerCase());
  });


  return (
    <div className="w-[100vw] bg-graymod"
    style={{
      minHeight: "100vh"
    }}
    >
      <div className="p-12 mx-6">
        <div className="flex justify-between pt-10">
          <div className="flex-grow">
            <h1 className="text-[24px] font-medium text-[#515151] pb-1">My FeedBack</h1>
            <hr className=" border-none h-[4px] bg-[#bebebe]" />
          </div>
          <div className="">
            <div className="flex items-center w-[350px] justify-center gap-4">
              <h1 className="text-[48px] font-semibold text-[#098B42]">{feedbackData.ratings} / 5</h1>
              <div className="flex gap-2">
                {renderStars(feedbackData.ratings)}
              </div>
            </div>
          </div>
        </div>
        <div className="flex justify-between items-start pb-3">

          <div className="flex gap-6 items-center justify-center">
            <input
              placeholder="Search ..."
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="h-[39px] w-[346px] rounded-3xl outline-none border border-[#c7c7c7] px-3"
            />
            <ul className="relative w-[133px] h-[28px]">
              <li
                onClick={dropDownShow}
                className="flex gap-7 py-1 cursor-pointer text-[16px] bg-[#b0b0b048] justify-center items-center"
              >
                <span>Sort by</span>
                <img src={arrowdown} alt="Dropdown arrow" />
              </li>
              {hiddenflag && (
                <div className="absolute top-8 dropdown bg-white z-30 flex flex-col justify-around w-[133px] h-[135px] drop-shadow-sm shadow-lg">
                  <ul>
                    <li className="font-semibold border-b border-[#E6E6E6] py-1">Sort by</li>
                    <li onClick={() => filterSelect("id,desc")} className="hover:bg-gray-300 py-1">Newest</li>
                    <li onClick={() => filterSelect("id,asc")} className="hover:bg-gray-300 py-1">Oldest</li>
                    <li onClick={() => filterSelect("rating,desc")} className="hover:bg-gray-300 py-1">Highest</li>
                    <li onClick={() => filterSelect("rating,asc")} className="hover:bg-gray-300 py-1">Lowest</li>
                  </ul>
                </div>
              )}
            </ul>
          </div>
        </div>
        {feedbackData.loading ? (
          <CustomSpinner />
        ) : (
          <div className="grid xl:grid-cols-4 mt-12 overflow-y-auto gap-3">
            {finalReview.filter((data:Feedback) => data.review !== null && data.review.trim() !== '')
            .map((data: Feedback) => (
              <div key={data.id} className="p-7 text-[16px] border flex flex-col gap-2 bg-white rounded-2xl ">
                <div className="flex items-center mb-1 justify-start">
                  <div className="h-[50px] border border-black  flex justify-center items-center w-[50px] rounded-[50%]">
                    <img src={userIcon} alt="User icon" />
                  </div>
                  <div className="ml-4">
                    <h2 className="font-medium text-[22px] text-[#515151]">{data.learnerName}</h2>
                    <div className="flex gap-1">{renderStars(+data.rating)}</div>
                  </div>
                </div>
                <div className="text-[18px] font-medium text-[#656565]">{data.title}</div>
                <div className="text-[16px]  h-[10rem] overflow-y-scroll text-[#616161]">
                  {data.review}
                  {/* {data.review.length <= FEEDBACK_MAX_CHARACTER_LENGTH ? (
                    data.review
                  ) : (
                    <>
                      <div ref={seemore} className="block">
                        {data.review.slice(0, FEEDBACK_MAX_CHARACTER_LENGTH) + '...'}
                        <span onClick={toggleVisibility} className="text-[#09A5D6] cursor-pointer"> {FEEDBACK_SEE_MORE}</span>
                      </div>
                      <div ref={seeless} className="hidden" >
                        {data.review}
                        <span onClick={toggleVisibility} className="text-[#09A5D6] cursor-pointer"> {FEEDBACK_SEE_LESS}</span>
                      </div>
                    </>
                  )} */}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ExpertFeedback;