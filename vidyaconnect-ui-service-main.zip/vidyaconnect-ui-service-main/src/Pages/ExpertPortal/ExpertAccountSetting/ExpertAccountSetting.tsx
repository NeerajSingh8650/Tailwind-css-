const ExpertAccountSetting = () => {
  return (
    <div className="m-20">
      <h2 className="text-[40px] font-medium mb-6">Available Slots</h2>
      <div className="border border-[#C7C7C7]"></div>
      <div>
        <h2 className="font-medium text-[40px] my-5">Bank Account Details</h2>
        <div className="mb-12">
          <form>
            <div className="flex mb-6">
              <label className="text-[24px] font-normal w-[35%]">Name</label>
              <div className="w-[65%]">
                <input
                  type="email"
                  className="border border-graymod-one font-extralight text-[24px] rounded-xl py-2 ps-3 outline-none w-[434px] h-[49px]"
                />
              </div>
            </div>
            <div className="flex mb-6">
              <label className="text-[24px] font-normal w-[35%]">
                Account Number
              </label>
              <div className="w-[65%]">
                <input
                  type="email"
                  className="border border-graymod-one font-extralight text-[24px] rounded-xl py-2 ps-3 outline-none w-[434px] h-[49px]"
                />
              </div>
            </div>
            <div className="flex mb-6">
              <label className="text-[24px] font-normal w-[35%]">
                Re-Enter Account Number
              </label>
              <div className="w-[65%]">
                <input
                  type="email"
                  className="border border-graymod-one font-extralight text-[24px] rounded-xl py-2 ps-3 outline-none w-[434px] h-[49px]"
                />
              </div>
            </div>
            <div className="flex mb-6">
              <label className="text-[24px] font-normal w-[35%]">
                IFSC Code
              </label>
              <div className="w-[65%]">
                <input
                  type="email"
                  className="border border-graymod-one font-extralight text-[24px] rounded-xl py-2 ps-3 outline-none w-[434px] h-[49px]"
                />
              </div>
            </div>
          </form>
        </div>
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <input type="checkbox" className="w-4 h-4" name="" id="" />
            <p className="text-[24px] font-normal ms-5">
              Add my sessions to Calendar automatically
            </p>
          </div>
          <button className="text-lg login-btn text-white font-normal px-8 py-2 rounded-lg text-center">
            Save
          </button>
        </div>
      </div>
    </div>
  );
};

export default ExpertAccountSetting;
