import { useEffect, useState } from "react";
import Pagination from "../../LearnerSelectExpert/Pagination";
import { FaCheck } from "react-icons/fa6";
import { FaTimes } from "react-icons/fa";
import CustomSpinner from "../../../Components/CustomSpinner/CustomSpinner";
import PendingRequestAcceptModal from "../../../Components/PendingRequestAcceptModal/PendingRequestAcceptModal";

interface requestPendingData {
  id: number;
  title: string;
  desc: string;
  timing: string;
  duration: string;
}

const ExpertPendingRequest = () => {
  const [pendingData, setPendingData] = useState<requestPendingData[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [requestModalIsOpen, setRequestModalIsOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  const openRequestModal = () => {
    setRequestModalIsOpen(true);
  };

  const closeRequestModal = () => {
    setRequestModalIsOpen(false);
  };

  useEffect(() => {
    fetch("pendingRequestData.json")
      .then((res) => res.json())
      .then((data) => {
        setPendingData(data);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
        setLoading(false);
      });
  }, []);

  const ITEMS_PER_PAGE = 4;
  const TOTAL_PAGES = Math.ceil(pendingData.length / ITEMS_PER_PAGE);

  const paginatedData = pendingData.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  return (
    <>
      {loading ? (
        <CustomSpinner />
      ) : (
        <div className="my-14 mx-20">
          <h2 className="font-medium text-[40px] mb-8">Pending Requests</h2>
          <div className="grid grid-cols-2 gap-9 mx-8">
            {paginatedData?.map((requested) => (
              <div key={requested.id} className="p-7 border rounded-2xl">
                <h4 className="font-normal text-[30px] mb-2">
                  {requested.title}
                </h4>
                <p className="font-normal text-[16px] mb-6">{requested.desc}</p>
                <div className="flex items-center mb-3">
                  <h2 className="w-[20%]">Date & Time:</h2>
                  <h4 className="w-[80%]">{requested.timing}</h4>
                </div>
                <div className="flex items-center mb-7">
                  <h2 className="w-[20%]">Duration:</h2>
                  <h4 className="w-[80%]">{requested.duration}</h4>
                </div>
                <div className="flex justify-center items-center space-x-5">
                  <button
                    className="bg-[#12A150] text-white w-[125px] h-[40px] flex justify-center items-center rounded-lg"
                    onClick={openRequestModal}
                  >
                    Accept <FaCheck className="ms-2" />
                  </button>
                  <button className="bg-[#C90000] text-white w-[125px] h-[40px] flex justify-center items-center rounded-lg">
                    Reject <FaTimes className="ms-2" />
                  </button>
                </div>
              </div>
            ))}
          </div>
          <Pagination
            currentPage={currentPage}
            totalPages={TOTAL_PAGES}
            onPageChange={setCurrentPage}
          />
          {requestModalIsOpen && (
            <PendingRequestAcceptModal
              isOpen={requestModalIsOpen}
              onClose={() => {
                closeRequestModal();
              }}
            />
          )}
        </div>
      )}
    </>
  );
};

export default ExpertPendingRequest;
