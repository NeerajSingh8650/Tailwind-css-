import "./LearnerExpertPreference.css";
import silverImg from "../../assets/silver_user.svg";
import goldImg from "../../assets/gold_user.svg";
import platinumImg from "../../assets/platinum_user.svg";
import RangeSlider from "./RangeSlider";

const LearnerExpertPreference = () => {

  const handleBookClick = () => {
  };

  return (
    <div className="my-12 mx-2 sm:mx-8 lg:mx-12">
      <div className="border border-graymod-one py-8 rounded-lg">
        <h2 className="font-normal text-[56px] text-center mb-8">
          Expert Preference
        </h2>
        <div className="mx-20">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-x-24">
            <div
              onClick={() => {}}
              className="cursor-pointer"
            >
              <h3 className="font-normal text-[32.51px] sliver-text mb-7 text-center">
                Silver
              </h3>
              <div className="flex justify-center">
                <img src={silverImg} className="w-28 h-28 mb-3" alt="Silver" />
              </div>
              <p className="font-normal text-[16.26px] mb-5 text-center">
                Experts with solid industry experience offering guidance at
                economical price point
              </p>
              <RangeSlider
                min={2000}
                max={4000}
                initialValues={[2000, 4000]}
                thumbColor="#8D8E94"
                trackColor="#000000"
              />
            </div>
            <div
              onClick={() => {}}
              className="cursor-pointer"
            >
              <h3 className="font-normal text-[32.51px] gold-text mb-7 text-center">
                Gold
              </h3>
              <div className="flex justify-center">
                <img src={goldImg} className="w-28 h-28 mb-3" alt="Gold" />
              </div>
              <p className="font-normal text-[16.26px] mb-5 text-center">
                Seasoned experts with advanced knowledge and extensive
                experience
              </p>
              <RangeSlider
                min={4000}
                max={6000}
                initialValues={[4000, 6000]}
                thumbColor="#7E630B"
                trackColor="#000000"
              />
            </div>
            <div
              onClick={() => {}}
              className="cursor-pointer"
            >
              <h3 className="font-normal text-[32.51px] gold-text mb-7 text-center">
                Platinum
              </h3>
              <div className="flex justify-center">
                <img
                  src={platinumImg}
                  className="w-28 h-28 mb-3"
                  alt="Platinum"
                />
              </div>
              <p className="font-normal text-[16.26px] mb-5 text-center">
                Top-tier experts with unparalleled skills and exceptional
                ratings.
              </p>
              <RangeSlider
                min={6000}
                max={8000}
                initialValues={[6000, 8000]}
                thumbColor="#4D4F51"
                trackColor="#000000"
              />
            </div>
          </div>
        </div>
        <div className="flex justify-end pe-5 mt-14">
          <button
            onClick={handleBookClick}
            className="text-[26.6px] login-btn text-white font-normal px-14 py-1 rounded-lg text-center"
          >
            Book
          </button>
        </div>
      </div>
    </div>
  );
};

export default LearnerExpertPreference;
