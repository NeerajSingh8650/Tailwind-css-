import React, { useState } from "react";
import { Range, getTrackBackground } from "react-range";

interface RangeSliderProps {
  min: number;
  max: number;
  initialValues: [number, number];
  thumbColor: string;
  trackColor: string;
}

const RangeSlider: React.FC<RangeSliderProps> = ({
  min,
  max,
  initialValues,
  thumbColor,
  trackColor,
}) => {
  const [values, setValues] = useState<number[]>(initialValues);

  return (
    <div>
      <div className="flex flex-col items-center my-7 mx-4">
        <Range
          values={values}
          step={1}
          min={min}
          max={max}
          onChange={(values) => setValues(values)}
          renderTrack={({ props, children }) => (
            <div
              {...props}
              className="h-[1px] w-full"
              style={{
                ...props.style,
                background: getTrackBackground({
                  values,
                  colors: [trackColor, trackColor, trackColor],
                  min: min,
                  max: max,
                }),
              }}
            >
              {children}
            </div>
          )}
          renderThumb={({ props, isDragged }) => (
            <div
              {...props}
              className="h-8 w-8 rounded-full flex justify-center items-center border border-black"
              style={{
                ...props.style,
                backgroundColor: thumbColor,
              }}
            >
              <div
                style={{
                  backgroundColor: isDragged ? "#548BF4" : "#CCC",
                }}
              />
            </div>
          )}
        />
      </div>
      <div className="w-full flex justify-between">
        <output>₹{values[0]}</output>
        <output>₹{values[1]}</output>
      </div>
    </div>
  );
};

export default RangeSlider;