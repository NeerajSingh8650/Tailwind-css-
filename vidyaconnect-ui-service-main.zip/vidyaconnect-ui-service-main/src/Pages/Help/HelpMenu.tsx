import { Link, useLocation } from 'react-router-dom';
import './Help.css';  // Ensure you have your CSS styles in this file
import { useEffect } from 'react';

const HelpMenu = () => {
    const { hash } = useLocation();
    const isActive = (iHash:string) => hash === iHash;

  useEffect(() => {
    if (!hash) {
      window.location.hash = 'getting-started';
    }
  }, [hash]);

  return (
    <div className="flex flex-col w-[335px] px-5 h-auto min-h-screen gap-4 border-r border-graymod">
      <h1 className="font-semibold text-[24px] px-4 mt-20 mb-4">Help</h1>
      <ul>
        <li>
          <Link
            to="/help#getting-started"
            className={isActive("#getting-started") ? "active menu-item":"menu-item"}
          >
            Getting Started
          </Link>
        </li>
        <li>
          <Link
            to="/help#user-guides"
            className={isActive("#user-guides") ? "active menu-item":"menu-item"}
          >
            User Guides
          </Link>
        </li>
        <li>
          <Link
            to="/help#faqs"
            className={isActive("#faqs") ? "active menu-item":"menu-item"}>
            FAQs
          </Link>
        </li>
        <li>
          <Link
            to="/help#contact-us"
            className={isActive("#contact-us") ? "active menu-item":"menu-item"}
          >
            Contact Us
          </Link>
        </li>
      </ul>
    </div>
  );
};

export default HelpMenu;
