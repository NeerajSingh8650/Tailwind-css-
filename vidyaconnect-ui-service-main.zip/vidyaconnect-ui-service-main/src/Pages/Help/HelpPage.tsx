import Question from "./Question";
import LearnerExpertToggle from "./LearnerExpertToogle";
import { useLocation} from "react-router-dom";
import HelpMenu from "./HelpMenu";
import PageHeading from "@/Components/PageHeadings";
import FAQsPage from "./FAQsPage";
import ContactUs from "./ContactUs";


const gettingStartLearnerSignup = {
    signUp: {
        title: "",
        details: [
            "Sign up as a learner using your email, Google, or LinkedIn.",
            "A verification link will be sent to your email, so ensure it's correct.",
            "Input your personal information (name, gender, DOB, phone number).",
            "Note: Users under 18 must have a parent or guardian sign up on their behalf."
        ]
    }
};


const gettingStartExpertSignup = {
    signUp: {
        title: "",
        details: [
            "Sign up as an expert using your email, Google, or LinkedIn. A verification link will be sent to your email, so ensure it's correct."
        ]
    }
};


const userGuideLearnerPayment = {
    signUp: {
        title: "",
        details: [
            "Payments are processed through Razorpay. Ensure your payment details are up to date."
        ]
    }
};


const userGuideLearnerSecurity = {
    signUp: {
        title: "",
        details: [
            "All sessions are conducted via Zoom. For your safety, avoid sharing personal information during sessions."
        ]
    }
};


const userGuideExpertManageSessions = {
    signUp: {
        title: "",
        details: [
            "Receive Requests: Session requests will be based on your availability. You can accept or decline sessions."
        ]
    }
};


const userGuideExpertPayment = {
    signUp: {
        title: "",
        details: [
            "Payments are processed through Razorpay. Ensure your payment details are up to date."
        ]
    }
};


const userGuideExpertsecurity = {
    signUp: {
        title: "",
        details: [
            "All sessions are conducted via Zoom. For your safety, avoid sharing personal information during sessions."
        ]
    }
};


const completeOnboardingExpertAns = {
    personalInformation: {
        title: "Personal Information",
        details: [
            "Fill out your details (name, gender, DOB, phone number) for KYC.",
            "Upload a profile photo (optional) and set your timezone.",
            "Note: Phone number and timezone can be updated post-KYC; other details cannot."
        ]
    },
    professionalInformation: {
        title: "Professional Information",
        details: [
            "Add or sync your LinkedIn profile for work experience and education.",
            "Specify your skills and self-assessed proficiency.",
            "Each skill is automatically linked to a relevant domain.",
            "Interviews will determine your ranking (Platinum, Gold, Silver) and pricing."
        ]
    },
    availability: {
        title: "Availability",
        details: ["Set your weekly availability, which can be updated anytime."]
    },
    verification: {
        title: "Verification",
        details: ["KYC and interviews will follow the completion of the onboarding process."]
    }
};




const UserGuideLearnerManageSessionAns = {
    exploreExperts: {
        title: "Explore Experts",
        description: "Browse through various domains and book sessions with experts."
    },
    requestAnExpert: {
        title: "Request an Expert",
        details: [
            "Specify the skills you need, then",
            "Choose an expert and pricing bucket (Platinum, Gold, Silver)",
            "Or let SageNest match you with relevant experts and trigger requests automatically."
        ]
    },
    trackYourSessions: {
        title: "Track Your Sessions",
        details: [
            "View your upcoming sessions, pending requests, and session history.",
        ]
    }
};



const DisplayAns = ({ data }: any) => {
    return (
        <ul>
            {Object.keys(data).map((key) => {
                const item = data[key];
                return (
                    <li className={`${ data[key].title === "" ? "" : "ml-4 list-disc" } `} key={key}>
                        <span className="font-semibold ">{item?.title || ""}</span>
                        {item?.details && (
                            <ul className="ml-4 list-disc">
                                {item.details.map((option: any, index: number) => (
                                    <li key={index}>{option}</li>
                                ))}
                            </ul>
                        )}
                        {item?.description && !item?.options && (
                            <p className="ml-4">{item.description}</p>
                        )}
                    </li>
                );
            })}
        </ul>
    );
};




const GettingStartLearner = () => {
    return (
        <div className="flex flex-col gap-5">
            <Question
                question="How to Sign-Up?"
                answer={<DisplayAns data={gettingStartLearnerSignup} />}
            />
        </div>
    )
}




const GettingStartExpert = () => {
    return (
        <div className="flex flex-col gap-5">
            <Question
                question="How to Sign-Up?"
                answer={<DisplayAns data={gettingStartExpertSignup} />}
            />

            <Question
                question="How to Complete Onboarding?"
                answer={<DisplayAns data={completeOnboardingExpertAns} />}
            />
        </div>
    )
}


const UserGuideLearner = () => {
    return (
        <div className="flex flex-col gap-6">
            <Question
                question="Managing Sessions"
                answer={<DisplayAns data={UserGuideLearnerManageSessionAns} />}
            />

            <Question
                question="Payment"
                answer={<DisplayAns data={userGuideLearnerPayment} />}
                />

            <Question
                question="Security"
                answer={<DisplayAns data={userGuideLearnerSecurity} />}
                />

        </div>
    )
}




const UserGuideExpert = () => {
    return (
        <div className="flex flex-col gap-6">
            <Question
                question="Manage Sessions"
                answer={<DisplayAns data={userGuideExpertManageSessions} />}  
                />

            <Question
                question="Payment"
                answer={<DisplayAns data={userGuideExpertPayment} />}  
                />

            <Question
                question="Security"
                answer={<DisplayAns data={userGuideExpertsecurity} />} 
            />

        </div>
    )
}




function HelpPage() {
    const location = useLocation();

    const GettingStartedComponent = () => {
        return (
                <LearnerExpertToggle
                    learnerContent={GettingStartLearner}
                    expertContent={GettingStartExpert}
                    heading="Getting started"
                />
        );
    }

    const UserGuidesComponent = () => {
        return (
             <LearnerExpertToggle
                    learnerContent={UserGuideLearner}
                    expertContent={UserGuideExpert}
                    heading="User Guides"
                />
           
        );
    }

    
    const getContentComponent = () => {
        switch (location.hash) {
            case '#getting-started':
                return <GettingStartedComponent />;
            case '#user-guides':
                return <UserGuidesComponent />;
            case '#faqs':
                return <FAQsPage />;
            case '#contact-us':
                return <ContactUs/>;
            default:
                return null;
        }
    };

    return (
        <div className="flex">
            <HelpMenu/>
            <div className="flex-1 px-28 py-8">
            <div className="flex-1 py-8 ">
                <PageHeading title="Help Center"/>
                {getContentComponent()}
            </div>
        </div>
        </div>
    );
}

export default HelpPage;