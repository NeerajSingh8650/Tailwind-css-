import arrow from "../../assets/arrowdown.svg"
import React, { useEffect, useState } from "react";
import ComboBox from "@/Components/ui/comboBox";
import LearnerExpertToggle from "./LearnerExpertToogle";

interface FAQItemProps {
    question: string;
    answer: string;
}

const LearnerQues = [
    {
        question: "What is SageNest?",
        answer: "SageNest is a platform connecting learners with experts for personalized, interactive sessions. It covers a wide range of domains, offering skill development, upskilling, and educational help."
    },
    {
        question: "How do I sign up for SageNest?",
        answer: "You can sign up using your email, Google, or LinkedIn. Ensure you verify your email through the link sent to your inbox."
    },
    {
        question: "Can learners below 18 sign up on SageNest?",
        answer: "No, learners under 18 need a parent or guardian to sign up on their behalf."
    },
    {
        question: "How do I book a session with an expert?",
        answer: "You can browse through available experts, book directly, or create a request specifying the skills you need. You can then choose an expert or let SageNest match you with one."
    },
    {
        question: "Can I cancel a booked session?",
        answer: "Yes, you can cancel a session from the dashboard."
    },
    {
        question: "How do I make a payment for a session?",
        answer: "Payments are handled through Razorpay. Ensure your payment method is up to date in your account settings."
    },
    {
        question: "Is it safe to share personal information during a session?",
        answer: "We advise against sharing any personal information during sessions. All interactions should remain professional and focused on the learning objectives."
    }
];



const ExpertQues = [
    {
        question: "What is SageNest?",
        answer: "SageNest is a platform connecting learners with experts for personalized, interactive sessions. It covers a wide range of domains, offering skill development, upskilling, and educational help."
    },
    {
        question: "How do I sign up for SageNest?",
        answer: "You can sign up using your email, Google, or LinkedIn. Ensure you verify your email through the link sent to your inbox."
    },
    {
        question: "What is the KYC process for experts?",
        answer: "The KYC process involves providing your personal information, such as name, gender, DOB, phone number, and professional details. This ensures authenticity and safety on the platform."
    },
    {
        question: "How are my skills and expertise verified?",
        answer: "Experts can sync their LinkedIn profile or manually input their professional details. After this, they undergo a couple of interview rounds to verify their skills. Based on the results, experts are categorized into Platinum, Gold, or Silver buckets."
    },
    {
        question: "How do I set my availability for sessions?",
        answer: "During onboarding, you'll set your weekly availability based on your timezone. You can update this at any time through your account settings."
    },
    {
        question: "How do I get paid for the sessions I conduct?",
        answer: "Payments are made to the bank account you provide during the screening process. If you need to update your bank details, you can raise a ticket in the Accounts section or the Help page."
    },
    {
        question: "What should I do if I need to update my professional information?",
        answer: "If you need to update your professional information, you will need to go through the verification process again. Contact support for guidance on this process."
    }
];


const LearnerSection = () => {
    return (
        <div className="flex flex-col gap-3 mb-10">
            {LearnerQues.map((data, index) => (
                <FAQItem
                    key={index}
                    question={data.question}
                    answer={data.answer}
                />
            ))
            }
        </div>
    )
}

const ExpertSection = () => {
    return (
        <div className="flex flex-col gap-3 mb-10">
            {ExpertQues.map((data, index) => (
                <FAQItem
                    key={index}
                    question={data.question}
                    answer={data.answer}
                />
            ))
            }
        </div>
    )
}


const FAQItem: React.FC<FAQItemProps> = ({ question, answer }) => {
    const [isOpen, setIsOpen] = useState(false);

    const toggleOpen = () => {
        setIsOpen(!isOpen);
    };

    return (
        <div className="border border-gray-300 rounded-lg p-4 w-full">
            <div
                onClick={toggleOpen}
                className="cursor-pointer w-full text-left flex justify-between items-center focus:outline-none"
            >
                <span className="font-semibold text-[20px] text-graymod-textfive">{question}</span>
                <span
                    className={`transform transition-transform duration-300 ${isOpen ? "rotate-180" : "rotate-0"
                        }`}
                >
                    <img src={arrow} alt="" />
                </span>
            </div>
            <div
                className={`transition-[max-height] duration-300 ease-in-out overflow-hidden ${isOpen ? "max-h-screen" : "max-h-0"
                    }`}
            >
                <p className="text-[18px] mt-2">{answer}</p>
            </div>
        </div>
    );
};



function FAQsPage() {

    const [suggestion, setSuggestion] = useState([])
    useEffect(() => {
        setSuggestion([])
    }, [])


    return (
        <div className='flex flex-col items-center xl:mx-36 lg:mx-24 md:mx-16 mx-8 min-h-[90vh]'>
            <h1>Frequently Asked Questions(FAQs)</h1>
            <br/>
            <div>
                <ComboBox
                    suggestions={suggestion}
                    onSelect={() => { }}
                    className="rounded-[3rem] h-[39px] mb-10 min-w-[539px] border-graymod-border"
                    placeholder="search"
                />
            </div>
            
            <LearnerExpertToggle
                heading=""
                learnerContent={LearnerSection}
                expertContent={ExpertSection}
            />

        </div>
    )
}

export default FAQsPage