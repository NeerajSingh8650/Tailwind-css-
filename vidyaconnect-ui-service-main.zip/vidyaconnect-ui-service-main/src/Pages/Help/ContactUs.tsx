import { FC } from "react";
import { useNavigate } from "react-router-dom";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/Components/ui/select";
import { Button } from "@/shadcn/ui/button";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchTicketCategories, fetchTickets } from "@/Redux/slices/TicketSlice";
import { RootState } from "@/Redux/store/store";
import { Label } from "@/Components/ui/label";
import { Textarea } from "@/Components/ui/textarea";
import { SUPPORT_EMAIL } from "@/constants";


// const Address: FC<any> = ({ heading, content }) => {
//     return (
//         <div className="h-[63px] flex flex-col justify-between">
//             <h2 className="text-[16px] font-medium">{heading}</h2>
//             <p className="text-[14px] text-graymod-textthree">{content}</p>
//         </div>
//     )
// }

const ContactUs: FC<any> = () => {
    const navigate = useNavigate()




    const [submitFlag, setSubmitFlag] = useState<boolean>(false);
    const [othersFlag, setOthersFlag] = useState<boolean>(false);
    const [value, setValue] = useState<any>("Other");
    const [textValue, setTextValue] = useState<string>("");
    const [categoryId, setCategoryId] = useState<number>(0);
    const ticket = useSelector((state: RootState) => state.ticket.categories)
    const dispatch: any = useDispatch()

    useEffect(() => {
        if (value === "" || value?.toUpperCase() === "OTHER") {
            setSubmitFlag(false);
            if (textValue === "") {
                setOthersFlag(false);
            } else {
                setOthersFlag(true);
                setSubmitFlag(true);
            }
        } else {
            setSubmitFlag(true);
            setOthersFlag(true);
        }
    }, [value, textValue]);

    useEffect(() => {
        dispatch(fetchTicketCategories())
    }, [])



    return (
        <div className='mx-32 flex flex-col '>
            <h1 className="text-[20px] text-[#515151] font-semibold">Contact Us</h1>
            <div className="bg-white flex flex-col mt-20">
            </div>
            <div className="flex flex-col gap-8">
                <h1 className="text-[20px] text-[#515151] font-medium">Hi, How can we help?</h1>
                <p className="text-[16px] text-graymod-textthree">Have a question or need to report an issue with our service? We’ve <br /> got you covered.</p>
            </div>

            <div className="w-[728px]">
                <div className="mt-10">
                    <Label className="mb-2 text-[#515151]">Area of concern</Label>
                    <Select onValueChange={(e: string) => setValue(e)}>
                        <SelectTrigger className="min-w-[728px]">
                            <SelectValue placeholder={"Choose an Area"} />
                        </SelectTrigger>
                        <SelectContent>
                            {
                                ticket.map((data: any) => (
                                    <SelectItem key={data.categoryId} onClick={() => setCategoryId(data.categoryId)} value={data.category}>
                                        {data.category}
                                    </SelectItem>
                                ))
                            }
                        </SelectContent>
                    </Select>
                    {value?.toUpperCase() === "OTHER" && (
                        <div className="gap-1.5 mt-5 text-graymod-textfive">
                            <Textarea
                                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setTextValue(e.target.value)}
                                rows={4}
                                placeholder="Please include as much info as possible..."
                                id="message"
                            />
                        </div>
                    )}

                </div>


                <div className="flex gap-3 flex-col ">
                    {submitFlag && othersFlag ? (
                        <Button className="self-end mt-4" onClick={() => {
                            dispatch(fetchTickets({ categoryId, value })).then(() => {
                                window.location.reload()
                            })
                        }}>Submit</Button>
                    ) : (
                        <Button className="mt-4 self-end" variant={"disabled"}>Submit</Button>
                    )}
                    <p className="text-[16px] mt-1">Visit our <span onClick={() => navigate("/help")} className="cursor-pointer text-cyanmod">Help</span> desk for more details, that might help you with your concern.</p>
                    <br/>
                    <p className="text-[16px] mt-1">You can also email us your query at <a href="" target="mailto:contact@globfluent.com" className="cursor-pointer text-cyanmod">{SUPPORT_EMAIL}</a>.</p>
                </div>
            </div>

            {/* <div className="flex justify-between mt-16 mb-20">
                <Address
                    heading='Email Address'
                    content={SUPPORT_EMAIL}
                />
                <Address
                    heading="Phone number"
                    content="+91 1234567890"
                />
            </div> */}


        </div>
    )
}

export default ContactUs