import { FC, useState } from "react";

interface ButtonProps {
    onClick: () => void;
    Heading: string;
    activeTab: string;
}

interface LearnerExpertToggleProps {
    learnerContent: () => JSX.Element;
    expertContent: () => JSX.Element;
    heading: string;
}

const Button: FC<ButtonProps> = ({ onClick, Heading, activeTab }) => (
    <div
        className={`w-[184px] h-[51px] flex items-center justify-center text-[22px] cursor-pointer toggle-button ${activeTab === Heading.toLowerCase() ? "bg-cyanmod-dark text-white font-semibold" : "bg-graymod"}`}
        onClick={onClick}
    >
        {Heading}
    </div>
);

const LearnerExpertToggle: FC<LearnerExpertToggleProps> = ({ learnerContent, expertContent, heading }) => {
    const [activeTab, setActiveTab] = useState<"learner" | "expert">("learner");

    const handleTabClick = (tab: "learner" | "expert") => {
        setActiveTab(tab);
    };

    return (
        <div className="toggle-container">
            <div className="flex justify-center w-full">
                <Button
                    onClick={() => handleTabClick("learner")}
                    Heading="Learner"
                    activeTab={activeTab}
                />
                <Button
                    onClick={() => handleTabClick("expert")}
                    Heading="Expert"
                    activeTab={activeTab}
                />
            </div>
            <div className="mb-4 mt-10 font-medium text-[20px] text-graymod-textfive">{heading}</div>
            <div className="content">
                {activeTab === "learner" ? learnerContent() : expertContent()}
            </div>
        </div>
    );
};

export default LearnerExpertToggle;
