
import { FC } from 'react'

interface Question{
    question: string,
    answer: any
}

const Question:FC<Question> = ({question, answer}) => {
  return (
    <div >
        <h2 className='text-[20px] text-wrap  font-medium'>
            {question}
        </h2>
        <p className='text-[18px] mt-2 text-wrap text-graymod-textfive'>
            {answer}
        </p>
    </div>
  )
}

export default Question