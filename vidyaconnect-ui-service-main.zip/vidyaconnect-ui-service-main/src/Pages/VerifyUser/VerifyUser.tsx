import { useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import axios, { AxiosResponse } from "axios";
import LandingPage from "../LandingPage/LandingPage";

interface VerifyUserProps {
  setShowPasswordModal: (value: boolean) => void;
}

interface VerificationResponse {
  data: {
    email: string;
    profile: string;
  };
}

const VerifyUser: React.FC<VerifyUserProps> = ({ setShowPasswordModal }) => {
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const token = params.get("token") || "";
  let profile = params.get("profile") || "";
  const navigate = useNavigate();

  useEffect(() => {
    const verifyEmail = async () => {
      try {
        const apiUrl = import.meta.env.VITE_REACT_APP_API_BASE_URL;
        const response: AxiosResponse<VerificationResponse> = await axios.get(
          `${apiUrl}/verifyEmail?token=${token}&profile=${profile}`
        );
        const { email, profile: fetchedProfile } = response.data.data;
        profile = fetchedProfile;

        // Serialize data into a single string and store in localStorage
        const userData = JSON.stringify({ email, profile });
        localStorage.setItem("userdata", userData);
        navigate("/");
        setShowPasswordModal(true);
      } catch (error) {
        console.error("Verification failed:", error);
      }
    };

    verifyEmail();
  }, [token, profile, navigate, setShowPasswordModal]);

  return <LandingPage showPasswordModal={true} />;
};

export default VerifyUser;
