import * as React from "react";
import expertProfileBg from "../../../../assets/expert-profile-bg.png";
import { FaStar } from "react-icons/fa";
import linkedin from "../../../../assets/linke.png";
import "./ExpertProfile.css";
import userIcon from "../../../../assets/userIcon.svg";
import { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Expertise, ExpertiseSkill, fetchEducation, fetchExpertise, fetchWork  } from "@/Redux/slices/ExpertWorkProfile";
import { RootState } from "@/Redux/store/store";
import AskaQuestionModal from "@/Components/AskaQuestionmodal/AskaQuestionModal";
import camera from "../../../../assets/camerawithbg.svg";
import { postProfilePicture } from "@/Redux/slices/ProfilePicGetUploadSlice";
import { getProfileDetails } from "@/Redux/slices/userSlice";
import { Education, WorkExperience } from "@/Redux/slices/ExpertsDataSlice";
import { getRatings } from "@/Redux/slices/FeedbackSlice";


interface HeadingButtonProps {
  value: string;
  heading: string;
  onClick: () => void;
}

const renderStars = (rating: number) => {
  const stars = [];
  for (let i = 1; i <= 5; i++) {
    stars.push(
      <FaStar
        key={i}
        className={`h-[24.47px] ${i <= rating ? "text-[#FFC700]" : "text-[#919EAB]"}`}
      />
    );
  }
  return stars;
};

const HeadingButton: React.FC<HeadingButtonProps> = ({ value, heading, onClick }) => {
  const isActive = value === heading.toLowerCase();
  return (
    <div
      onClick={onClick}
      className={`w-[248px] flex items-center justify-center cursor-pointer font-semibold text-[20px] pb-2 transition-all duration-100 ${isActive ? "border-cyanmod text-cyanmod" : "border-graymod text-graymod-textfour"} border-b-4`}>
      {heading}
    </div>
  );
};

const WorkExperienceComponent: React.FC = () => {
  const workExperiences = useSelector((state: RootState) => state.expertWorkProfile.workExperiences);
  const dispatch: any = useDispatch();

  useEffect(() => {
    dispatch(fetchWork());
  }, [dispatch]);

  return (
    <div className="flex flex-col gap-12 mt-16">
      {workExperiences.map((data: WorkExperience) => (
        <div className="border-l border-graymod-light pl-4" key={data.position}>
          <h3 className="font-medium text-[24px] text-graymod-textone mb-1">
            {data.position}
          </h3>
          <p className="font-medium text-[20px] text-graymod-textone mb-1">
            {data.company}
          </p>
          <p className="font-normal text-[16px] text-graymod-texttwo mb-4">
            {data.startDate === null || "" ? "" : data.startDate.slice(0, 4)} - {data.endDate === null || "" ? "Present" : data.endDate.slice(0, 4)}
          </p>
          <p className="font-normal text-[16px] w-[55vw] text-graymod-textthree mb-1">
            {data.description === null || '' ? " " : data.description}
          </p>
        </div>
      ))}
    </div>
  );
};

const EducationComponent: React.FC = () => {
  const education = useSelector((state: RootState) => state.expertWorkProfile.education);
  const dispatch: any = useDispatch();

  useEffect(() => {
    dispatch(fetchEducation());
  }, [dispatch]);

  return (
    <div className="flex flex-col gap-12 mt-16">
      {education.map((data: Education) => (
        <div className="border-l border-graymod-light pl-4" key={data.company}>
          <h3 className="font-medium text-[24px] text-graymod-textone mb-1">
            {data.company}
          </h3>
          <p className="font-medium text-[16px] text-text-graymod-one mb-1">
            {data.degree}, {data.course}
          </p>
          <p className="font-normal text-[14px] text-graymod-one mb-4">
            {data.startDate === null || "" ? "" : data.startDate}-{data.endDate === null || "" ? "Pursuing" : data.endDate}
          </p>
          <p className="font-normal text-[16px] w-[55vw] text-graymod-textthree mb-1">
            {data.description === null || '' ? " " : data.description}
          </p>
        </div>
      ))}
    </div>
  );
};

const ExpertiseComponent: React.FC = () => {
  const expertise = useSelector((state: RootState) => state.expertWorkProfile.expertise);
  const dispatch: any = useDispatch();

  useEffect(() => {
    dispatch(fetchExpertise());
  }, [dispatch]);

  return (
    <div className="mt-16 mb-10">
      {expertise.map((data: Expertise) => (
        <div className="border-l border-graymod-light pl-4 mb-16" key={data.domain}>
          <h3 className="font-medium text-[20px] text-graymod-textone mb-3">{data.domain}</h3>
          <div className="flex items-center gap-4 mb-4">
                  {data.skills.map((skillData: ExpertiseSkill) => (
                    <div className="flex items-center space-x-1 border border-graymod-verylight px-4 py-1 rounded-[20px]">
                    <div className="flex space-x-1">
                    {renderStars(skillData.score)}
                    <p className="font-normal text-[16px] text-graymod-text ps-1">
                      {skillData.skillName.charAt(0).toUpperCase() + skillData.skillName.slice(1)}
                      </p>
                    </div>
                    </div>
                    ))}
                   
        </div>
    </div>
  ))}
</div>);
}


const RaiseATicket: React.FC<{ onClick: () => void }> = ({ onClick }) => (
  <div className="mt-6">
    <p className="text-center">
      <span onClick={onClick} className="text-[16px] italic border-b mx-[4px] cursor-pointer hover:text-cyan-400 hover:border-cyan-400 border-cyanmod text-cyanmod">
        Raise a Ticket
      </span>
      <span className="flex text-[14px] text-gray px-6">to update your profile</span>
    </p>
  </div>
);

const RenderTabContent: React.FC<{ value: string }> = ({ value }) => {

  switch (value) {
    case "work experience":
      return (
          <WorkExperienceComponent />
      );
    case "education":
      return (
          <EducationComponent />
      );
    case "expertise":
      return (
          <ExpertiseComponent />
      );
    default:
      return null;
  }
};

const ExpertProfile: React.FC = () => {
  const [tab, setTab] = useState("work experience");
  const expertDetails = useSelector((state: RootState) => state.user.userDetails)
  //const [linkedInProfileLink, setLinkedInProfileLink] = useState<string>("")
  const [raiseATicketFlag, setRaiseATicketFlag] = useState<boolean>(false);
  const expertRatings = useSelector((state: RootState) => state.feedback);

  const handleTabChange = (newValue: string) => {
    setTab(newValue);
  };
  //const [isLinkedInEdit, setIsLinkedInEdit] = useState(false);
  const dispatch: any = useDispatch();

  const handlePostProfilePic = (e: any) => {
    if (e.target.files) {
      dispatch(postProfilePicture(e.target.files[0]));
    }
  };

  useEffect(() => {
    dispatch(getProfileDetails())
    dispatch(fetchWork());
    dispatch(getRatings())
    console.log(expertDetails.linkedInProfileLink)
  }, [dispatch]);

  // const handleSaveClick = () => {
  //   dispatch(updateExpertData({
  //     linkedInProfileLink: linkedInProfileLink
  //   })).then(() => {
  //     setIsLinkedInEdit(false);
  //   });
  // };

  // const handleCancelClick = () => {
  //   setIsLinkedInEdit(false);
  // };

  return (
    <div className="flex flex-col mx-10 mt-12">
  <img
    src={expertProfileBg}
    alt=""
    className="w-full h-[8rem] md:h-[12rem] rounded-t-[10px] md:rounded-t-[16px]"
  />

  <div className="flex">
    <div className="w-[25%] relative p-4">
      <div className="flex flex-col items-center">
        <div className="top-[40%] md:top-[55%] left-8 flex items-center justify-center flex-col">
        <div className="-top-20 left-1/2 transform -translate-x-1/2 absolute rounded-[50%] bg-white">
          <div className="absolute cursor-pointer w-[28px] bottom-0 right-6 image-upload">
            <label htmlFor="file-input">
              <img className="cursor-pointer" src={camera} alt="Upload" />
            </label>
          </div>
          <input
            id="file-input"
            type="file"
            style={{ display: 'none' }}
            onChange={handlePostProfilePic}
          />
          <img
            className="profilepic rounded-[50%] object-cover object-center h-[180px] w-[180px]"
            src={expertDetails.picUrl === null ? userIcon : expertDetails.picUrl}
            alt="Profile"
          />
          </div>
          <div className="flex flex-col justify-center items-center mt-[110px] gap-2">
            <h4 className="font-semibold text-[24px] text-center mb-2">
              {expertDetails.firstName} {expertDetails.lastName}
            </h4>
            <div className="flex items-center gap-2">
              <div className="gap-5">
                <div className="flex items-center space-x-1">
                  {renderStars(expertRatings.ratings)}
                </div>
                <span className="text-[20.56px] text-[#5B5B5B]">
                  {expertRatings.numSessions} sessions
                </span>
              </div>
            </div>
            {expertDetails.linkedInProfileLink && (
              <div className="flex items-start mt-3 gap-3">
              <a href={expertDetails.linkedInProfileLink} className="flex justify-content-center" target="_blank">
                <img src={linkedin} alt="LinkedIn" className="w-[22px] h-[22px]" />
                  <h4 className="font-normal text-[16px] cursor-pointer text-cyanmod ml-3">
                    {expertDetails.firstName} {expertDetails.lastName}
                  </h4>
                  {/* {expertDetails.linkedInProfileLink && (
                    <img onClick={() => setIsLinkedInEdit(true)} src={Edit} alt="Edit" className="cursor-pointer scale-75" />
                  )} */}
              </a>
              {/* {isLinkedInEdit ? (
                <div className="h-[54px] w-[137px] flex flex-col gap-3 items-start">
                  <Input
                    value={expertDetails.linkedInProfileLink}
                    onChange={(e) => setLinkedInProfileLink(e.target.value)}
                    placeholder="LinkedIn Profile URL"
                    className="w-[137px] px-1 text-[10px] h-[20px] placeholder:italic placeholder:text-[10px] placeholder:text-graymod-texttwo"
                  />
                  <div className="flex w-full justify-end gap-2">
                    <Button onClick={handleCancelClick} variant="outline" size="vsm">
                      Cancel
                    </Button>
                    <Button onClick={handleSaveClick} size="vsm">
                      Save
                    </Button>
                  </div>
                </div>
              ) : (
                <>
                  <h4 className="font-normal text-[16px] cursor-pointer text-cyanmod">
                    {expertDetails.firstName} {expertDetails.lastName}
                  </h4>
                  {expertDetails.linkedInProfileLink && (
                    <img onClick={() => setIsLinkedInEdit(true)} src={Edit} alt="Edit" className="cursor-pointer scale-75" />
                  )}
                </>
              )} */}
            </div>)}
            <RaiseATicket onClick={() => setRaiseATicketFlag(true)} />
          </div>
        </div>
      </div>
    </div>
    <div className="w-[75%] p-4">
      <div className="flex mb-4">
        <HeadingButton
          value={tab}
          heading="Work Experience"
          onClick={() => handleTabChange("work experience")}
        />
        <HeadingButton
          value={tab}
          heading="Education"
          onClick={() => handleTabChange("education")}
        />
        <HeadingButton
          value={tab}
          heading="Expertise"
          onClick={() => handleTabChange("expertise")}
        />
      </div>
      <div className="tab-content">
        <RenderTabContent value={tab} />
      </div>
      {raiseATicketFlag && <AskaQuestionModal onClose={() => setRaiseATicketFlag(false)} concern="Edit work profile" />}
    </div>
  </div>
</div>
  );
};

export default ExpertProfile;
