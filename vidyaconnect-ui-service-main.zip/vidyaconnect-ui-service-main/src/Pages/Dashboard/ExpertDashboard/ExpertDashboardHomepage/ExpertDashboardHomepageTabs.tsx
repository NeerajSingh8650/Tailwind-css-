import * as React from "react";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Box from "@mui/material/Box";
import { useSelector, useDispatch } from "react-redux";
import SadFace from "../../../../assets/sad_face.svg";
import { RootState } from "../../../../Redux/store/store";
import { useEffect, useState } from "react";
import {
  BOOKING_ACTION_ACCEPT,
  BOOKING_ACTION_REJECT,
  PAGE_SIZE,
  BOOKING_STATUS_SCHEDULED,
  BOOKING_STATUS_PENDING,
  SORT_FILTER_ID_DESCENDING,
  START_PAGE
} from "../../../../constants";
import {
  approvalSelectionApi,
  cancelBooking,
  clearSessionsData,
  fetchSessions
} from "../../../../Redux/slices/SessionRequestSlice";
import ExpertRejectSessionPopUp from "../../../../Components/RejectPopUp/RejectPopUp";
import ViewDetailsCard from "@/Components/ViewDetailsCard/ViewDetailsCard";
import SessionHistoryCard from "@/Components/SessionCard/SessionCard";
import SessionCard from "@/Components/SessionCard/SessionCard";
import { Button } from "@/shadcn/ui/button";
import { useNavigate } from "react-router-dom";

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function CustomTabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );
}

function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}

interface Props {
  userDetails: any;
}

export default function ExpertDashboardHomepageTabs({ userDetails }: Props) {
  const [value, setValue] = useState(0);
  const [firstName, setFirstName] = useState<string | null>(null);
  const [lastName, setLastName] = useState<string | null>(null);
  const [sessionId, setSessionId] = useState<number>(0);
  const [cancelSessionId, setCancelSessionId] = useState<number>(0);
  const [rejectionModule, setRejectionModule] = useState<boolean>(false);
  const [cancelModule, setCancelModule] = useState<boolean>(false);


  const sessions = useSelector(
    (state: RootState) => state.session.sessions);


  const dispatch: any = useDispatch();
  const navigate = useNavigate();
  const [isViewSession, setIsViewSession] = useState<boolean>(false);
  const [sessionRejectPopUpRejectCta, setSessionRejectPopUpRejectCta] =
    useState<boolean>(false);

  useEffect(() => {
    if (userDetails) {
      setFirstName(userDetails.firstName);
      setLastName(userDetails.lastName);
    }
  }, [userDetails]);



  useEffect(() => {
    dispatch(fetchSessions({ queryFilter: `status==${BOOKING_STATUS_SCHEDULED}`, sortFilter: SORT_FILTER_ID_DESCENDING, page: START_PAGE, size: PAGE_SIZE }));
  }, []);




  const handleChange = (_event: React.SyntheticEvent, newValue: number) => {
    dispatch(clearSessionsData());
    const queryFilter = newValue === 0 ? `status==${BOOKING_STATUS_SCHEDULED}` : `status==${BOOKING_STATUS_PENDING}`;
    const sortFilter = SORT_FILTER_ID_DESCENDING;
    const page = START_PAGE;
    const size = PAGE_SIZE;

    dispatch(fetchSessions({ queryFilter, sortFilter, page, size }));
    setValue(newValue);
  };




  const handleAccept = (data: any) => {
    dispatch(
      approvalSelectionApi({ action: BOOKING_ACTION_ACCEPT, id: data.id })
    ).then(() => {
      setTimeout(() => {
        dispatch(fetchSessions({ queryFilter: `status==${BOOKING_STATUS_PENDING}`, sortFilter: SORT_FILTER_ID_DESCENDING, page: START_PAGE, size: PAGE_SIZE }));
      }, 5000);
    });
  };

  const handleReject = () => {
    dispatch(
      approvalSelectionApi({ action: BOOKING_ACTION_REJECT, id: sessionId })
    ).then(() => {
      setTimeout(() => {
        dispatch(fetchSessions({ queryFilter: `status==${BOOKING_STATUS_PENDING}`, sortFilter: SORT_FILTER_ID_DESCENDING, page: START_PAGE, size: PAGE_SIZE })).then(() => {
          setRejectionModule(false);
          setSessionRejectPopUpRejectCta(false);
        });
      })
    }, 5000);
  };

  const handleCancel = () => {
    const queryFilter = value === 0 ? `status==${BOOKING_STATUS_SCHEDULED}` : `status==${BOOKING_STATUS_PENDING}`;
    dispatch(cancelBooking(cancelSessionId)).then(() => {
      setCancelModule(false);
      setTimeout(() => {
      dispatch(fetchSessions({ queryFilter: queryFilter, sortFilter: SORT_FILTER_ID_DESCENDING, page: START_PAGE, size: PAGE_SIZE }))
    }, 5000);
    });
  }

  return (
    <div className="px-16">

      {isViewSession && (
        <ViewDetailsCard
          onClose={() => {
            setIsViewSession(false);
          }}
        />
      )}

      {rejectionModule && (
        <ExpertRejectSessionPopUp
          heading="Are you sure you want to reject the session?"
          onCancel={() => setRejectionModule(false)}
          onConfirm={() => handleReject()}
        />
      )}

      {cancelModule && (
        <ExpertRejectSessionPopUp
          heading="Are you sure you want to cancel the session?"
          onCancel={() => setCancelModule(false)}
          onConfirm={() => handleCancel()}
        />
      )}

      <Box sx={{ width: "100%" }}>
        <Box sx={{ borderBottom: 1, borderColor: "divider" }} className="mb-8">
          <Tabs
            value={value}
            onChange={handleChange}
            aria-label="basic tabs example"
            TabIndicatorProps={{
              style: {
                backgroundColor: "#09A5D6",
              },
            }}
            sx={{
              "& .MuiTab-root.Mui-selected": {
                color: "#09A5D6 !important",
              },
            }}
          >
            <Tab
              label="Upcoming Sessions"
              {...a11yProps(0)}
              className="custom-tab"
            />
            <Tab
              label="Pending Approval"
              {...a11yProps(1)}
              className="custom-tab"
            />
          </Tabs>
        </Box>
        <CustomTabPanel value={value} index={0}>
          <div>
            {sessions.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {sessions.map((session: any) => (
                  <SessionCard
                    key={session.id}
                    session={session}
                    buttonText="Join"
                    isCancel={true}
                    onCancel={() => {
                      setCancelModule(true);
                      setCancelSessionId(session.id)
                    }}
                    profile="EXPERT"
                  />
                ))}
              </div>
            ) : (
              <div className="flex flex-cols items-center justify-center h-[50vh]">
                <div className="text-[16px] font-normal text-gray max-w-[500px] text-center mb-4">
                  <div className="empty-img mb-5 flex justify-center">
                    <img src={SadFace} />
                  </div>
                  <p>
                    Hi {firstName} {lastName}! Looks like you have no upcoming
                    sessions. Make sure your availability is updated to start
                    receiving the requests.
                  </p>
                  <div className="mt-4">
                    <Button onClick={() => navigate("/expert-settings#availability")}>
                      Add Availability
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </CustomTabPanel>

        <CustomTabPanel value={value} index={1}>
          <div>
            {sessionRejectPopUpRejectCta && (
              <ExpertRejectSessionPopUp
                heading="Are you sure want to reject this session ?"
                onCancel={() => setSessionRejectPopUpRejectCta(false)}
                onConfirm={() => handleReject()}
              />
            )}
            {sessions.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {sessions.map((session: any) => (
                  <SessionHistoryCard
                    key={session.id}
                    session={session}
                    isAmount={true}
                    isApprovalCTA={true}
                    AcceptCTAClick={() => handleAccept(session)}
                    RejectCTAClick={() => {
                      setSessionId(session.id);
                      setSessionRejectPopUpRejectCta(true);
                    }}
                    profile="EXPERT"
                  />
                ))}
              </div>
            ) : (
              <div className="flex flex-cols items-center justify-center h-[50vh]">
                <div className="text-[16px] font-normal text-gray max-w-[500px] text-center mb-4">
                  <div className="empty-img mb-5 flex justify-center">
                    <img src={SadFace} />
                  </div>
                  <p>
                    Hi {firstName} {lastName}! Looks like you have no Pending
                    Approvals. Make sure your availability is updated to start
                    receiving the requests.
                  </p>
                  <div className="mt-4">
                    <Button onClick={() => navigate("/expert-settings#availability")}>
                      Add Availability
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </CustomTabPanel>
      </Box>
    </div>
  );
}
