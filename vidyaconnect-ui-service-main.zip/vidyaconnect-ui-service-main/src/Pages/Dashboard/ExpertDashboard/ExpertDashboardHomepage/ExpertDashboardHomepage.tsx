import { useEffect } from "react";
import ExpertDashboardHomepageTabs from "./ExpertDashboardHomepageTabs";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "@/Redux/store/store";
import { fetchUserProfile } from "@/Redux/slices/authSlice";

const ExpertDashboardHomepage = () => {
  const dispatch: any = useDispatch();
  const { userDetails }  = useSelector((state: RootState) => state.auth);

  useEffect(() => {
    dispatch(fetchUserProfile());
  },[])

  return (
    <>
      <div className=" bg-[#E2E2E2]">
        <div className="py-10 mx-6 md:mx-12">
          <ExpertDashboardHomepageTabs userDetails={userDetails} />
        </div>
      </div>
      
    </>
  );
};

export default ExpertDashboardHomepage;
