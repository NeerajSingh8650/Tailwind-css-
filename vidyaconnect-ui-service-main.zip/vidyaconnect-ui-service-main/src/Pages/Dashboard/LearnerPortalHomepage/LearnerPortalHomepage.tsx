import HomepageTabs from "./HomepageTabs";

const LearnerPortalHomepage = () => {
  return (
    <div className=" bg-[#E2E2E2]">
      <div className="py-10 mx-6 md:mx-12">
        <HomepageTabs />
      </div>
    </div>
  );
};

export default LearnerPortalHomepage;