import * as React from "react";
import { useState } from "react";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Box from "@mui/material/Box";
import SentimentDissatisfiedTwoToneIcon from "@mui/icons-material/SentimentDissatisfiedTwoTone";
import { useEffect } from "react";
import {
  cancelBooking,
  clearSessionsData,
  fetchSessions
} from "@/Redux/slices/SessionRequestSlice";

import { useDispatch, useSelector } from "react-redux";
import { AppDispatch, RootState } from "@/Redux/store/store";
import ExpertRejectSessionPopUp from "@/Components/RejectPopUp/RejectPopUp";
import { Button } from "@/shadcn/ui/button";
import ViewDetailsCard from "@/Components/ViewDetailsCard/ViewDetailsCard";
import SessionCard from "@/Components/SessionCard/SessionCard";
import { useNavigate } from "react-router-dom";

import { PAGE_SIZE, BOOKING_STATUS_SCHEDULED, BOOKING_STATUS_PENDING, SORT_FILTER_ID_DESCENDING, START_PAGE } from '../../../constants'
import GetLiveHelpModalManager from "@/Components/GetLiveHelpModalManager";
import { learnerGetLiveHelpModalUpdate } from "@/Redux/slices/FlagsSLice";

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function CustomTabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );
}

function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}

export default function HomepageTabs() {


  const [value, setValue] = React.useState(0);
  const dispatch: AppDispatch = useDispatch();



  const sessions = useSelector(
    (state: RootState) => state.session.sessions
  );
  const navigate = useNavigate();

  const [cancelModule, setCancelModule] = useState<boolean>(false);
  const [cancelSessionId, setCancelSessionId] = useState<number>(0);
  const [isViewSession, setIsViewSession] = useState<boolean>(false);

  const handleChange = (_event: React.SyntheticEvent, newValue: number) => {
    dispatch(clearSessionsData());
    const queryFilter = newValue === 0 ? `status==${BOOKING_STATUS_SCHEDULED}` : `status==${BOOKING_STATUS_PENDING}`;
    const sortFilter = SORT_FILTER_ID_DESCENDING;
    const page = START_PAGE;
    const size = PAGE_SIZE;
    dispatch(fetchSessions({ queryFilter, sortFilter, page, size }))
    setValue(newValue);
  };


  const handleCancel = () => {
    dispatch(cancelBooking(cancelSessionId)).then(() => {
      setCancelModule(false);
      setTimeout(() => {
        dispatch(fetchSessions({ queryFilter: `status==${sessions[0].status}`, sortFilter: SORT_FILTER_ID_DESCENDING, page: START_PAGE, size: PAGE_SIZE }))
      }, 5000)
    });
  };



  useEffect(() => {
    dispatch(fetchSessions({ queryFilter: `status==${BOOKING_STATUS_SCHEDULED}`, sortFilter: SORT_FILTER_ID_DESCENDING, page: START_PAGE, size: PAGE_SIZE }))
  }, []);

  return (
    <div className="px-16">


      {cancelModule && (
        <ExpertRejectSessionPopUp
          heading="Are you sure you want to cancel the session?"
          onCancel={() => setCancelModule(false)}
          onConfirm={() => handleCancel()}
        />
      )}

      {isViewSession && (
        <ViewDetailsCard onClose={() => setIsViewSession(false)} />
      )}

      <Box sx={{ width: "100%" }}>


        <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
          <Tabs
            value={value}
            onChange={handleChange}
            aria-label="basic tabs example"
            TabIndicatorProps={{
              style: {
                backgroundColor: "#09A5D6",
              },
            }}
            sx={{
              "& .MuiTab-root.Mui-selected": {
                color: "#09A5D6 !important",
              },
            }}
          >
            <Tab label="Upcoming Sessions" {...a11yProps(0)} />
            <Tab label="Pending Requests" {...a11yProps(1)} />
          </Tabs>
        </Box>

        <CustomTabPanel value={value} index={0}>
          {sessions.length === 0 ? (
            <div className="flex flex-col justify-center items-center h-[100vh]">
              <div className="h-[60px] flex justify-center items-center scale-[350%] font-[300] text-[#9d9d9d] mb-5">
                <SentimentDissatisfiedTwoToneIcon />
              </div>
              <p className="text-[16px] font-normal text-graymod-light2 max-w-[500px] text-center mb-4">
                Hi, Looks like you have no upcoming sessions. Explore experts or directly Book a Session based on your requirements.
              </p>
              <div className="flex items-center">
                <Button
                  className="mr-4"
                  onClick={() => navigate("/explore-experts")}
                >
                  Explore
                </Button>
                <Button onClick={() => dispatch(learnerGetLiveHelpModalUpdate(true))}>
                  Book Now
                </Button>
              </div>
            </div>
          ) : (
            <div
              id="pendingreq"
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
            >
              {sessions.map((session: any) => (
                <SessionCard
                  key={session.id}
                  session={session}
                  buttonText="Join"
                  isCancel={true}
                  onCancel={() => {
                    setCancelModule(true);
                    setCancelSessionId(session.id)
                  }}
                  profile = "LEARNER"
                />
              ))}
            </div>
          )}
        </CustomTabPanel>


        <CustomTabPanel value={value} index={1}>
          {sessions.length === 0 ? (
            <div className="flex flex-col justify-center items-center h-[100vh]">
              <div className="h-[60px] flex justify-center items-center scale-[350%] font-[300] text-[#9d9d9d]  mb-5">
                <SentimentDissatisfiedTwoToneIcon />
              </div>
              <p
                id="proc"
                className="text-[16px] font-normal text-graymod-light2 max-w-[500px] text-center mb-4"
              >
                Hi, Looks like you have no upcoming sessions. Explore experts or directly Book a Session based on your requirements.
              </p>
              <div className="flex items-center gap-3">
                <Button
                  className="mr-4"
                  onClick={() => navigate("/explore-experts")}
                >
                  Explore
                </Button>
                <Button onClick={() => dispatch(learnerGetLiveHelpModalUpdate(true))}>
                  Book Now
                </Button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {sessions.map((session: any) => (
                <SessionCard
                  key={session.id}
                  session={session}
                  buttonText="Book Again"
                  isLearnerPending={true}
                  isCancel={true}
                  onCancel={() => {
                    setCancelModule(true);
                    setCancelSessionId(session.id);
                  }}
                  profile="LEARNER"
                />
              ))}
            </div>
          )}
        </CustomTabPanel>
      </Box>
      <GetLiveHelpModalManager />
    </div>
  );
}
